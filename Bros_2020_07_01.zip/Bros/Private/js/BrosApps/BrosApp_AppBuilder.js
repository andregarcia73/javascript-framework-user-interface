//###########################################################################
//###########################################################################
//##
//## Bros Application - Application Builder
//##
//###########################################################################
//###########################################################################

		var BrosAppBuilder			= new CBrosAppBuilder();
		BrosAppBuilder.CreateWindow	();

//###########################################################################
//###########################################################################
//##
//## Class BrosAppBuilder
//##
//###########################################################################
//###########################################################################

function CBrosAppBuilder()
	{
	//===========================================================================
	//===========================================================================
	//==
	//== Properties
	//==
	//===========================================================================
	//===========================================================================

		this.MainWindowPos			= [5, 5, 1270, 490];
//this.MainWindowPos		= [200, 5, 1070, 490];			// To see System Monitor behind (in debug)
//this.MainWindowPos		= [400, 5,  870, 490];			// To see System Monitor behind (in debug)
		this.NewWindowPos			= [5, 5,  680, 280];
		//
		this.Panel_Handler_Width	= 700;
this.Panel_ElemInsp_Width	= 100;
		this.Panel_Buttons_Height	=  38;
		this.Panel_ElemBut_Height	=  70;

		// Named elements
this.Panel_ElemInsp			= null;
		this.Panel_Buttons			= null;
		this.Panel_ElemButtons		= null;
		this.Panel_Messages			= null;
		this.Panel_Work				= null;
		this.Panel_Execution		= null;
		//
		this.Panel_ElemBtns_Kernel	= null;

		// For Buttons
		this.Button_Left			= 2;							// Current Left
		this.Button_Top				= 2;
		this.Button_Width			= 30;
		this.Button_Weight			= 30;
		//
		this.Button_SLeft			= 2;							// Start Left
		this.Button_Spacement		= 0;

		// For Projects
		this.SelectedElement		= null;
		this.ProjectWindow			= null;
		this.HoldElemBtnDown		=   false;

		// Element Inspector
		this.ElementInspector		= new CBrosElementInspector();

		// SnapToGrid
		this.SnapToGrid				= ! false;
		this.GridSize				= 8;

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to Create Window
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Widndow
	//---------------------------------------------------------------------------

	this.CreateWindow = function CreateWindow()
		{
		//	deb						("CBrosAppBuilder.CreateWindow");

		// Creates the Application Window
		Bros
			.createelement			("window")
				.name				("MainWindow", this)
				.left				(this.MainWindowPos)
			;

		// Creates Menus
		this.CreateMenus			();

//		// Creates the Element Inspector panel
//		Bros
//			.createelement			("panel")
//				.name				("Panel_ElemInsp", this)
//.color			("FF0000")
//				.borderstyle		(Bros.bsNone)
//				.align				("left")
//				.width				(this.Panel_ElemInsp_Width)
//				.resizable			(! false)
////				//
//				.parent				()
//			;

		// Handler Panel Beguin
		Bros
			.createelement			("panel")
				.width				(this.Panel_Handler_Width)
				.align				("left")
				.resizable			(! false)
				.borderstyle		(Bros.bsNone)
			;

		// Creates the Buttons panel
		Bros
			.createelement			("panel")
				.name				("Panel_Buttons", this)
				//	.color			("0000FF")
				//	.borderstyle	(Bros.bsNone)
				.borderstyle		(Bros.bsGroup)
				.align				("top")
				.height				(this.Panel_Buttons_Height)
				//
				.parent				()
			;

		// Creates the Element Buttons panel
		Bros
			.createelement			("panel")
				.name				("Panel_ElemButtons", this)
				//	.color			("FFFF00")
				.borderstyle		(Bros.bsNone)
				.align				("top")
				.height				(this.Panel_ElemBut_Height)
				//	.resizable		(! false)
				//
				.parent				()
			;

		// Creates the Work panel
		Bros
			.createelement			("panel")
				.name				("Panel_Work", this)
				//	.color			("000000")
				.borderstyle		(Bros.bsNone)
				.align				("client")
				//
				.parent				()
			;

		// Handler Panel End
		Bros.parent					();

		// Splitter
		Bros
			.createelement			("splitter")
				.align				("left")
				.borderstyle		(Bros.bsNone)
			;

		// Creates the Inspector and Messages panel
		Bros
			.createelement			("selectorpanels")
				.borderstyle		(Bros.bsEdit)
				.align				("client")
				.addparentitem		("Inspector")
					.name			("Panel_AppBuilderInspector",	this)
					.parentitem		()
				.addparentitem		("Bros Messages")
					.name			("Panel_Messages",	this)
					.parentitem		()
.selected			(1)
.selected			(0)
			;
		//	Bros.bsEdit				= [	["808080"]	,	["808080"]	,	["FFFFFF"]	,	["FFFFFF"]	,		["404040"]	,	["404040"]	,	["D4D0C8"]	,	["D4D0C8"]	];
		var BorderStyle				= [	[]			,	["808080"]	,	[]			,	[]			,		[]			,	["404040"]	,	[]			,	[]			];
		Bros.BuildMsgsContainer		(this.Panel_Messages, BorderStyle);
		this.ElementInspector.Setup	(this.Panel_AppBuilderInspector);

		// OK !
//	PCS						(this.Panel_ElemInsp);
		//	PCS						(this.Panel_Buttons);
		//	PCS						(this.Panel_ElemButtons);
		//	PCS						(this.Panel_Messages);
		//	PCS						(this.Panel_Work);

		// Creates the panel Buttons elements
		this.CreatePanelButtons		();

		// Creates the panel Work elements
		this.CreatePanelWork		();

		// Creates the panel Element Buttons elements
		this.CreatePanelElements	();

		// New Project
		this.NewProject				();
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to create Menus
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates Menus
	//---------------------------------------------------------------------------

	this.CreateMenus = function CreateMenus()
		{
		//	deb						("CBrosAppBuilder.CreateMenus");
		var This					= this;
		Bros
			.createelement			("mainmenu")
				.additem			("File",	"",		"",		"Menu_File")
			;

		// Menu: File
		Bros
			.createelement			("menu")
				.name				("Menu_File")
				.additem			("New Project", "", "", function (Elem)
					{
					//	deb			("Menu_New_Project clicked");
					This.NewProject	();
					})
				.additem			("Exit", "", "", function (Elem)
					{
					//	deb			("Menu_File_Exit clicked");
					Bros.element	(This.MainWindow).close();
					})
			;
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates a Button
	//---------------------------------------------------------------------------

	this.CreateButton = function CreateButton(IsPushPull, GroupIndex, OnClickOn, ImageSrc, OnClick)
		{
		//	deb						("CBrosAppBuilder.CreateButton");
		Bros
			.createelement			("button")
				.caption			("")
				//	.color			("FF0000")
				.left				(this.Button_Left, this.Button_Top, this.Button_Width, this.Button_Weight)
				.borderstyle		(Bros.bsNone)
				.ispushpull			(IsPushPull)
//				.groupindex			(GroupIndex)
				.onclickon			(OnClickOn)
				.imagesrc			(Bros.URL_Path_Img_Bros_Prg + "BrosApp_AppBuilder/" + ImageSrc)
				.onclick			(OnClick)
//.onover ...
				//.onclick			(OnClick ? OnClick : function (Elem, e)
				//	{
				//	deb				("NO ON CLICK !!!");
				//	})
				.down				()
					.color			("FFFFFF")
					.pixelsoffset	([0, 0])
				.parent				()
			;
		this.Button_Left		   += this.Button_Width + this.Button_Spacement;
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to create the Panel Buttons elements
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates the panel Buttons elements
	//---------------------------------------------------------------------------

	this.CreatePanelButtons = function CreatePanelButtons()
		{
		//	deb						("CBrosAppBuilder.CreatePanelButtons");

		// Setup
		this.Button_Left			= this.Button_SLeft;			// Current Left = Start Left
		Bros.element				(this.Panel_Buttons);

		// Run button
		var This					= this;
		this.CreateButton			(  false, -1, "up",		"Img_Btn_Run.png",			function (Elem, e)
			{
			This.CompileProject		();
			Bros.element			(This.Work_SelectorPanels).selected(1);
			Bros.element			(This.Work_EditArea).value(This.CompiledResult.join(Bros.CRLF));
			});

		// Clear Msgs button
		this.CreateButton			(  false, -1, "up",		"Img_Btn_ClearMsgs.png",	function (Elem, e)
			{
			Bros.ClearMsgsContainer	();
			});

		// Hold Element Buttons Down button
		// Created below
		//this.CreateButton			(! false, -1, "up",		"Img_Btn_HoldDown.png",		function (Elem, e)
		//	{
		//	This.HoldElemBtnDown	= (Bros.value() == 1);
		//	// Clear last selected element
		//	if (Bros.value() == 0)
		//		This.ClearLastSelected();
		//	});
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to create the Panel Work elements
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates the panel Work elements
	//---------------------------------------------------------------------------

	this.CreatePanelWork = function CreatePanelWork()
		{
		//	deb						("CBrosAppBuilder.CreatePanelWork");

		// Setup
		Bros.element				(this.Panel_Work);

		//	Bros.bsEdit				= [	["808080"]	,	["808080"]	,	["FFFFFF"]	,	["FFFFFF"]	,		["404040"]	,	["404040"]	,	["D4D0C8"]	,	["D4D0C8"]	];
		var bsEdit_OnlyTop			= [	[]			,	["808080"]	,	[]			,	[]			,		[]			,	["404040"]	,	[]			,	[]			];

		// Create
		Bros
			.createelement			("selectorpanels")
				.name				("Work_SelectorPanels", this)
				.borderstyle		(Bros.bsEdit)
				.align				("client")
				.addparentitem		("Window")
					.borderstyle	(bsEdit_OnlyTop)
					.createelement	("panel")
						.name		("Panel_Execution", this)
						.align		("client")
						.color		("808080")
						.borderstyle(Bros.bsNone)
						.scrollbars	("both")
						.parent		()
					.parentitem		()
				.addparentitem		("Script")
					.createelement	("editarea")
						.mode		("codeeditor")
						.borderstyle(bsEdit_OnlyTop)
						.name		("Work_EditArea", this)
						.align		("client")
					.parentitem		()
// BUG ! NOT SELECTING 0
.selected			(1)
.selected			(0)
			;
		//	PCS						(this.Panel_Execution);
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to create the panel Element Buttons elements
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates the panel Element Buttons elements
	//---------------------------------------------------------------------------

	this.CreatePanelElements = function CreatePanelElements()
		{
		//	deb						("CBrosAppBuilder.CreatePanelElements");

		// Setup
		Bros.element				(this.Panel_ElemButtons);

		// Create
		Bros
			.createelement			("panel")
				.align				("left")
				.width				(37)
				.borderstyle		(Bros.bsEdit)
			;
		this.Button_Left			= this.Button_SLeft;			// Current Left = Start Left
		// Hold Element Buttons Down button
		this.CreateButton			(! false, -1, "up",		"Img_Btn_HoldDown.png",		function (Elem, e)
			{
			This.HoldElemBtnDown	= (Bros.value() == 1);
			// Clear last selected element
			if (Bros.value() == 0)
				This.ClearLastSelected();
			});
		Bros		.top			(35);
		Bros	.parent				();

		// Create
		Bros
			.createelement			("selectorpanels")
				.borderstyle		(Bros.bsEdit)
				.align				("client")
				.addparentitem		("Kernel")
					.name			("Panel_ElemBtns_Kernel",	this)
					.parentitem		()
			//	.additem			("Aux")
			//		.name			("Panel_ElemBtns_Aux",		this)
			//		.parent			()
// BUG ! NOT SELECTING 0
//.selected			(1)
//.selected			(0)
			;
		//	PCS						(this.Panel_ElemBtns_Kernel);

		// Setup
		var This					= this;
		var IF						= ! false;						// IF = IsPushPull
		var GI						= -1;							// GI = GroupIndex
		var OO						= "down";						// OO = OnClickOn

		// Panel_ElemBtns_Kernel
		this.Button_Left			= this.Button_SLeft;			// Current Left = Start Left
		Bros.element				(this.Panel_ElemBtns_Kernel);
		//	this.CreateButton		(IF, GI, OO, "Img_0010_element.png",		function (Elem, e) { This.HAOCEB(Elem, e, "element"			)});
		this.CreateButton			(IF, GI, OO, "Img_0020_label.png",			function (Elem, e) { This.HAOCEB(Elem, e, "label"			)});
		this.CreateButton			(IF, GI, OO, "Img_0030_image.png",			function (Elem, e) { This.HAOCEB(Elem, e, "image"			)});
		this.CreateButton			(IF, GI, OO, "Img_0040_imagelabel.png",		function (Elem, e) { This.HAOCEB(Elem, e, "imagelabel"		)});
		this.CreateButton			(IF, GI, OO, "Img_0050_button.png",			function (Elem, e) { This.HAOCEB(Elem, e, "button"			)});
		this.CreateButton			(IF, GI, OO, "Img_0060_checkbox.png",		function (Elem, e) { This.HAOCEB(Elem, e, "checkbox"		)});
		this.CreateButton			(IF, GI, OO, "Img_0070_radiobutton.png",	function (Elem, e) { This.HAOCEB(Elem, e, "radiobutton"		)});
		//	this.CreateButton		(IF, GI, OO, "Img_0080_updown.png",			function (Elem, e) { This.HAOCEB(Elem, e, "updown"			)});
		this.CreateButton			(IF, GI, OO, "Img_0090_panel.png",			function (Elem, e) { This.HAOCEB(Elem, e, "panel"			)});
		this.CreateButton			(IF, GI, OO, "Img_0100_group.png",			function (Elem, e) { This.HAOCEB(Elem, e, "group"			)});
		this.CreateButton			(IF, GI, OO, "Img_0110_selector.png",		function (Elem, e) { This.HAOCEB(Elem, e, "selector"		)});
		//	this.Button_Left		= this.Button_SLeft;			// Current Left = Start Left
		//	Bros.element			(this.Panel_ElemBtns_Aux);		// For Testing, show in new panel
		this.CreateButton			(IF, GI, OO, "Img_0120_checkboxes.png",		function (Elem, e) { This.HAOCEB(Elem, e, "checkboxes"		)});
		this.CreateButton			(IF, GI, OO, "Img_0130_radiobuttons.png",	function (Elem, e) { This.HAOCEB(Elem, e, "radiobuttons"	)});
		this.CreateButton			(IF, GI, OO, "Img_0140_mainmenu.png",		function (Elem, e) { This.HAOCEB(Elem, e, "mainmenu"		)});
		this.CreateButton			(IF, GI, OO, "Img_0150_selectorpanels.png",	function (Elem, e) { This.HAOCEB(Elem, e, "selectorpanels"	)});
		this.CreateButton			(IF, GI, OO, "Img_0160_editarea.png",		function (Elem, e) { This.HAOCEB(Elem, e, "editarea"		)});
		//	this.CreateButton		(IF, GI, OO, "Img_0165_editarea.png",		function (Elem, e) { This.HAOCEB(Elem, e, "editarea"		)});
		this.CreateButton			(IF, GI, OO, "Img_0170_edit.png",			function (Elem, e) { This.HAOCEB(Elem, e, "edit"			)});
		this.CreateButton			(IF, GI, OO, "Img_0180_editbutton.png",		function (Elem, e) { This.HAOCEB(Elem, e, "editbutton"		)});
		this.CreateButton			(IF, GI, OO, "Img_0190_select.png",			function (Elem, e) { This.HAOCEB(Elem, e, "select"			)});
		//	this.CreateButton		(IF, GI, OO, "Img_0200_selectdate.png",		function (Elem, e) { This.HAOCEB(Elem, e, "selectdate"		)});
		this.CreateButton			(IF, GI, OO, "Img_0210_splitter.png",		function (Elem, e) { This.HAOCEB(Elem, e, "splitter"		)});
		//	this.CreateButton		(IF, GI, OO, "Img_0220_navigator.png",		function (Elem, e) { This.HAOCEB(Elem, e, "navigator"		)});
		this.CreateButton			(IF, GI, OO, "Img_0230_tree.png",			function (Elem, e) { This.HAOCEB(Elem, e, "tree"			)});
		this.CreateButton			(IF, GI, OO, "Img_0240_spreadsheet.png",	function (Elem, e) { This.HAOCEB(Elem, e, "table"			)});
		//	this.CreateButton		(IF, GI, OO, "Img_0250_list.png",			function (Elem, e) { This.HAOCEB(Elem, e, "list"			)});
		this.CreateButton			(IF, GI, OO, "Img_0255_slider.png",			function (Elem, e) { This.HAOCEB(Elem, e, "slider"			)});
		this.CreateButton			(IF, GI, OO, "Img_0260_gauge.png",			function (Elem, e) { This.HAOCEB(Elem, e, "gauge"			)});
		this.CreateButton			(IF, GI, OO, "Img_0270_menu.png",			function (Elem, e) { This.HAOCEB(Elem, e, "menu"			)});
		this.CreateButton			(IF, GI, OO, "Img_0280_timer.png",			function (Elem, e) { This.HAOCEB(Elem, e, "timer"			)});
		this.CreateButton			(IF, GI, OO, "Img_0290_tmeter.png",			function (Elem, e) { This.HAOCEB(Elem, e, "tmeter"			)});
		//	this.CreateButton		(IF, GI, OO, "Img_0300_window.png",			function (Elem, e) { This.HAOCEB(Elem, e, "window"			)});
		//	this.CreateButton		(IF, GI, OO, "Img_0310_application.png",	function (Elem, e) { This.HAOCEB(Elem, e, "application"		)});
		};

	//---------------------------------------------------------------------------
	// Handler OnClick of Element Button
	//---------------------------------------------------------------------------

	this.HAOCEB = function HAOCEB(Elem, e, ClassName)		// HAOCEB = HandlerOnClickElemBtn
		{
		//	deb						("CBrosAppBuilder.HAOCEB", "ClassName = " + ClassName, "Bros.value() = " + Bros.value());
		//	deb						("ClassName = " + ClassName);
		//	PCS						(Elem);

		// Same button going up ?
		if (Bros.value() == 0)
			{
			this.SelectedElement	= null;
			return;
			}

		// Clear last selected element
		this.ClearLastSelected		();

		// Stores the ClassName into the Button
		Elem.AppB_ClassName			= ClassName;

		this.SelectedElement		= Elem;
		};

	//---------------------------------------------------------------------------
	// Clear last selected element
	//---------------------------------------------------------------------------

	this.ClearLastSelected = function ClearLastSelected()
		{
		//	deb						("CBrosAppBuilder.ClearLastSelected", "this.SelectedElement = " + this.SelectedElement);
		// Someoneelse selected ?
		if (this.SelectedElement == null)
			return;

		// Set Button Up
		Bros
			.element				(this.SelectedElement)
			.value					(0)
			;

		// Reset
		this.SelectedElement		= null;
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods for projects
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// New Project
	//---------------------------------------------------------------------------

	this.NewProject = function NewProject()
		{
		//	deb						("CBrosAppBuilder.NewProject");
		var This					= this;
		this.ElementInspector.ClearInspector();
		Bros
			.element				(this.Work_EditArea)
				.value				("")
			.element				(this.Panel_Execution)
.html					("")
			.createelement			("window")
				.left				(this.NewWindowPos)
				.caption			("New Project")
				.onready			(function (Elem)
					{
					This.ProjectWindow			= Elem;
					Elem.CreatedOnAppBuilder	= ! false;
This.CaptureEvents(Elem.Panel_Bottom);
					})
			;
		};

	//---------------------------------------------------------------------------
	// Capture Events of an element
	//---------------------------------------------------------------------------

	this.CaptureEvents = function CaptureEvents(Bobj)
		{
		//	deb						("CBrosAppBuilder.CaptureEvents", Bros.CElm.WhoAmI(Bobj));
		var This					= this;
		$("#" + Bros.CElm.Get_ID(Bobj, Bros.Elm_ID_Element))
			.click					(function (e)
				{
				//	deb				("CBrosAppBuilder", "click",		Bros.CElm.WhoAmI(Bobj));
				Bros.StopEventPropagation(e);
				var ElementCreated	= This.OnClickOnProject(Bobj, e);
				if (! ElementCreated)
					This.ElementInspector.Inspect(Bobj);				// Changes the element to be inspected
				})
//			.mousedown				(function (e)
//				{
//				Bros.StopEventPropagation(e);
//				//	deb				("CBrosAppBuilder", "mousedown",	Bros.CElm.WhoAmI(Bobj));
//				})
			;
		};

	//---------------------------------------------------------------------------
	// Capture Events of an element return true if creates an element and false if not
	//---------------------------------------------------------------------------

	this.OnClickOnProject = function OnClickOnProject(Bobj, e)
		{
		//	deb						("CBrosAppBuilder.OnClickOnProject", Bros.CElm.WhoAmI(Bobj));
		//	deb						("this.SelectedElement = " + this.SelectedElement);

		// Someone selected ?
		if (this.SelectedElement == null)
			return false;

		// Before cleanning
		var ClassToCreate			= this.SelectedElement.AppB_ClassName;

		// Disables
		if (! this.HoldElemBtnDown)
			this.ClearLastSelected	();

		// Creates...
		//	deb						("Creating " + ClassToCreate);
		this.CreateElement			(Bobj, e, ClassToCreate);

		return ! false;
		};

	//---------------------------------------------------------------------------
	// Create element on mouse position
	//---------------------------------------------------------------------------

	this.CreateElement = function CreateElement(Bobj, e, ClassToCreate)
		{
		//	deb						("CBrosAppBuilder.CreateElement", Bros.CElm.WhoAmI(Bobj));

		// Gets the position to locate the new element (see "Bros.MouseIsInside")
		var Pos						= Bros.GetMousePos(e);
		var LT						= Bros.Get_Page_LeftTop(Bobj);
		//	deb						("Pos = " + Pos, "LT = " + LT);
		var LT_ToApply				= [Pos[0] - LT[0], Pos[1] - LT[1]];

		// Snap to grid ?
		if (this.SnapToGrid)
			LT_ToApply				= [LT_ToApply[0] - (LT_ToApply[0] % this.GridSize), LT_ToApply[1] - (LT_ToApply[1] % this.GridSize)];

		// Creates and positionates
		var This					= this;
		Bros
			.element				(Bobj)
			.createelement			(ClassToCreate)
				.left				(LT_ToApply)
				.onready			(function (Elem)
					{
					This.SetupCreatedElement	(Elem);
					Elem.CreatedOnAppBuilder	= ! false;
					Elem.SnapToGrid				= This.SnapToGrid;
					Elem.GridSize				= This.GridSize;
					})
			;
			
		};

	//---------------------------------------------------------------------------
	// Setup Created element
	//---------------------------------------------------------------------------

	this.SetupCreatedElement = function SetupCreatedElement(Bobj)
		{
		//	deb						("CBrosAppBuilder.SetupCreatedElement", Bros.CElm.WhoAmI(Bobj));
		//	PCS						(Bobj);
		Bros
			.element				(Bobj)
				.movable			(! false)
				.resizable			(! false)
			;

		// Apply Align (if is the case) (used in cases like splitter or mainmenu)
		switch (Bobj.Align)
			{
			case "left":
			case "top":
			case "right":
			case "bottom":
				Bros.align			(Bobj.Align);
				break;
			}

		// Add Default Itens (if is the case)
		//	PCS						(Bobj.Handler);
		if (Bobj.Handler.AppBuilderItemsToAdd)
			{
			for (var i = 0; i < Bobj.Handler.AppBuilderItemsToAdd.length; i++)
				{
				if (Bobj.Handler.AppBuilderItemsToAddPar)
					{
					Bros.addparentitem	(Bobj.Handler.AppBuilderItemsToAdd[i]);
					Bros.parentitem		();
					}
				else
					Bros.additem	(Bobj.Handler.AppBuilderItemsToAdd[i]);
				}
			}

		// Finalize
		this.CaptureEvents			(Bobj);
		this.ElementInspector.Inspect(Bobj);
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to compile
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Compile Project
	//---------------------------------------------------------------------------

	this.CompileProject = function CompileProject()
		{
		//	deb						("CBrosAppBuilder.CompileProject", "this.ProjectWindow = " + this.ProjectWindow);
		//	Bros.ShowBOM			(this.ProjectWindow);
		//	var Result				= this.ExploreBOM(this.ProjectWindow);
		//	Bros.RW					(Result.join(""));

		var MaxLevel				= Bros.GetMaxLevelBOM(this.ProjectWindow);

		// Compile
		this.LastLevel				= -1;
		this.CompiledResult			= [];
//		this.CompiledResult.push	(this.GetStatementToPush(0, -1, MaxLevel, "Bros.runmethod",	"(function (Application)"));
//		this.CompiledResult.push	(this.GetStatementToPush(0,  0, MaxLevel, "{",				""));
		this.CompiledResult.push	(this.GetStatementToPush(0,  0, MaxLevel, "Bros",			""));
		this.CompileBOM				(this.ProjectWindow);
		this.CompiledResult.push	(this.GetStatementToPush(0,  1, MaxLevel, ";",				""));
//		this.CompiledResult.push	(this.GetStatementToPush(0,  0, MaxLevel, "});",			""));
		this.CompiledResult.push	(this.GetStatementToPush(0,  0, MaxLevel, "",				""));	// Final blank line to facilitate copy-paste

		// Show Result (for Test)
		//	Bros.RW					(Result.join(""));
		//	Bros.RW					(this.CompiledResult.join("<br>"));
		//	Bros.RW					(this.CompiledResult.join(Bros.CRLF));
		};

	//---------------------------------------------------------------------------
	// Explore BOM
	//---------------------------------------------------------------------------
	//
	//this.ExploreBOM = function ExploreBOM(From)
	//	{
	//	//	deb						("CBrosAppBuilder.ExploreBOM", Bros.CElm.WhoAmI(From));
	//	if (! From)
	//		From					= Bros.MainElement;
	//	var Result					= [];
	//	Bros.ExploreBOM				(From, function OnExplore(Bobj, Index, Level)
	//		{
	//		var MaxLevel			= 10;
	//		var ToShow				= "";
	//		ToShow				   += Bros.Str_AlignRight(Index, 5);
	//		ToShow				   += Bros.Str_AlignRight(Level, 3) + " ";
	//		var LevelBar			= "";
	//		for (var i = 1; i <= Level; i++)
	//			LevelBar		   += "--";
	//		//	ToShow			   += LevelBar;
	//		ToShow				   += Bros.Str_AlignLeft (LevelBar, MaxLevel * 2) + " ";
	//		ToShow				   += Bros.CElm.WhoAmI(Bobj);
	//		ToShow				   += (Bobj.CreatedOnAppBuilder ? " CreatedOnAppBuilder" : "");
	//		//	deb					(ToShow);
	//		Result.push				(ToShow + "<br>");
	//		});
	//	return Result;
	//	};

	//---------------------------------------------------------------------------
	// Compile BOM
	//---------------------------------------------------------------------------
	//
	//this.CompileBOM = function CompileBOM(From)
	//	{
	//	//	deb						("CBrosAppBuilder.CompileBOM", Bros.CElm.WhoAmI(From));
	//	if (! From)
	//		From					= Bros.MainElement;
	//	var This					= this;
	//	var MaxLevel				= Bros.GetMaxLevelBOM(From);
	//	//	deb						("MaxLevel = " + MaxLevel);
	//	Bros.ExploreBOM				(From, function OnExplore(Bobj, Index, Level)
	//		{
	//		if (! Bobj.CreatedOnAppBuilder)
	//			return;
	//		This.AddElemStatement	(Bobj, Index, Level, MaxLevel);
	//		});
	//	};

	//---------------------------------------------------------------------------
	// Compile BOM
	//---------------------------------------------------------------------------

	this.CompileBOM = function CompileBOM(From)
		{
		//	deb						("CBrosAppBuilder.CompileBOM", Bros.CElm.WhoAmI(From));
		if (! From)
			From					= Bros.MainElement;
		var This					= this;
		var MaxLevel				= Bros.GetMaxLevelBOM(From);
		//	deb						("MaxLevel = " + MaxLevel);
		this.ExploreBOMFrom			(From, 0, 1, MaxLevel);
		};

	//---------------------------------------------------------------------------
	// Explore BOM - Bros Object Model from a starter element
	//---------------------------------------------------------------------------

	this.ExploreBOMFrom = function ExploreBOMFrom(Bobj, Index, Level, MaxLevel)
		{
		//	deb						("CBrosAppBuilder.ExploreBOMFrom", Index, Level, MaxLevel, Bros.CElm.WhoAmI(Bobj));
		Index++;

		// Add Element
		if (Bobj.CreatedOnAppBuilder)
			this.AddElemStatement	(Bobj, Index, Level, MaxLevel);

		// Stops now ?
		//if (! Bobj.CanHaveChilds)	// Switched to below to investigate objects with ParentUpOne (CanHaveChilds = false BUT have ChildElements)
		if (! Bobj.ChildElements)
			return Index;

		// Special cases that have ChildElements BUT have no parent()
		//	deb						(Bobj.Handler.ClassName);
		switch (Bobj.Handler.ClassName)
			{
			case "checkboxes":
			case "radiobuttons":
			case "mainmenu":
			case "slider":
			case "gauge":
				return Index;
			}

		// Reenter for ChildElements
		for (var i = 0; i < Bobj.ChildElements.length; i++)
			Index					= this.ExploreBOMFrom(Bobj.ChildElements[i], Index, Level + 1, MaxLevel);

		// Need Parent ?
		if (Bobj.CreatedOnAppBuilder)
			{
			//	deb					("CBrosAppBuilder.ExploreBOMFrom (ending)", Index, Level, MaxLevel, Bros.CElm.WhoAmI(Bobj));
			// BUG FIX to avoid double spacement after create window
			if (Level != 1)
				Level--;
			this.CompiledResult.push(this.GetStatementToPush(Index, Level + 1, MaxLevel, ".parent", "()"));	// Level + 1 instead of Level to be better aligned
			}

		return Index;
		};

	//---------------------------------------------------------------------------
	// Add Element Statement
	//---------------------------------------------------------------------------

	this.AddElemStatement = function AddElemStatement(Bobj, Index, Level, MaxLevel)
		{
		//	deb						("CBrosAppBuilder.AddElemStatement", Bros.CElm.WhoAmI(Bobj), Index, Level, MaxLevel);

		// BUG FIX to avoid double spacement after create window
		if (Level != 1)
			Level--;

		var Result					= this.CompiledResult;
		Result.push					(this.GetStatementToPush(Index, Level, MaxLevel, ".createelement",	"(\"" + Bobj.Handler.ClassName + "\")"));
		Level++;

		// Methods pre-set above
		var ArrToSkip				= ["left", "top", "width", "height"];

		// Special cases
		var SetLT					= ! false;
		var SetAlsoWH				= ! false;
		Bros.elementpush			();
		Bros.element				(Bobj);
		//
		var An_halign				= ! false;
		var An_valign				= ! false;
		switch (Bobj.Handler.ClassName)
			{
			case "label":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Lab);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"top");
				this.AnSpecialCase	(ArrToSkip, "autosize",		! false);
				if (Bros.autosize())
					SetAlsoWH		=   false;
				break;
			//
			case "image":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Img);
				break;
			//
			case "imagelabel":
				An_halign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Iml);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				if (Bros.autosize())
					SetAlsoWH		=   false;
				break;
			//
			case "button":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Btn);
				if (Bros.autosize())
					SetAlsoWH		=   false;
				break;
			//
			case "checkbox":
			case "radiobutton":
				An_halign			=   false;
				this.AnSpecialCase	(ArrToSkip, "borderstyle",	Bros.bsNone);
				this.AnSpecialCase	(ArrToSkip, "color",		Bros.Sysc.Prps_Btn.Color);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				if (Bros.autosize())
					SetAlsoWH		=   false;
				break;
			//
			case "panel":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Pan);
				break;
			//
			case "group":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Grp);
				break;
			//
			case "selector":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Sel);
				break;
			//
			case "checkboxes":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Cbs);
				this.AnSpecialCase	(ArrToSkip, "alignment",	"left");
				this.AnSpecialCase	(ArrToSkip, "scrollbars",	"both");
				this.AnSpecialCase	(ArrToSkip, "selectormode",	"button");
				break;
			//
			case "radiobuttons":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Cbs);
				this.AnSpecialCase	(ArrToSkip, "alignment",	"left");
				this.AnSpecialCase	(ArrToSkip, "scrollbars",	"both");
				this.AnSpecialCase	(ArrToSkip, "selectormode",	"button");
				break;
			//
			case "mainmenu":
				this.AnSpecialCase	(ArrToSkip, "borderstyle",	Bros.bsNone);
				this.AnSpecialCase	(ArrToSkip, "align",		"top");
				this.AnSpecialCase	(ArrToSkip, "selectormode",	"button");
				SetLT				=   false;
				break;
			//
			case "selectorpanels":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Spa);
				break;
			//
			case "editarea":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Eda);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"top");
				break;
			//
			case "edit":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Eda);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"middle");
				break;
			//
			case "editbutton":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Eda);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"middle");
				this.AnSpecialCase	(ArrToSkip, "imagewidth",	Bros.Sysc.Prps_Edb.Btn_ImageWidth);
				this.AnSpecialCase	(ArrToSkip, "imageheight",	Bros.Sysc.Prps_Edb.Btn_ImageHeight);
				break;
			//
			case "select":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Eda);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"middle");
			//	this.AnSpecialCase	(ArrToSkip, "imagewidth",	Bros.Sysc.Prps_Edb.Btn_ImageWidth);
			//	this.AnSpecialCase	(ArrToSkip, "imageheight",	Bros.Sysc.Prps_Edb.Btn_ImageHeight);
				ArrToSkip.push		("imagesrc");
				ArrToSkip.push		("imagewidth");
				ArrToSkip.push		("imageheight");
				break;
			//
			case "splitter":
			//	this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Spl);
				this.AnSpecialCase	(ArrToSkip, "borderstyle",	Bros.Sysc.Prps_Spl.BorderStyle_Spl_Ver);
				this.AnSpecialCase	(ArrToSkip, "minsize",		Bros.Sysc.Prps_Spl.MinSize);
				SetLT				=   false;
				switch (Bobj.Align)
					{
					case "top":
					case "bottom":
						Result.push	(this.GetStatementToPush(Index, Level, MaxLevel, ".height",			"(" + Bobj.Height + ")"));
						break;
					default:
						Result.push	(this.GetStatementToPush(Index, Level, MaxLevel, ".width",			"(" + Bobj.Width + ")"));
					}
				break;
			//
			case "tree":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Tre);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"top");
				this.AnSpecialCase	(ArrToSkip, "scrollbars",	"both");
				break;
			//
			case "table":
				An_halign			=   false;
				An_valign			=   false;
				this.AnSpecialCase	(ArrToSkip, "borderstyle",	Bros.Sysc.Prps_Sps.BorderStyle);
				this.AnSpecialCase	(ArrToSkip, "halign",		"left");
				this.AnSpecialCase	(ArrToSkip, "valign",		"top");
				break;
			//
			case "slider":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Sld);
				break;
			//
			case "gauge":
				this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Gau);
				break;
			//
			case "menu":
			//	this.AnSpecialCasesA(ArrToSkip, Bros.Sysc.Prps_Men);
				SetLT				=   false;
				break;
			//
			case "timer":
				SetLT				=   false;
				break;
			//
			case "tmeter":
				SetLT				=   false;
				break;
			//
			case "window":
				this.AnSpecialCase	(ArrToSkip, "borderstyle",	Bros.bsWindow);
				break;
			//
			//case "application":
			//	break;
			}
		if (An_halign)
			this.AnSpecialCase		(ArrToSkip, "halign",		"center");
		if (An_valign)
			this.AnSpecialCase		(ArrToSkip, "valign",		"middle");
		//
		Bros.elementpop				();

		// Sets Left, Top (and if SetAlsoWH: Width, Height)
		if (SetLT)
			{
			if (SetAlsoWH)
				Result.push			(this.GetStatementToPush(Index, Level, MaxLevel, ".left",			"(" + Bobj.Left + ", " + Bobj.Top + ", " + Bobj.Width + ", " + Bobj.Height + ")"));
			else
				Result.push			(this.GetStatementToPush(Index, Level, MaxLevel, ".left",			"(" + Bobj.Left + ", " + Bobj.Top + ")"));
			}

		// Gets the valid methods
		var BobjMethods				= Bros.GetValidMethods(Bobj.Handler.ClassName);
		//	deb						("BobjMethods.length = " + BobjMethods.length);

		// Sort (better not because, in compiled code the methods are sort by relevance)
		//Bros.Arr_Sort				(BobjMethods, function (a, b)
		//	{
		//	//	return   false;
		//	if (a.Type < b.Type)
		//		return  1;
		//	if (a.Type > b.Type)
		//		return -1;
		//	if (a.Name > b.Name)
		//		return  1;
		//	return -1;
		//	});

		// Sequence Methods (for elegance)
		var Sequence				= [
			 "name"		  			//	property
			,"caption"				//	property
		//	,"left"		  			//	property
		//	,"top"			  		//	property
		//	,"width"		  		//	property
		//	,"height"				//	property
			,"color"				//	property
			,"borderstyle"			//	property
			,"align"				//	property
			,"alignment"			//	property
			,"halign"				//	property
			,"valign"		  		//	property
		//	// Natural sequence
		//	,"apparguments"			//	property
		//	,"autosize"				//	property
		//	,"colcount"				//	property
		//	,"down"					//	property
		//	,"editable"				//	property
		//	,"enabled"				//	property
		//	,"fixedcols"			//	property
		//	,"fixedrows"			//	property
		//	,"font"					//	property
		//	,"goingdown"			//	property
		//	,"goingup"				//	property
		//	,"gradient"				//	property
		//	,"imagealignment"		//	property
		//	,"imageborder"	  		//	property
		//	,"imageheight"	  		//	property
		//	,"imagesrc"	  			//	property
		//	,"imagewidth"	  		//	property
		//	,"innerspacement"		//	property
		//	,"ispushpull"	  		//	property
		//	,"minsize"		  		//	property
		//	,"mode"		  			//	property
		//	,"movable"		  		//	property
		//	,"onclickon"	  		//	property
		//	,"opacity"		  		//	property
		//	,"orientation"	  		//	property
		//	,"outerspacement"		//	property
		//	,"pixelsoffset"  		//	property
		//	,"resizable"	  		//	property
		//	,"rowcount"	  			//	property
		//	,"scriptsrc"	  		//	property
		//	,"scrollbars"	  		//	property
		//	,"selectable"	  		//	property
		//	,"selectormode"  		//	property
		//	,"startmenu"	  		//	property
		//	,"text"		  			//	property
		//	,"value"		  		//	property
		//	,"visible"		  		//	property
		//	,"wraptext"	  			//	property
		//	// Not need 
		//	,"additem"				//	method
		//	,"animate"				//	method
		//	,"append"				//	method
		//	,"bottom"				//	method
		//	,"centralize"			//	method
		//	,"clientheight"			//	method
		//	,"clientwidth"			//	method
		//	,"close"				//	method
		//	,"collapse"				//	method
		//	,"collapseall"			//	method
		//	,"createelement"		//	method
		//	,"cssext"		 		//	method
		//	,"cssint"		 		//	method
		//	,"deb"			 		//	method
		//	,"deblaps"		 		//	method
		//	,"deletechildren"		//	method
		//	,"deleteelement" 		//	method
		//	,"deleteitem"	  		//	method
		//	,"deletetree"	  		//	method
		//	,"elapsed"		  		//	method
		//	,"element"		  		//	method
		//	,"elementpop"	  		//	method
		//	,"elementpush"	  		//	method
		//	,"expand"		  		//	method
		//	,"expandall"	  		//	method
		//	,"format"		  		//	method
		//	,"getappargs"	  		//	method
		//	,"html"		  			//	method
		//	,"item"		  			//	method
		//	,"lap"			  		//	method
		//	,"laps"		  			//	method
		//	,"maximize"	  			//	method
		//	,"minimize"	  			//	method
		//	,"panel"		  		//	method
		//	,"parent"		  		//	method
		//	,"parentitem"	  		//	method
		//	,"pause"		  		//	method
		//	,"popup"		  		//	method
		//	,"putontray"	  		//	method
		//	,"reload"		  		//	method
		//	,"removeelement" 		//	method
		//	,"restore"		  		//	method
		//	,"resume"		  		//	method
		//	,"right"		 		//	method
		//	,"rotate"		 		//	method
		//	,"selected"	 			//	method
		//	,"setfocus"	 			//	method
		//	,"start"		 		//	method
		//	,"stop"		 			//	method
		//	,"timeout"		 		//	method
		//	// Not need
		//	,"onchange"				//	event
		//	,"onclick"				//	event
		//	,"onclose"				//	event
		//	,"ongetappargs"			//	event
		//	,"onselect"				//	event
		//	,"ontimer"				//	event
			];

		// Sequence Methods (for elegance)
		for (var i = 0; i < Sequence.length; i++)
			{
			var Method_Name			= Sequence[i];
			this.AddElemStatementLoop(Bobj, Index, Level, MaxLevel, BobjMethods, ArrToSkip, Method_Name);
			ArrToSkip.push			(Method_Name);
			}

		// Add Default Itens (if is the case)
		//	PCS						(Bobj.Handler);
		if (Bobj.Handler.AppBuilderItemsToAdd)
			{
			for (var i = 0; i < Bobj.Handler.AppBuilderItemsToAdd.length; i++)
				{
				if (Bobj.Handler.AppBuilderItemsToAddPar)
					{
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, ".addparentitem",	"(\"" + Bobj.Handler.AppBuilderItemsToAdd[i] + "\")"));
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, "	.parentitem",	"()"));
					}
				else
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, ".additem",		"(\"" + Bobj.Handler.AppBuilderItemsToAdd[i] + "\")"));
				}
			}

		// Last round (for missed Method_Name's in Sequence)
		this.AddElemStatementLoop	 (Bobj, Index, Level, MaxLevel, BobjMethods, ArrToSkip, "*");

		// Loop Events (at last)
		for (var i = 0; i < BobjMethods.length; i++)
			{
			var Method				= BobjMethods[i];
			//	deb					(i, Method.Type, Method.Name);

			// Is Event ?
			if (Method.Type != "event")
				continue;

			this.DoAddElemEventStatement(Result, Bobj, Index, Level, MaxLevel, Method);
			}

		this.LastLevel				= Level;
		};

	//---------------------------------------------------------------------------
	// Analyze Special Cases Borderstyle and Color
	//---------------------------------------------------------------------------

	this.AnSpecialCasesA = function AnSpecialCasesA(ArrToSkip, Prps)
		{
		//	deb						("CBrosAppBuilder.AnSpecialCasesA")
		this.AnSpecialCase			(ArrToSkip, "borderstyle",	Prps.BorderStyle);
		this.AnSpecialCase			(ArrToSkip, "color",		Prps.Color);
		};

	//---------------------------------------------------------------------------
	// Analyze Special Case
	//---------------------------------------------------------------------------

	this.AnSpecialCase = function AnSpecialCase(ArrToSkip, PropName, DefPropValue, PropValue)
		{
		//	deb						("CBrosAppBuilder.AnSpecialCase", arguments.length, ArrToSkip.length, PropName, DefPropValue);	// , PropValue, (DefPropValue != PropValue)

		// Analyzes arguments.length
		if (arguments.length == 3)
			{
			PropValue				= Bros[PropName]();
			//	deb					("PropValue = " + PropValue);
			}
		//	deb						("PropValue = " + PropValue);

		// If current value is different, does nothing (the property will be add)
		//	if (DefPropValue != PropValue)
		//	deb						("FullCompare = " + Bros.Lib.Var.FullCompare(DefPropValue, PropValue));
		if (Bros.Lib.Var.FullCompare(DefPropValue, PropValue) != 0)
			return;
		// If current value is the same, pushes on ArrToSkip avoiding add
		ArrToSkip.push				(PropName);
		};

	//---------------------------------------------------------------------------
	// Add Element Statement Loop
	//---------------------------------------------------------------------------

	this.AddElemStatementLoop = function AddElemStatementLoop(Bobj, Index, Level, MaxLevel, BobjMethods, ArrToSkip, Method_Name)
		{
		//	deb						("CBrosAppBuilder.AddElemStatementLoop", Bros.CElm.WhoAmI(Bobj), Index, Level, MaxLevel);
		var Result					= this.CompiledResult;

		// Loop
		for (var i = 0; i < BobjMethods.length; i++)
			{
			var Method				= BobjMethods[i];
			//	deb					(i, Method.Type, Method.Name);

			// Method_Name ?
			if (Method_Name != "*")
				{
				if (Method_Name != Method.Name)
					continue;
				}

			// Is Event ?
			if (Method.Type == "event")
				continue;
			//if (Method.Type == "event")
			//	{
			//	this.DoAddElemEventStatement(Result, Bobj, Index, Level, MaxLevel, Method);
			//	continue;
			//	}

			// Apply ?
			if (! this.ElementInspector.DoInspectMethod(Bobj, Method))
				continue;
			//	deb					(i, Method.Type, Method.Name);

			// Pre-setted ?
			if (Bros.Arr_Have(ArrToSkip, Method.Name))
				continue;

			// Add (really) Element Statement
			this.DoAddElemStatement	(Result, Bobj, Index, Level, MaxLevel, Method);
			}
		};

	//---------------------------------------------------------------------------
	// Add Element Event Statement
	//---------------------------------------------------------------------------

	this.DoAddElemEventStatement = function DoAddElemEventStatement(Result, Bobj, Index, Level, MaxLevel, Method)
		{
		//	deb						("CBrosAppBuilder.DoAddElemEventStatement", Bros.CElm.WhoAmI(Bobj), Method.Name);
		var FuncParams;
		switch (Method.Name)
			{
			// Do not apply here
//			case "onover":
			case "ongetappargs":
			case "onload":
			case "onready":
			case "onresize":
			case "onhaveonclick":
			case "ondraw":
			case "onbeguin":
			case "onend":
			case "onkeydown":
			case "onkeypress":
			case "onkeyup":
				return;

			case "onchange":
			case "onclose":
			case "onfocus":
			case "ontimer":
				FuncParams			= "Elem";
				break;

			case "onclick":
				FuncParams			= "Elem, e";
				break;

			case "onselect":
				FuncParams			= "Elem, e, FromTo";
				break;

			default:
				Bros.FatalErrorMNO	("CBrosAppBuilder.DoAddElemEventStatement", "Invalid Method.Name [" + Method.Name + "].");
			}
		Result.push					(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name,														"(function (" + FuncParams + ") {"));
		Result.push					(this.GetStatementToPush(Index, Level, MaxLevel, "	// Put here your event handler script",								""));
		Result.push					(this.GetStatementToPush(Index, Level, MaxLevel, "	// deb(\"" + Bobj.Handler.ClassName + "." + Method.Name + "\");",	""));
		Result.push					(this.GetStatementToPush(Index, Level, MaxLevel, "	})",																""));
		};

	//---------------------------------------------------------------------------
	// Add (really) Element Statement
	//---------------------------------------------------------------------------

	this.DoAddElemStatement = function DoAddElemStatement(Result, Bobj, Index, Level, MaxLevel, Method)
		{
		//	deb						("CBrosAppBuilder.DoAddElemStatement", Bros.CElm.WhoAmI(Bobj), Method.Name);

		// Analize Method.VarType
		switch (Method.VarType)
			{
			case "B":				// Boolean
				if (Method.ApplyGetSet)
					{
					if (! Bobj[Method.PropName])
						break;
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "(" + Bobj[Method.PropName] + ")"));
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement (B)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			case "N":				// Number
				if (Method.ApplyGetSet)
					{
// SkipIfNegative
					if (Bobj[Method.PropName] == Method.UndefValue)
						break;
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "(" + Bobj[Method.PropName] + ")"));
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement (N)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			case "S":				// String
				//	PCS				(Method);
				//	PCS				(Bobj);
				if (Method.ApplyGetSet)
					{
					if (! Bobj[Method.PropName])
						break;
				//	if (Bobj[Method.PropName] == "")
				//		break;
					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "(\"" + Bobj[Method.PropName] + "\")"));
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement (S)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

// ELIMINATE
//			case "OS":				// Option
//				if (Method.ApplyGetSet)
//					{
//					if (! Bobj[Method.PropName])
//						break;
//				//	if (Bobj[Method.PropName] == "")
//				//		break;
//					Result.push		(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "(\"" + Bobj[Method.PropName] + "\")"));
//					break;
//					}
//				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement (OS)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
//				break;

			case "O":				// Options
				if (Method.ApplyGetSet)
					{
					//	if (! Bobj[Method.PropName])				// Cannot be used because 0 returns false but is not undefined
					//		break;
					if (Bros.VarIsUndefined(Bobj[Method.PropName]))
						break;

					// If equal also break;
					if (Bobj[Method.PropName] == Method.UndefValue)
						break;

					// Get's Option according Value and pushes as string or literal
					var Option		= this.CSlc_GetOption	(Method,	Method.Options,    (Bros.VarIsUndefined(Bobj[Method.PropName]) ? Method.UndefValue : Bobj[Method.PropName]) );
					//	var Option	= Bros.CSlc.GetOption	(			Method.Options, [,,(Bros.VarIsUndefined(Bobj[Method.PropName]) ? Method.UndefValue : Bobj[Method.PropName])]);
					//	deb			(Option[0], Bros.VarIsString(Option[2]), Option[2]);
					if (Bros.VarIsString(Option[2]))
						Result.push	(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "(\"" + Option[2] + "\")"));
					else
						Result.push	(this.GetStatementToPush(Index, Level, MaxLevel, "." + Method.Name, "("	  + Option[0] +   ")"));	// Option[0] will be a global var like Bros.ibNone for example
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement (O)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			default:
				Bros.FatalErrorMNO	("CBrosElementInspector.DoAddElemStatement", "Invalid Method.VarType.", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
			}
		};

	//---------------------------------------------------------------------------
	// CSlc_GetOption
	//---------------------------------------------------------------------------

	this.CSlc_GetOption = function CSlc_GetOption(Method, Options, Condition)
		{
		//	deb						("CBrosAppBuilder.CSlc_GetOption", Method.Name, Options.length, Condition, "Options = " + Options);
		//	deb						("Options[1]", Options[1]);
		var Option					= Bros.CSlc.FindOption(Options, [,,Condition]);
		if (Option != null)
			{
			//	deb					("Option found = " + Option);
			//	return [Bros.Lib.Var.ToScriptStr(Condition), , Condition];	// For Testing
			return Option;
			}
		//	Bros.FatalErrorMNO		("CBrosAppBuilder.CSlc_GetOption", "Option not found", "Options.length = " + Options.length, "Condition = " + Condition);
		// Simulate an Option (this situation occurs when user changes, for example, to style Windows XP and not find modified borderstyle.
		return [Bros.Lib.Var.ToScriptStr(Condition), , Condition];
		};

	//---------------------------------------------------------------------------
	// Returns statement line to push
	//---------------------------------------------------------------------------

	this.GetStatementToPush = function GetStatementToPush(Index, Level, MaxLevel, SttLeft, SttRight)
		{
		//	deb						("CBrosAppBuilder.DoAddElemStatement", Index, Level, MaxLevel, SttLeft, SttRight);
		var OffsetTabs				= 1;
		var TabPos					= OffsetTabs + MaxLevel + 4;	// "selectorpanels" have 14 so, 4 Tabs x 4 (TabSize) = 16
		if (TabPos					< 9)
			TabPos					= 9;							// Minimum set according my standard
		var TabSize					= 4;

		var Result					= "";
		Result					   += (new Array(Level + OffsetTabs + 1)).join("\t");			// + 1 is to force at least one join
		Result					   += SttLeft;
		Result						= Bros.Str_WrapTabs(Result, TabPos, SttRight, TabSize);
		return Result;
		};

	};	// function CBrosAppBuilder()

//###########################################################################
//###########################################################################
//##
//## Class BrosElementInspector
//##
//###########################################################################
//###########################################################################

function CBrosElementInspector()
	{
	//===========================================================================
	//===========================================================================
	//==
	//== Properties
	//==
	//===========================================================================
	//===========================================================================

		// To Store
		this.InspBobj				= null;

		// Aspect
		this.Panel_Butons_Height	=  47;

		// To Inspect
		this.Prop_Top_Start			=  10;
		this.Prop_Spacement			=  24;							// Was 25
		//
		this.Caption_Left			=  10;
		this.Value_Left				= 100;
		this.Distance_Left			=   7;
		this.Delta_Top				=   3;

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to build Inspector
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Setup Element Inspector
	//---------------------------------------------------------------------------

	this.Setup = function Setup(Bobj)		// Bobj is the element (usually a panel) to create Element Instector
		{
		//	deb						("CBrosElementInspector.Setup", Bros.CElm.WhoAmI(Bobj));

		//	Bros.bsEdit				= [	["808080"]	,	["808080"]	,	["FFFFFF"]	,	["FFFFFF"]	,		["404040"]	,	["404040"]	,	["D4D0C8"]	,	["D4D0C8"]	];
		var bsEdit_OnlyTop			= [	[]			,	["808080"]	,	[]			,	[]			,		[]			,	["404040"]	,	[]			,	[]			];

		var This					= this;
		Bros
			.element				(Bobj)
			.createelement			("panel")
				.borderstyle		(bsEdit_OnlyTop)
				.height				(this.Panel_Butons_Height)
				.align				("top")
				.createelement		("button")
					.left			(this.Caption_Left,	this.Prop_Top_Start)
					.caption		("Apply")
					.onclick		(function (Elem, e)
						{
						//	deb		("Apply");
						This.Apply	();
						})
				.createelement		("button")
					.name			("Button_Delete", this)
					.left			(this.Caption_Left + 210,	this.Prop_Top_Start)
					.caption		("Delete")
					.visible		(  false)
					.onclick		(function (Elem, e)
						{
						This.DeleteElement();
						})
				.createelement		("label")
					.left			(this.Value_Left,	this.Prop_Top_Start + 5)
					.name			("Label_Element", this)
					.caption		("")
				.parent				()
			.createelement			("panel")
				.name				("Panel_Inspector", this)
				.align				("client")
				.scrollbars			("both")
				.parent				()
			;
		};

	//---------------------------------------------------------------------------
	// Clear Inspector
	//---------------------------------------------------------------------------

	this.ClearInspector = function ClearInspector()
		{
		//	deb						("CBrosElementInspector.ClearInspector");
		Bros
			.element				(this.Button_Delete)
				.visible			(  false)
			.element				(this.Label_Element)
				.caption			("")
			.element				(this.Panel_Inspector)
// Delete elements ????
.html					("")
			;
		};

	//---------------------------------------------------------------------------
	// Delete an element
	//---------------------------------------------------------------------------

	this.DeleteElement = function DeleteElement()
		{
		//	deb						("CBrosElementInspector.DeleteElement", Bros.CElm.WhoAmI(this.InspBobj));

		// Delete
		Bros.element(this.InspBobj).deleteelement();

		// Clear Inspector
		this.ClearInspector			();
		};

	//---------------------------------------------------------------------------
	// Inspect an element
	//---------------------------------------------------------------------------

	this.Inspect = function Inspect(Bobj)
		{
		//	deb						("CBrosElementInspector.Inspect", Bros.CElm.WhoAmI(Bobj));
		// Runs propected because this method can be called without Run_Handler_Event protection
		try
			{
			this.DoInspect			(Bobj);
			}
		catch (Error)
			{
			Bros.FatalErrorMNO		("CBrosElementInspector.Inspect", Bros.CElm.WhoAmI(Bobj), Bros.GetErrorDescription(Error));
			}
		}

	//---------------------------------------------------------------------------
	// Inspect an element
	//---------------------------------------------------------------------------

	this.DoInspect = function DoInspect(Bobj)
		{
		//	deb						("CBrosElementInspector.DoInspect", Bros.CElm.WhoAmI(Bobj));
		//	PCS						(Bobj);

		// Adjust element to be Inspected (for example, if it is Panel_Bottom of a window, the element to be inspected is window instead of Panel_Bottom window)
		Bobj						= this.AdjustToBeInspected(Bobj);
		//	deb						("CBrosElementInspector.DoInspect (B)", Bros.CElm.WhoAmI(Bobj));

		// Store
		this.InspBobj				= Bobj;

		// Clear Inspector
		this.ClearInspector			();

		// Starting
		this.Prop_Top				= this.Prop_Top_Start - this.Prop_Spacement;	// - this.Prop_Spacement is because in BuildPropInspector it starts incrementing
		Bros
			.element				(this.Button_Delete)
				.visible			(! false)
			.element				(this.Label_Element)
				.caption			(Bobj.Handler.ClassName)
			;

		// Sets Panel_Inspector
		Bros.element				(this.Panel_Inspector);

		// Gets the valid methods
		this.InspBobj_Methods		= Bros.GetValidMethods(Bobj.Handler.ClassName);
		//	deb						("this.InspBobj_Methods.length = " + this.InspBobj_Methods.length);

		// Sort
		Bros.Arr_Sort				(this.InspBobj_Methods, function (a, b)
			{
			//	deb					(a.Type < b.Type, a.Type, b.Type, a.Name > b.Name, a.Name, b.Name);
			if (a.Type < b.Type)
				return  1;
			if (a.Type > b.Type)
				return -1;
			if (a.Name > b.Name)
				return  1;
			return -1;
			});

		// Loop
		for (var i = 0; i < this.InspBobj_Methods.length; i++)
			{
			var Method				= this.InspBobj_Methods[i];
			if (! this.DoInspectMethod(Bobj, Method))
				continue;
			//	deb					(i, Method.Type, Method.Name);

			// Build a Property to Inspect
			this.BuildPropInspector	(Bobj, Method);
			}
		};

	//---------------------------------------------------------------------------
	// Do Inspect Method ?
	//---------------------------------------------------------------------------

	this.DoInspectMethod = function DoInspectMethod(Bobj, Method)
		{
		//	deb						("CBrosElementInspector.DoInspectMethod", Bros.CElm.WhoAmI(Bobj), Method.Name);
		switch (Method.Type)
			{
			case "ClassDivisor":	return   false;
			case "property":		break;
			case "method":			return   false;
			case "event":			return   false;										// Not for a while
			default:
				Bros.FatalErrorMNO	("CBrosElementInspector.DoInspectMethod", "Invalid Method.Type.", "Method.Type = " + Method.Type, "Method.Name = " + Method.Name);
			}

		// Have VarType property ?
		//	PCS						(Method);
if (! Method.VarType)
	return false;

		// OK !
		return ! false;
		};

	//---------------------------------------------------------------------------
	// Adjust element to be Inspected (for example, if it is Panel_Bottom of a window, the element to be inspected is window instead of Panel_Bottom window)
	//---------------------------------------------------------------------------

	this.AdjustToBeInspected = function AdjustToBeInspected(Bobj)
		{
		//	deb						("CBrosElementInspector.AdjustToBeInspected", Bros.CElm.WhoAmI(Bobj), Bobj.ToBeInspected);
		if (Bobj.ToBeInspected)
			return Bobj.ToBeInspected;
		return Bobj;
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to apply Inspector
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Apply Inspector to element
	//---------------------------------------------------------------------------

	this.Apply = function Apply()
		{
		//	deb						("CBrosElementInspector.Apply", Bros.CElm.WhoAmI(this.InspBobj));

		// Exists ?
		if (this.InspBobj == null)
			return;

		// Restore
		Bobj						= this.InspBobj;

		// Loop
		for (var i = 0; i < this.InspBobj_Methods.length; i++)
			{
			var Method				= this.InspBobj_Methods[i];
			if (! this.DoInspectMethod(Bobj, Method))
				continue;
			//	deb					(i, Method.Type, Method.Name);

			// Apply an Inspected Property
			this.ApplyPropInspector	(Bobj, Method);
			}
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Methods putted together because they must be builded synchronously
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Build a Property to Inspect
	//---------------------------------------------------------------------------

	this.BuildPropInspector = function BuildPropInspector(Bobj, Method)
		{
		//	deb						("CBrosElementInspector.BuildPropInspector", Bros.CElm.WhoAmI(Bobj), Method.VarType);
		this.Prop_Top			   += this.Prop_Spacement;

		// Analize Method.VarType
		var BuildContainer			= ! false;
		var ToCreate				= "";
		var Value;
		var Caption;
// ELIMINATE
//var _Options;
		var Options;
		switch (Method.VarType)
			{
			case "B":				// Boolean
				ToCreate			= "checkbox";
				Caption				= "&nbsp;";
				//	PCS				(Method);
				if (Method.ApplyGetSet)
					{
					Value			= (Bobj[Method.PropName] ? 1 : 0);
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.BuildPropInspector (B)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			case "N":				// Number
			case "S":				// String
				ToCreate			= "edit";
				//	PCS				(Method);
				if (Method.ApplyGetSet)
					{
					Value			= "" + Bobj[Method.PropName];		// "" +  is in case of Number
					if (Value == "undefined")
						Value		= "";
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.BuildPropInspector (NS)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

// ELIMINATE
//			case "OS":				// _Options
//				ToCreate			= "select";
//				if (Method.ApplyGetSet)
//					{
//					//	PCS			(Method);
//					_Options		= Method.Options;
//					break;
//					}
//				Bros.FatalErrorMNO	("CBrosElementInspector.BuildPropInspector (OS)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
//				break;

			case "O":				// Options
				ToCreate			= "select";
				if (Method.ApplyGetSet)
					{
					//	PCS			(Method);
					Options			= Method.Options;
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.BuildPropInspector (O)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			default:
				BuildContainer		=   false;
				// If did not set (in methods module) does nothing
				if (Bros.VarIsUndefined(Method.VarType))
					break;
				Bros.FatalErrorMNO	("CBrosElementInspector.BuildPropInspector", "Invalid Method.VarType.", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
			}

		// Build
		Bros
			.createelement			("label")
				.autosize			(  false)
				.left				(this.Caption_Left, this.Prop_Top + this.Delta_Top)
				.width				(this.Value_Left - this.Caption_Left - this.Distance_Left)
				.halign				("right")
				.caption			(Method.Name)
				//	.color			("FF0000")
			;

		// BuildContainer ?
		if (! BuildContainer)
			return;

		// BuildContainer !
		Bros
			.createelement			(ToCreate)
				.left				(this.Value_Left,	this.Prop_Top)
				.onready			(function (Elem)
					{
					// Stores
					Method.AppB_Bobj= Elem;
					})
			;

		// Caption ?
		if (Caption)
			Bros.caption			(Caption);

		// Value ?
		if (Value)
			Bros.value				(Value);

// ELIMINATE
//		// _Options
//		if (_Options)
//			{
//			if (! Bobj[Method.PropName])
//				Bros.text			(_Options[0], "", _Options[0]);
//			else
//				Bros.text			(Bobj[Method.PropName]);
//			for (var i = 0; i < _Options.length; i++)
//				{
//				var Option			= _Options[i];
//				Bros.additem		(Option, "", Option);
//				}
//			var This				= this;
//			Bros.onchange			(function (Elem)
//				{
//				//	deb				("Apply");
//				This.Apply			();
//				})
//			}

		// Options
		if (Options)
			{
			//	PCS					(Bobj);
			//	PCS					(Method);
			//	if (Method.PropName == "Align")
			//		{
			//		deb				("<hr>");
			//		deb				("Method.PropName = "		+ Method.PropName);
			//		deb				("Bobj[Method.PropName] = "	+ Bobj[Method.PropName]);
			//		deb				("Method.UndefValue = "		+ Method.UndefValue);
			//		deb				("Options.length = "		+ Options.length);
			//		}
			//	deb					([,,(Bros.VarIsUndefined(Bobj[Method.PropName]) ? Method.UndefValue : Bobj[Method.PropName])]);
			var Option				= BrosAppBuilder.CSlc_GetOption(Method,	Options,	(Bros.VarIsUndefined(Bobj[Method.PropName]) ? Method.UndefValue : Bobj[Method.PropName]) );
			//	var Option			= Bros.CSlc.GetOption(					Options, [,,(Bros.VarIsUndefined(Bobj[Method.PropName]) ? Method.UndefValue : Bobj[Method.PropName])]);
			//	deb					("Found Option = [" + Option + "]");
			Bros.text				(Option[0]);
			// To avoid error in CBrosElementInspector.ApplyPropInspector when gets select value with no selection
			Bros.value				(Option[2]);
			for (var i = 0; i < Options.length; i++)
				{
				var Option			= Options[i];
				//	PCS				(Option);
				var ImgSrc			= "";
				if (Option[1] != "")
					ImgSrc			= Bros.URL_Path_Img_Bros_Sys + Option[1];
				Bros.additem		(Option[0], ImgSrc, Option[2]);
				}
			var This				= this;
			Bros.onchange			(function (Elem)
				{
				//	deb				("Apply");
				This.Apply			();
				})
			}
		};

	//---------------------------------------------------------------------------
	// Apply an Inspected Property
	//---------------------------------------------------------------------------

	this.ApplyPropInspector = function ApplyPropInspector(Bobj, Method)
		{
		//	deb						("CBrosElementInspector.ApplyPropInspector", Bros.CElm.WhoAmI(Bobj), Method.Name, Method.VarType);

		// Saves the current element
		Bros.elementpush			();

		// Analize Method.VarType
		switch (Method.VarType)
			{
			case "B":				// Boolean
				if (Method.ApplyGetSet)
					{
					var Value		= (Bros.element(Method.AppB_Bobj).value() == 1 ? true : false);
					Bros.element	(Bobj);
					Bros[Method.Name](Value);
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.ApplyPropInspector (B)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			case "N":				// Number
			case "S":				// String
				//	PCS				(Method);
				//	PCS				(Method.AppB_Bobj);
				if (Method.ApplyGetSet)
					{
					if (this.SkipApplyPropInspector(Bobj, Method))
						break;
					var Value		= Bros.element(Method.AppB_Bobj).value();
					if (Method.VarType == "N")
						Value		= Number(Value);
					//	PCS			(Method);
					//	deb			("Value = " + Value);
					Bros.element	(Bobj);
					Bros[Method.Name](Value);
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.ApplyPropInspector (NS)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

// ELIMINATE
//			case "OS":				// Options
//				if (Method.ApplyGetSet)
//					{
//					var Selected	= Bros.element(Method.AppB_Bobj).selected	();
//					var Value		= Bros.element(Method.AppB_Bobj).value		();
//					//	deb			("Selected = " + Selected, "Value = " + Value, "Method.Options.length = " + Method.Options.length);
//				//	// Discards Option Zero (default)
//				//	if (Selected <= 0)
//				//		break;
//					Bros.element	(Bobj);
//					Bros[Method.Name](Value);
//					break;
//					}
//				Bros.FatalErrorMNO	("CBrosElementInspector.ApplyPropInspector (OS)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
//				break;

			case "O":				// Options
				if (Method.ApplyGetSet)
					{
				//	var Selected	= Bros.element(Method.AppB_Bobj).selected	();
					var Value		= Bros.element(Method.AppB_Bobj).value		();
					//	deb			("Selected = " + Selected, "Value = " + Value, "Method.Options.length = " + Method.Options.length);
					//	if (Method.PropName == "Align")
					//	deb			("Value = " + Value);
				//	// Discards Option Zero (default)
				//	if (Selected <= 0)
				//		break;
					Bros.element	(Bobj);
					Bros[Method.Name](Value);
					break;
					}
				Bros.FatalErrorMNO	("CBrosElementInspector.ApplyPropInspector (O)", "(! Method.ApplyGetSet)", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
				break;

			default:
				// If did not set (in methods module) does nothing
				if (Bros.VarIsUndefined(Method.VarType))
					break;
				Bros.FatalErrorMNO	("CBrosElementInspector.ApplyPropInspector", "Invalid Method.VarType.", "Method.VarType = " + Method.VarType, "Method.Name = " + Method.Name);
			}

		// Restores the last element
		Bros.elementpop				();
		};

	//---------------------------------------------------------------------------
	// Skip Apply an Inspected Property ?
	//---------------------------------------------------------------------------

	this.SkipApplyPropInspector = function SkipApplyPropInspector(Bobj, Method)
		{
		//	deb						("CBrosElementInspector.SkipApplyPropInspector", Bros.CElm.WhoAmI(Bobj), Method.Name, Method.VarType);

		// Analyze case by case
		switch (Method.Name)
			{
			case "width":
				switch (Bobj.Handler.ClassName)
					{
					case "label":
					case "imagelabel":
					case "button":
					case "checkbox":
					case "radiobutton":
				//	case "application": // (???)
						if (Bobj.AutoSize)
							return ! false;
					}
				break;
			}

		// Do NOT skip to apply
		return false;
		};

	};	// function CBrosElementInspector()

//###########################################################################
//###########################################################################
