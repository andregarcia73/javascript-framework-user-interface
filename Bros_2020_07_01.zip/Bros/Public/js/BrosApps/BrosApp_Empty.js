		// This is an application example
		// 
		// To install this application:
		// 
		//		1) Save this file into some file
		//		2) Go to [My Computer] and add this Program
		//		3) Under the installed menu, runs it
		// 
		// So, you will can going modifying here and pressing Reload to see the results

		// Creates the Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// What to Build ?
		AppC.MainMenu.Build			= true;
		AppC.ButtonsPanel.Build		= true;
		AppC.StatusPanel.Build		= true;

		// Window Caption
		APPC.windowcaption			(AppC, "My Application");

		// Define IP (IP = ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_TextEditor/";

		// Define Here your Main Menu
		APPC.addmenufolder			(AppC, "Main");
			APPC.addmenufolder		(AppC, "File");
				APPC.addmenuitem	(AppC, "Open",		IP + "Img_0030_File_Open.png",		"Ctrl+O",	Menu_File_Open)				.Set("ShowButton", ! false);
				APPC.addmenuitem	(AppC, "Save As",	IP + "Img_0080_File_SaveAs.png",	"",			Menu_File_SaveAs)			.Set("ShowButton",   false);
				APPC.endmenufolder	(AppC);
			APPC.addmenuitem		(AppC, "Exit",		IP + "Img_0100_File_Exit.png",		"Alt+F4",	Menu_File_Exit)				.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.Tools);
			APPC.addmenuitemreload	(AppC);//.Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);

		// Define Here your Status Panel
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Now, everything will be created automatically for you
		APPC.createall				(AppC);

		// Create Here your application elements
		Bros
			.createelement			("editarea")
				.name				("MyEditArea")
				.align				("client")
				.mode				("codeeditor")
			;

		// This Method (Event indeed) will be called if this application is opened and you shut down and the returned value will be saved for the next sign-in
		APPC.ongetappargs(AppC, function ()
			{
			return "Something that make sense for this application";
			});

		// Here you will get the value saved in APPC.ongetappargs above and you can do something with the AppArgs
		var AppArgs					= APPC.getappargs(AppC);
		//	deb						("AppArgs = " + AppArgs);
		if (AppC.StatusPanel.Build)
			Bros.element("MyStatusPanelInfo").html("&nbsp;" + AppArgs);

	//---------------------------------------------------------------------------
	// Menu Methods
	//---------------------------------------------------------------------------

	function Menu_File_Open()
		{
		// Gets ths Name to Open
		Bros.lib.dlg.fileopen(function (ErrorMsg, FullFileName)
			{
			// Error occur ?
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			// User canceled ?
			if (FullFileName == "")
				return;

			// Reads
			Bros.lib.fs.read			(FullFileName, function (ErrorMsg, FileContent)
				{
				// Error occur ?
				if (Bros.lib.dlg.didshowerror(ErrorMsg))
					return;

				// Fills
				Bros.element			("MyEditArea").value(FileContent);
				});
			});
		}

	function Menu_File_SaveAs()
		{
		// Gets FileContent
		var FileContent					= Bros.element("MyEditArea").value();

		// Gets ths Name to Save As
		Bros.lib.dlg.filesave(function (ErrorMsg, FullFileName)
			{
			// Error occur ?
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			// User canceled ?
			if (FullFileName == "")
				return;

			// Writes
			Bros.lib.fs.write			(FullFileName, FileContent, function (ErrorMsg)
				{
				// Error occur ?
				if (Bros.lib.dlg.didshowerror(ErrorMsg))
					return;

				// Success
				Bros.lib.dlg.showmsg	("File Saved");
				});

			});
		}

	function Menu_File_Exit()
		{
		Bros.element(APPC.windowname(AppC)).close();
		}
