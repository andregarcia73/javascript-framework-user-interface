//###########################################################################
//###########################################################################
//##
//## Bros Application - All Tables
//##
//###########################################################################
//###########################################################################

		// Creates a new Data System Controller
		var DSys					= Bros.Lib.DSys.GetNew();

		// Creates and Build Main Elements of an Application Controller
		Bros.Lib.AppC.BuildMainElements(DSys.AppC);

		// Define BrosAppsTabsLib
		var BrosAppsTabsLib;

		var ObjectDescriptor		= Bros.Lib.Sys.GetNewObjectDescriptor();
		//	PCS						(ObjectDescriptor);
		ObjectDescriptor.FileName	= "BrosPublic:/js/BrosApps/BrosApp_TablesLib.js";
		ObjectDescriptor.ObjName	= "BrosAppsTabsLib";
		var MethodName				= "EditAllTables";
		var Arguments				= "People";
		Bros.Lib.Sys.RunObjMethod	(ObjectDescriptor, MethodName, Arguments, function ()
			{
			//	deb					("AAA");

			// Define BrosAppsTabsLib
			BrosAppsTabsLib			= ObjectDescriptor.Obj;
			//	PCS					(BrosAppsTabsLib);

			// Run All Tables App
			//	PCS					(ObjectDescriptor);
			//	PCS					(ObjectDescriptor.Obj);
			//	PCS					(ObjectDescriptor.Obj.Tables);
			RunAllTables			();
			});

	//---------------------------------------------------------------------------
	// Run All Tables App
	//---------------------------------------------------------------------------

	function RunAllTables()
		{
		//	deb						("RunAllTables");

		// Data Tables
		DTabs						= BrosAppsTabsLib.DTabs;
		//	deb						("DTabs.length = " + DTabs.length);

		// DTab Menu Items
		var DTab;
		//	deb						("DTabs.length = " + DTabs.length);
		for (var i = 0; i < DTabs.length; i++)
			{
			DTab					= DTabs[i];
			//	deb					(i, DTab.Caption);
			//	PCS					(DTab);

			// Adds a Menu Item type Query Table
			Bros.Lib.DSys.AddMenuItemQTab(DSys, DTab);
			}

		};

//###########################################################################
//###########################################################################
