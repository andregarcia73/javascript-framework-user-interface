//###########################################################################
//###########################################################################
//##
//## Bros Application - Calendar
//##
//###########################################################################
//###########################################################################

		//---------------------------------------------------------------------------
		// Globals
		//---------------------------------------------------------------------------

		var Window_WH				= [700, 500];

		var SkipOnDraw				=   false;
		var AddNoDates				=   false;
		//	SkipOnDraw				= ! false;
		//	AddNoDates				= ! false;

		// What To Show
		var Show_People				= ! false;
		var Show_Reminders			= ! false;
		//	Show_People				=   false;
		//	Show_Reminders			= ! false;

		var UpdateIsReady			=   false;

		var BrosAppsTabsLib			= null;
		var QTabs					= {};

		// General
		var Window_Caption			= Bros.Msg.CLD.Window_Caption;

		// Images
		var Image_Path				= "BrosPublic:/img/BrosApps/BrosApp_Calendar/";
		var ImageSrc_Insert			= GetImageSrc("Icon_Add.png");
		var ImageSrc_Reminders		= "BrosPublic:/img/Icons/_32/Icon_BrosApp_Reminders.png";
		var ImageSrc_People			= "BrosPublic:/img/Icons/_32/Icon_BrosApp_People.png";

		// Insert Menu
		var Insert_Menu				= null;
		var G_Year, G_Month, G_Day;

	//---------------------------------------------------------------------------
	// Get ImageSrc
	//---------------------------------------------------------------------------

	function GetImageSrc(ImageSrc)
		{
		//	deb						("Bros.Lib.QTab.GetImageSrc", "ImageSrc = " + ImageSrc);
		//	return this.ImageSrc_Path + ImageSrc;
		return Bros.FS.ImageSrc_Decode(Image_Path + ImageSrc);
		};


		// Calendar Preferences
		var CalPref					= {
			 Things_Color			: "FF0000"
			,Things_Color_OM		: "FF8080"
			}

		// Desktop Preferences
		var Color_Head				= "0181FF";
		var Color_Font				= "FFFFFF";
		//
		var C_Day_Cell				= "FFFFFF";
		var C_Day_Font				= "000000";
		//
		var C_DOM_Cell				= "D0D0D0";
		var C_DOM_Font				= "808080";
		//
		var Color_Border			= "0181FF";						// "A0A0A0"
		var Color_MouseOver			= "FFD700";
		//
		var FS						= 11;							// Font Size
		//
		var PREF					= {
			 BLANK					: Pref_What_GetNew("",			"",			10,	  false,   false,   false)	// 7 looses a litle bit alignment
			//
			,monthleft1				: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,monthleft2				: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,monthleft3				: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,month					: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,monthright3			: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,monthright2			: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,monthright1			: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			//
			,weekheader				: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,weekday				: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			,week					: Pref_What_GetNew(Color_Head,	Color_Font,	10,	  false,   false,   false)
			//
			,dayleft				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	10,	  false,   false,   false)
			,daycenter				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	10,	  false,   false,   false)
			,dayright				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	10,	  false,   false,   false)
			,daydata				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	10,	  false,   false,   false)
			//
			,dayleft_om				: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	10,	  false,   false,   false)
			,daycenter_om			: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	10,	  false,   false,   false)
			,dayright_om			: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	10,	  false,   false,   false)
			,daydata_om				: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	10,	  false,   false,   false)
			//
			,MONTHLEFT1				: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			,MONTHLEFT2				: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			,MONTHLEFT3				: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			,MONTH					: Pref_What_GetNew(Color_Head,	Color_Font,	18,	! false,   false,   false)
			,MONTHRIGHT3			: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			,MONTHRIGHT2			: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			,MONTHRIGHT1			: Pref_What_GetNew(Color_Head,	Color_Font,	13,	! false,   false,   false)
			//
			,WEEKHEADER				: Pref_What_GetNew(Color_Head,	Color_Font,	FS,	! false,   false,   false)
			,WEEKDAY				: Pref_What_GetNew(Color_Head,	Color_Font,	FS,	! false,   false,   false)
			,WEEK					: Pref_What_GetNew(Color_Head,	Color_Font,	FS,	! false,   false,   false)
			//
			,DAYLEFT				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYCENTER				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYRIGHT				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYDATA				: Pref_What_GetNew(C_Day_Cell,	C_Day_Font,	10,	! false,   false,   false)
			//
			,DAYLEFT_OM				: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYCENTER_OM			: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYRIGHT_OM			: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	FS,	! false,   false,   false)		// Was 18
			,DAYDATA_OM				: Pref_What_GetNew(C_DOM_Cell,	C_DOM_Font,	10,	! false,   false,   false)
			}

	//---------------------------------------------------------------------------
	// Get new Pref What
	//---------------------------------------------------------------------------

	function Pref_What_GetNew(Color, Font_Color, Font_Size, Font_Bold, Font_Italic, Font_Underline)
		{
		//	deb						("Pref_What_GetNew");
		return {
			 Color					: Color
			,Font					: {
				 Color				: Font_Color
				,Size				: Font_Size
				,Bold				: Font_Bold
				,Italic				: Font_Italic
				,Underline			: Font_Underline
				}
			};
		}

	//---------------------------------------------------------------------------
	// Preferences: Apply
	//---------------------------------------------------------------------------

	function Pref_Apply(Event, Pref_What)
		{
		//	deb						("Pref_Apply", Pref_What.Color);
		var Cell					= Event.Cell;					// For code elegance
		Cell.Color					= Pref_What.Color;
		Cell.Font.Color				= Pref_What.Font.Color;
		Cell.Font.Size				= Pref_What.Font.Size;
		Cell.Font.Bold				= Pref_What.Font.Bold;
		Cell.Font.Italic			= Pref_What.Font.Italic;
		Cell.Font.Underline			= Pref_What.Font.Underline;
		}

	//---------------------------------------------------------------------------
	// Main Call
	//---------------------------------------------------------------------------

		var MCLI;

		Calendar_Desktop			();

	//###########################################################################
	//###########################################################################
	//##
	//## Desktop Calendar
	//##
	//###########################################################################
	//###########################################################################

	function Calendar_Desktop()
		{

		//---------------------------------------------------------------------------
		// Globals
		//---------------------------------------------------------------------------

		//---------------------------------------------------------------------------
		// Application Controller
		//---------------------------------------------------------------------------

		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// Configure and create
		Config_AppC					();
		Create_Window				();

	//===========================================================================
	//===========================================================================
	//==
	//== Configuration Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Config AppC
	//---------------------------------------------------------------------------

	function Config_AppC()
		{
		//	deb						("Config_AppC");

		// Config
		//	AppC.Window.Build		=   false;
		AppC.MainMenu.Build			=   false;
		//	AppC.ButtonsPanel.Build	=   false;
		AppC.StatusPanel.Build		=   false;

		// Window
		AppC.Window.Caption			= Window_Caption;

		// Define IP (ImgPath)
		var IP						= "BrosPublic:/img/BrosApps/BrosApp_ImageViewer/";

		// MenuItems
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.Tools);
			if (Bros.IsInDebug)
				APPC.addmenuitemreload(AppC);//.Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Print,		IP + "Img_0060_File_Print.png",				"Ctrl+P",	Menu_File_Print)			.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", Bros.IsInDebug);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Exit,		IP + "Img_0070_File_Exit.png",				"Alt+F4",	Menu_File_Exit)				.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Creators Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Window
	//---------------------------------------------------------------------------

	function Create_Window()
		{
		//	deb						("Create_Window");
		APPC.createall				(AppC);
		Complement_MainWindow		();
		}

	//---------------------------------------------------------------------------
	// Complement Main Window
	//---------------------------------------------------------------------------

	function Complement_MainWindow()
		{
		//	deb						("Complement_MainWindow");

		Bros.element				(APPC.windowname(AppC))
				//	.width			(Window_WH)
				.onready			(function (Elem)
					{
					//	deb			("onready", Bros.CElm.WhoAmI(Elem));	// window
					//	PCS			(Elem);		// 600 x 400
					//	alert		("onready");
					Update			();
					})
				.onfocus			(function (Elem)
					{
					//	deb			("onfocus", Bros.CElm.WhoAmI(Elem));	// window
					// Update Calendar
					Update			();
					})
			;

		// Creates the Host Panel
		Bros.createelement			("panel")
				//	.name			("HostPanel")
				.align				("client")
				.borderstyle		(Bros.bsNone)
			;

		// Creates the Calendar Panel
		Bros.createelement			("panel")
				.name				("Panel_Calendar")
				.align				("client")
				//	.align			("top")
				//	.height			(300)
				.borderstyle		(Bros.bsNone)
			;

		// Creates the Calendar
		Bros.createelement			("calendar")
				.name				("MyCalendar")
				.align				("client")
				//	.width			(700, 450)
				//	.resizable		(! false)
				//	.borderstyle	(Bros.bsEdit)
				//	.color			("FF0000")								// If apply here, change PREF.blank and PREF.BLANK (above) with the same color
				//	.color			(Bros.clPanel)								// If apply here, change PREF.blank and PREF.BLANK (above) with the same color
				//
				//	.mode			("year")
				//	.mode			("smallmonth")
				//	.mode			("smallday")
				//	.mode			("month")
				//	.mode			("week")
				//	.mode			("day")
				.onready			(function (Elem)
					{
					//	deb			("onready", Bros.CElm.WhoAmI(Elem));	// calendar
					//	Elem.InitialDate			= new Date(2015, 8, 7, 0, 0, 0, 0);
					//	Elem.Pref.Show_SmallMonths	= ! false;
					//	Elem.Pref.Show_Weeks		= ! false;
					Elem.Color_Border = Color_Border;
					})
				.onbeguin			(function (Elem, Event)
					{
					//	deb			("onbeguin, Elem.Mode = " + Elem.Mode);
					//	PCS			(Event);
					//	PCS			(Event.Range);
					//	//	var	B	= C;							// To simulate error
					})
				.onend				(function (Elem, Event)
					{
					//	deb			("onend");
					//	PCS			(Event);
					//	Event.ContentArr.push("TEST");
					//	Event.ContentArr = [];
					//	Bros.Lib.Arr.ShowValues(Event.ContentArr);
					//	//	var	B	= C;							// To simulate error
					})
				.onhaveonclick		(function (Elem, Event)
					{
					//	deb			("onhaveonclick");
					//	PCS			(Event);
					//	Event.Prevent = ! false;
					//	//	var	B	= C;							// To simulate error
					})
				.onclick			(function (Elem, Event)
					{
					//	deb			("onclick");
					//	PCS			(Event);
					//	Event.Prevent = ! false;
					//	//	var	B	= C;							// To simulate error
					})
				.ondraw				(function (Elem, Event)
					{
					//	deb			("ondraw");
					//	PCS			(Event);
					//	//	var	B	= C;							// To simulate error
					if (SkipOnDraw)
						return;
					Handle_OnDraw	(Elem, Event);
					})
			//	.refresh			()
			;

		// Setup if is on mobile
		if (Bros.lib.sys.isonmobile())
			Bros.mode				("smallmonth");

		// Ends the Calendar Panel
		Bros.parent					();

		// Creates the People Panel
		Bros.createelement			("panel")
				.name				("Panel_People")
				.align				("client")
				.borderstyle		(Bros.bsNone)
				.visible			(false)
				.parent				()
			;

		// Creates the Reminders Panel
		Bros.createelement			("panel")
				.name				("Panel_Reminders")
				.align				("client")
				.borderstyle		(Bros.bsNone)
				.visible			(false)
				.parent				()
			;

		// Ends the Host Panel
		Bros.parent					();

		// Create Elements for Insert
		Insert_CreateElements		();

		// UpdateIsReady !
		UpdateIsReady				= ! false;
		Update						();
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Menu/Buttons Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_File_Print
	//---------------------------------------------------------------------------

	function Menu_File_Print()
		{
		//	deb						("Menu_File_Print");
		Bros.element				("MyCalendar").print();
		}

	//---------------------------------------------------------------------------
	// Menu_File_Exit
	//---------------------------------------------------------------------------

	function Menu_File_Exit()
		{
		//	deb						("Menu_File_Exit");
		Bros.element(APPC.windowname(AppC)).close();
		}

	};	// function Calendar_Desktop()

	//###########################################################################
	//###########################################################################

	//===========================================================================
	//===========================================================================
	//==
	//== Common Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Handle_OnDraw
	//---------------------------------------------------------------------------

	function Handle_OnDraw(Elem, Event)
		{
		//	deb						("Handle_OnDraw", Event.What);
		//	PCS						(Event);
		//	PCS						(Event.Cell);
		//	deb						(Event.Cell.Content);
		//	deb						(Bros.Lib.Var.GetTypeOf(Event.Cell.Content));
		//	return;
		//	Event.Cell.Content		= "<font color='0000FF'><b>" + Event.What + "</b></font><br>" + Event.Cell.Content.substr(1, 10000);
		//	Event.Cell.Content		= "<font color='0000FF'><b>" + Event.What + "</b></font><br>" + Event.Cell.Content;
		//	return;
		var IsSmall					= GetIsSmall(Elem);
		var Pref					= PREF;
		//	deb						("IsSmall = " + IsSmall);
		switch (Event.What)
			{
			case "BLANK":
				//	Pref_Apply		(Event, Pref.BLANK);
				break;

			case "MONTHLEFT1":
				Pref_Apply			(Event, IsSmall ? Pref.monthleft1	: Pref.MONTHLEFT1);
				break;

			case "MONTHLEFT2":
				Pref_Apply			(Event, IsSmall ? Pref.monthleft2	: Pref.MONTHLEFT2);
				break;

			case "MONTHLEFT3":
				Pref_Apply			(Event, IsSmall ? Pref.monthleft3	: Pref.MONTHLEFT3);
				break;

			case "MONTH":
				Pref_Apply			(Event, IsSmall ? Pref.month		: Pref.MONTH);
				break;

			case "MONTHRIGHT3":
				Pref_Apply			(Event, IsSmall ? Pref.monthright3	: Pref.MONTHRIGHT3);
				break;

			case "MONTHRIGHT2":
				Pref_Apply			(Event, IsSmall ? Pref.monthright2	: Pref.MONTHRIGHT2);
				break;

			case "MONTHRIGHT1":
				Pref_Apply			(Event, IsSmall ? Pref.monthright1	: Pref.MONTHRIGHT1);
				break;

			case "WEEKHEADER":
				Pref_Apply			(Event, IsSmall ? Pref.weekheader	: Pref.WEEKHEADER);
				break;

			case "WEEKDAY":
				Pref_Apply			(Event, IsSmall ? Pref.weekday		: Pref.WEEKDAY);
				break;

			case "WEEK":
				Pref_Apply			(Event, IsSmall ? Pref.week			: Pref.WEEK);
				break;

			case "DAYLEFT":
				if (! Event.DayIsOutOfMonth)
					Pref_Apply		(Event, IsSmall ? Pref.dayleft		: Pref.DAYLEFT);
				else
					Pref_Apply		(Event, IsSmall ? Pref.dayleft_om	: Pref.DAYLEFT_OM);
				if (IsSmall && OnDay_HaveThings(Event))
					Event.Cell.Color = (Event.DayIsOutOfMonth ? CalPref.Things_Color_OM : CalPref.Things_Color);
				break;

			case "DAYCENTER":
				if (! Event.DayIsOutOfMonth)
					Pref_Apply		(Event, IsSmall ? Pref.daycenter	: Pref.DAYCENTER);
				else
					Pref_Apply		(Event, IsSmall ? Pref.daycenter_om	: Pref.DAYCENTER_OM);
				break;

			case "DAYRIGHT":
				if (! Event.DayIsOutOfMonth)
					Pref_Apply		(Event, IsSmall ? Pref.dayright		: Pref.DAYRIGHT);
				else
					Pref_Apply		(Event, IsSmall ? Pref.dayright_om	: Pref.DAYRIGHT_OM);
				Insert_Build		(Event);
				break;

			case "DAYDATA":
				if (! Event.DayIsOutOfMonth)
					Pref_Apply		(Event, IsSmall ? Pref.daydata		: Pref.DAYDATA);
				else
					Pref_Apply		(Event, IsSmall ? Pref.daydata_om	: Pref.DAYDATA_OM);
				//if (Event.DayIsOutOfMonth)
				//	break;
				var Things			= OnDay_GetThings(Event);
				Event.Cell.Content	= Things;
				//Event.Cell.Color	= "FFFF00";
				break;

			default:
				Bros.FatalErrorMNO	("BrosApp_Calendar.Handle_OnDraw (OnDraw)", "Invalid Event.What [" + Event.What + "].");
			}
		}

	//---------------------------------------------------------------------------
	// Get Is Small callendar (year, smallmonth of smallday)
	//---------------------------------------------------------------------------

	function GetIsSmall(Elem)
		{
		//	deb						("GetIsSmall", Elem.Mode);
		switch (Elem.Mode)
			{
			case "year":			return ! false;
			case "smallmonth":		return ! false;
			case "smallday":		return ! false;
			case "month":			return   false;
			case "week":			return   false;
			case "day":				return   false;
			default:
				Bros.FatalErrorMNO	("BrosApp_Calendar.GetIsSmall", "Invalid Elem.Mode [" + Elem.Mode + "].");
			}
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Calendar Event Handler Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Update Calendar
	//---------------------------------------------------------------------------

	function Update()
		{
		//	deb						("Update");
		//	Bros.element("MyCalendar").refresh();
		//	return;

		// Is Ready for Update ?
		if (! UpdateIsReady)
			return;

		//	var RangeDates			= Bros.element("MyCalendar").range();
		//	deb						("RangeDates.Min = " + Bros.Lib.Date.ToStr(RangeDates.Min, "%dd/%mm/%yyyy %hh:%nn:%ss:%iii"));
		//	deb						("RangeDates.Max = " + Bros.Lib.Date.ToStr(RangeDates.Max, "%dd/%mm/%yyyy %hh:%nn:%ss:%iii"));
		//	PCS						(RangeDates);
		//	PCS						(Bros.Cobj);

		var ObjectDescriptor		= Bros.Lib.DSys.ObjDescr_BrosAppsTabsLib;
		//	PCS						(ObjectDescriptor);

		// Reload Table: People
		Bros.Lib.Sys.RunObjMethod	(ObjectDescriptor, "ReloadTable", "People", function (ErrorMsg)
			{
			//	deb					("ReloadTable, ErrorMsg = " + ErrorMsg);
			//	PCS					(ObjectDescriptor);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				{
				Bros.element("MyCalendar").refresh();
				return;
				}

			// Define BrosAppsTabsLib
			BrosAppsTabsLib			= ObjectDescriptor.Obj;

			// Reload Table: Reminders
			Bros.Lib.Sys.RunObjMethod(ObjectDescriptor, "ReloadTable", "Reminders", function (ErrorMsg)
				{
				//	deb				("ReloadTable, ErrorMsg = " + ErrorMsg);
				if (Bros.lib.dlg.didshowerror(ErrorMsg))
					{
					Bros.element("MyCalendar").refresh();
					return;
					}

			// No longer sorting here !
			//	// Sort by TIMEBEGUIN
			//	var DTab			= BrosAppsTabsLib.GetTable("Reminders");
			//	//	PCS				(DTab);
			//	//	PCS				(Bros.Lib.DTab);
			//	var SortCount		= 1;
			//	Bros.Lib.DTab.SortRecords	(DTab, function (Reco_A, Reco_B)
			//		{
			//		//	deb			("Bros.Lib.QTab.SortRecords", SortCount++, Reco_A.ID, Reco_B.ID);
			//		//	PCS			(Reco_A);
			//		var StrA		= Bros.Lib.UDate.ToStr(Reco_A.TIMEBEGUIN, "%hh:%nn");
			//		var StrB		= Bros.Lib.UDate.ToStr(Reco_B.TIMEBEGUIN, "%hh:%nn");
			//		//	deb			(StrA, StrB);
			//		if (StrA == StrB)
			//			return 0;
			//		if (StrA >  StrB)
			//			return 1;
			//		return -1;
			//		});
					
				// Refresh
				Bros.element("MyCalendar").refresh();
				});

			});

		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Record belong to the ColName ?
	//---------------------------------------------------------------------------

	function Reco_RecoBelong(Event, Reco, ColName, TableName)
		{
		//	deb						("Reco_RecoBelong", "Event.DayDate = " + Bros.Lib.UDate.ToStr(Event.DayDate, "%dd/%mm/%yyyy"), TableName);
		//	PCS						(Event);
		//	PCS						(Reco);
		//	Bros.FatalErrorMNO		("Reco_RecoBelong", "Stop For Testing");
		//	return false;

		// Record Enabled ?
		if (Reco.ENBD != "S")
			return false;

		// Reminders ?
		if (TableName == "Reminders")
			return Reminders_Reco_RecoBelong(Event, Reco, ColName, TableName);

	// XPTUTCDATE
	//	if (Reco[ColName].getDate () != Event.DayDate.getDate ())
	//		return false;
	//	if (Reco[ColName].getMonth() != Event.DayDate.getMonth())
	//		return false;
	//	if (Bros.Lib.Date.IsUndefinedDate(Reco[ColName]))
	//		return AddNoDates;
	// XPTUTCDATE
		if (Bros.Lib.UDate.GetDay	(Reco[ColName]) != Bros.Lib.UDate.GetDay	(Event.DayDate))
			return false;
		if (Bros.Lib.UDate.GetMonth	(Reco[ColName]) != Bros.Lib.UDate.GetMonth	(Event.DayDate))
			return false;
		if (Bros.Lib.UDate.IsUndefinedDate(Reco[ColName]))
			return AddNoDates;

		return true;
		};

	//---------------------------------------------------------------------------
	// Record belong to the ColName ?
	//---------------------------------------------------------------------------

	function Reminders_Reco_RecoBelong(Event, Reco, ColName, TableName)
		{
		//	deb						("Reminders_Reco_RecoBelong", Reco.IDREMTYPE, "Event.DayDate = " + Bros.Lib.UDate.ToStr(Event.DayDate, Bros.Lib.UDate.DebugFormat), TableName);
		//	PCS						(Event);
		//	PCS						(Reco);
		//	Bros.FatalErrorMNO		("Reminders_Reco_RecoBelong", "Stop For Testing");
		//	return false;

		// Past Date ?
		if (Bros.Lib.UDate.Compare(Event.DayDate, Reco.DATEBEGUIN) < 0)
			return false;

		// According Reminder Type
		switch (Reco.IDREMTYPE)
			{
			case BrosAppsTabsLib.IDREMTYPE_OneTimeOnly:				// One time only
				return (Bros.Lib.UDate.Compare(Event.DayDate, Reco.DATEBEGUIN) == 0);

		//	case BrosAppsTabsLib.IDREMTYPE_Dayly:					// Dayly
		//		break;

			case BrosAppsTabsLib.IDREMTYPE_Weekly:					// Weekly
				//	PCS				(Event);
				//	deb				(Event.DayDate, Bros.Lib.UDate.ToStr(Event.DayDate), Bros.Lib.UDate.GetDayOfWeek(Event.DayDate));

				// Future Date ?
				if (Bros.Lib.UDate.Compare(Event.DayDate, Reco.DATEEND) > 0)
					return false;

				// On which weeks ?
				//	deb				(Reco.IDWEEKS, BrosAppsTabsLib.IDWEEKS_OnAllMonthWeeks);
				var Week;
				if (Reco.IDWEEKS != BrosAppsTabsLib.IDWEEKS_OnAllMonthWeeks)			// To save time when not needing to calculate
					Week			= Bros.Lib.UDate.GetMonthWeek(Event.DayDate);
				//	PCS				(Week);
				switch (Reco.IDWEEKS)
					{
					case BrosAppsTabsLib.IDWEEKS_OnAllMonthWeeks:
						break;
					case BrosAppsTabsLib.IDWEEKS_On1stMonthWeeks:
						if (Week.Num != 1)
							return false;
						break;
					case BrosAppsTabsLib.IDWEEKS_On2ndMonthWeeks:
						if (Week.Num != 2)
							return false;
						break;
					case BrosAppsTabsLib.IDWEEKS_On3rdMonthWeeks:
						if (Week.Num != 3)
							return false;
						break;
					case BrosAppsTabsLib.IDWEEKS_On4rtMonthWeeks:
						if (Week.Num != 4)
							return false;
						break;
					case BrosAppsTabsLib.IDWEEKS_OnLastMonthWeeks:
						if (! Week.IsLast)
							return false;
						break;
					default:
						Bros.FatalErrorMNO("Reminders_Reco_RecoBelong", "Invalid Reco.IDWEEKS [" + Reco.IDWEEKS + "].");
					}

				// Enabled ?
				switch (Bros.Lib.UDate.GetDayOfWeek(Event.DayDate))
					{
					case 0:			// Sun
						return (Bros.Lib.UDate.ToStr(Reco.SUNTIMEBEG, "%hh:%nn") != "??:??");
					case 1:			// Mon
						return (Bros.Lib.UDate.ToStr(Reco.MONTIMEBEG, "%hh:%nn") != "??:??");
					case 2:			// Tue
						return (Bros.Lib.UDate.ToStr(Reco.TUETIMEBEG, "%hh:%nn") != "??:??");
					case 3:			// Wed
						return (Bros.Lib.UDate.ToStr(Reco.WEDTIMEBEG, "%hh:%nn") != "??:??");
					case 4:			// Thu
						return (Bros.Lib.UDate.ToStr(Reco.THUTIMEBEG, "%hh:%nn") != "??:??");
					case 5:			// Fri
						return (Bros.Lib.UDate.ToStr(Reco.FRITIMEBEG, "%hh:%nn") != "??:??");
					case 6:			// Sat
						return (Bros.Lib.UDate.ToStr(Reco.SATTIMEBEG, "%hh:%nn") != "??:??");
					}
				return false;

			case BrosAppsTabsLib.IDREMTYPE_Monthly:					// Monthly
				//	deb				((Bros.Lib.UDate.GetDay(Event.DayDate) == Reco.IDMONTHDAY), Bros.Lib.UDate.GetDay(Event.DayDate), Reco.IDMONTHDAY);

				// Future Date ?
				if (Bros.Lib.UDate.Compare(Event.DayDate, Reco.DATEEND) > 0)
					return false;

				return (Bros.Lib.UDate.GetDay(Event.DayDate) == Reco.IDMONTHDAY);

			default:
				Bros.FatalErrorMNO	("Reminders_Reco_RecoBelong", "Invalid Reco.IDREMTYPE [" + Reco.IDREMTYPE + "].");
			}
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Small Calendar Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// OnDay_HaveThings
	//---------------------------------------------------------------------------

	function OnDay_HaveThings(Event)
		{
		//	deb						("OnDay_HaveThings", Event.Name);
		if (Show_People)
			{
			if (Do_OnDay_HaveThings	(Event, "People",		"BIRTHDAY"))
				return true;
			}
		if (Show_Reminders)
			{
			if (Do_OnDay_HaveThings	(Event, "Reminders",	"DATEREMIND"))
				return true;
			}

		return false;
		}

	//---------------------------------------------------------------------------
	// Do_OnDay_HaveThings
	//---------------------------------------------------------------------------

	function Do_OnDay_HaveThings(Event, TableName, ColName_Date)
		{
		//	deb						("Do_OnDay_HaveThings", TableName, ColName_Date);
		//	return;
		//	return false;

		// Exists ?
		if (BrosAppsTabsLib == null)
			return false;

		var DTab					= BrosAppsTabsLib.GetTable(TableName);
		//	PCS						(DTab);

		// Loop on Records
		var RecordsCount			= Bros.Lib.DTab.GetRecordsCount(DTab);
		//	deb						("RecordsCount = " + RecordsCount);
		//	return;
		var Reco;
		for (var i = 0; i < RecordsCount; i++)
			{
			Reco					= Bros.Lib.DTab.GetRecordByIndex(DTab, i);
			if (Reco_RecoBelong(Event, Reco, ColName_Date, TableName))
				return ! false;
			}
		return false;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Big Calendar Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// OnDay_GetThings
	//---------------------------------------------------------------------------

	function OnDay_GetThings(Event)
		{
		//	deb						("OnDay_GetThings");

		// Push Things
		var Result					= [];
		if (Show_People)
			OnDay_PushThings		(Event, Result, "People",		"BIRTHDAY",		"NAME");
		if (Show_Reminders)
			OnDay_PushThings_Rem	(Event, Result, "Reminders",	"DATEREMIND",	"DESCR");

		// Something ?
		if (Result.length == 0)
			return "";

		// Encapsulates in a table
		var ToShow					= [];
		ToShow.push					("<table border=0>");
		ToShow.push					(Result.join(""));
		ToShow.push					("</table>");

		// Return to Show !
		return ToShow.join("");
		}

	//---------------------------------------------------------------------------
	// OnDay_PushThings
	//---------------------------------------------------------------------------

	function OnDay_PushThings(Event, Result, TableName, ColName_Date, ColName_ToShow)
		{
		//	deb						("OnDay_PushThings", TableName, ColName_Date, ColName_ToShow);
		//	PCS						(Event);
		//	return;

		// Exists ?
		if (BrosAppsTabsLib == null)
			return;

		var DTab					= BrosAppsTabsLib.GetTable(TableName);
		//	PCS						(DTab);

		// Create QTab
		var QTab					= Create_QTab(DTab, TableName);

		// Loop on Records
		var RecordsCount			= Bros.Lib.DTab.GetRecordsCount(DTab);
		//	deb						("RecordsCount = " + RecordsCount);
		//	return;
		var Reco;
		for (var i = 0; i < RecordsCount; i++)
			{
			Reco					= Bros.Lib.DTab.GetRecordByIndex(DTab, i);
			if (! Reco_RecoBelong(Event, Reco, ColName_Date, TableName))
				continue;
			//	PCS					(Reco);

			// Get the Style
			//	PCS					(Reco.Reco.IDRELEVANC.Reco.IDFONT);
			var TDEvent				= {
				 ComplementStyle	: ""
				};
			//	BrosAppsTabsLib.OnDrawTD(TDEvent, Reco.Reco.IDRELEVANC.Reco.IDFONT);
			// TypeError: Reco.Reco.IDRELEVANC is null can be null in case of data corruption
			BrosAppsTabsLib.OnDrawTD(TDEvent, (Reco.Reco.IDRELEVANC == null ? Reco.Reco.IDRELEVANC : Reco.Reco.IDRELEVANC.Reco.IDFONT));
			//	deb					(TDEvent.ComplementStyle);

			// Push
			Result.push				("<tr>");
			//
			//	Result.push			("<td " + Bros.Lib.CSS.GetStyleTag(TDEvent.ComplementStyle) + " style='width:1;' >");
			Result.push				("<td style='width:1;' >");
			Result.push				("<img src='" + DTab.ImageSrc + "'");
			Result.push				(" style='");
			Result.push				(" width:" + Bros.ApplyZoom(16) + ";");
			Result.push				("' >");
			Result.push				("</td>");
			//
			Result.push				("<td " + Bros.Lib.CSS.GetStyleTag(TDEvent.ComplementStyle) + " >");
			var ToShow				= "";
			ToShow				   += Reco[ColName_ToShow];
			Result.push				(BrosAppsTabsLib.GetLink(QTab, Reco.ID, ToShow));
			Result.push				("</td>");
			//
			Result.push				("</tr>");
			}
		}

	//---------------------------------------------------------------------------
	// OnDay_PushThings_Rem (Reminders)
	//---------------------------------------------------------------------------

	function OnDay_PushThings_Rem(Event, Result, TableName, ColName_Date, ColName_ToShow)
		{
		//	deb						("OnDay_PushThings_Rem", TableName, ColName_Date, ColName_ToShow);
		//	PCS						(Event);
		//	return;

		// Exists ?
		if (BrosAppsTabsLib == null)
			return;

		var DTab					= BrosAppsTabsLib.GetTable(TableName);
		//	PCS						(DTab);

		// Create QTab
		var QTab					= Create_QTab(DTab, TableName);

		// Loop on Records
		var SelRecos				= [];
		var RecordsCount			= Bros.Lib.DTab.GetRecordsCount(DTab);
		//	deb						("RecordsCount = " + RecordsCount);
		//	return;
		var Reco;
		for (var i = 0; i < RecordsCount; i++)
			{
			Reco					= Bros.Lib.DTab.GetRecordByIndex(DTab, i);
			if (! Reco_RecoBelong(Event, Reco, ColName_Date, TableName))
				continue;
			//	PCS					(Reco);
			SelRecos.push			(Reco);
			}

		// Sort SelRecos
		var SortCount				= 1;
		Bros.Arr_Sort				(SelRecos, function (Reco_A, Reco_B)
			{
			var Temp_A				= GetReminderToSort(Event, Reco_A);
			var Temp_B				= GetReminderToSort(Event, Reco_B);
			//	deb					("Arr_Sort", SortCount++, Temp_A, Temp_B);
			//	deb					(a.Type < b.Type, a.Type, b.Type, a.Name > b.Name, a.Name, b.Name);
			if (Temp_A > Temp_B)
				return  1;
			if (Temp_A < Temp_B)
				return -1;
			return 0;
			});

		// Loop on SelRecos
		//	deb						("SelRecos.length = " + SelRecos.length);
		for (var i = 0; i < SelRecos.length; i++)
			{
			Reco					= SelRecos[i];

			// Get the Style
			//	PCS					(Reco.Reco.IDRELEVANC.Reco.IDFONT);
			var TDEvent				= {
				 ComplementStyle	: ""
				};
			//	BrosAppsTabsLib.OnDrawTD(TDEvent, Reco.Reco.IDRELEVANC.Reco.IDFONT);
			// TypeError: Reco.Reco.IDRELEVANC is null can be null in case of data corruption
			BrosAppsTabsLib.OnDrawTD(TDEvent, (Reco.Reco.IDRELEVANC == null ? Reco.Reco.IDRELEVANC : Reco.Reco.IDRELEVANC.Reco.IDFONT));
			//	deb					(TDEvent.ComplementStyle);

			// Push
			Result.push				("<tr>");
			//
			//	Result.push			("<td " + Bros.Lib.CSS.GetStyleTag(TDEvent.ComplementStyle) + " style='width:1;' >");
			Result.push				("<td style='width:1;' >");
			Result.push				("<img src='" + DTab.ImageSrc + "'");
			Result.push				(" style='");
			Result.push				(" width:" + Bros.ApplyZoom(16) + ";");
			Result.push				("' >");
			Result.push				("</td>");
			//
			Result.push				("<td " + Bros.Lib.CSS.GetStyleTag(TDEvent.ComplementStyle) + " >");
			var ToShow				= "";
			//
			switch (Reco.IDREMTYPE)
				{
				case BrosAppsTabsLib.IDREMTYPE_OneTimeOnly:			// One time only
					ToShow		   += GetRemFromTo(Reco.ONETIMEBEG, Reco.ONETIMEEND);
					break;
			//	case BrosAppsTabsLib.IDREMTYPE_Dayly:				// Dayly
			//		break;
				case BrosAppsTabsLib.IDREMTYPE_Weekly:				// Weekly
					//	PCS			(Event);
					//	deb			(Event.DayDate, Bros.Lib.UDate.ToStr(Event.DayDate), Bros.Lib.UDate.GetDayOfWeek(Event.DayDate));
					switch (Bros.Lib.UDate.GetDayOfWeek(Event.DayDate))
						{
						case 0:		// Sun
							ToShow += GetRemFromTo(Reco.SUNTIMEBEG, Reco.SUNTIMEEND);
							break;
						case 1:		// Mon
							ToShow += GetRemFromTo(Reco.MONTIMEBEG, Reco.MONTIMEEND);
							break;
						case 2:		// Tue
							ToShow += GetRemFromTo(Reco.TUETIMEBEG, Reco.TUETIMEEND);
							break;
						case 3:		// Wed
							ToShow += GetRemFromTo(Reco.WEDTIMEBEG, Reco.WEDTIMEEND);
							break;
						case 4:		// Thu
							ToShow += GetRemFromTo(Reco.THUTIMEBEG, Reco.THUTIMEEND);
							break;
						case 5:		// Fri
							ToShow += GetRemFromTo(Reco.FRITIMEBEG, Reco.FRITIMEEND);
							break;
						default:	// Sat
							ToShow += GetRemFromTo(Reco.SATTIMEBEG, Reco.SATTIMEEND);
							break;
						}
					break;
				case BrosAppsTabsLib.IDREMTYPE_Monthly:				// Monthly
					ToShow		   += GetRemFromTo(Reco.MNTTIMEBEG, Reco.MNTTIMEEND);
					break;
				default:
					Bros.FatalErrorMNO("OnDay_PushThings_Rem", "Invalid Reco.IDREMTYPE [" + Reco.IDREMTYPE + "].");
				}
			//
			if (ToShow != "")
				ToShow			   += " ";
			ToShow				   += Reco[ColName_ToShow];
			Result.push				(BrosAppsTabsLib.GetLink(QTab, Reco.ID, ToShow));
			Result.push				("</td>");
			//
			Result.push				("</tr>");
			}
		}

	//---------------------------------------------------------------------------
	// Get Reminder ToSort
	//---------------------------------------------------------------------------

	function GetReminderToSort(Event, Reco)
		{
		//	deb						("GetReminderToSort", Reco.IDREMTYPE);
		//	PCS						(Reco);
		var TempDate;
		switch (Reco.IDREMTYPE)
			{
			case BrosAppsTabsLib.IDREMTYPE_OneTimeOnly:				// One time only
				TempDate			= Reco.ONETIMEBEG;
				break;

		//	case BrosAppsTabsLib.IDREMTYPE_Dayly:					// Dayly
		//		break;

			case BrosAppsTabsLib.IDREMTYPE_Weekly:					// Weekly
				//	PCS				(Event);
				//	deb				(Event.DayDate, Bros.Lib.UDate.ToStr(Event.DayDate), Bros.Lib.UDate.GetDayOfWeek(Event.DayDate));
				switch (Bros.Lib.UDate.GetDayOfWeek(Event.DayDate))
					{
					case 0:			// Sun
						TempDate	= Reco.SUNTIMEBEG;
						break;
					case 1:			// Mon
						TempDate	= Reco.MONTIMEBEG;
						break;
					case 2:			// Tue
						TempDate	= Reco.TUETIMEBEG;
						break;
					case 3:			// Wed
						TempDate	= Reco.WEDTIMEBEG;
						break;
					case 4:			// Thu
						TempDate	= Reco.THUTIMEBEG;
						break;
					case 5:			// Fri
						TempDate	= Reco.FRITIMEBEG;
						break;
					default:		// Sat
						TempDate	= Reco.SATTIMEBEG;
						break;
					}
				break;

			case BrosAppsTabsLib.IDREMTYPE_Monthly:					// Monthly
				TempDate			= Reco.MNTTIMEBEG;
				break;

			default:
				Bros.FatalErrorMNO	("GetReminderToSort", "Invalid Reco.IDREMTYPE [" + Reco.IDREMTYPE + "].");
			}

		//	return Bros.Lib.UDate.ToStr(TempDate, "%hh:%nn");
		var Result					= Bros.Lib.UDate.ToStr(TempDate, "%hh:%nn");
		if (Result == "??:??")
			Result					= "     ";
		return Result;
		};

	//---------------------------------------------------------------------------
	// Get Reminder From-To
	//---------------------------------------------------------------------------

	function GetRemFromTo(From, To)
		{
		//	deb						("GetRemFromTo", From, To);
		var Temp					= Bros.Lib.UDate.ToStr(From, Bros.User.Pref.TimeFormat);
		if (Temp.indexOf("?") >= 0)
			return "";
		var ToShow					= Temp;
		Temp						= Bros.Lib.UDate.ToStr(To,	 Bros.User.Pref.TimeFormat);
		if (Temp.indexOf("?") >= 0)
			return ToShow;
		return ToShow + "-" + Temp;
		}

	//---------------------------------------------------------------------------
	// Create QTab
	//---------------------------------------------------------------------------

	function Create_QTab(DTab, TableName)
		{
		//	deb						("Create_QTab", "TableName = " + TableName);

		// Already Created ?
		if (QTabs[TableName])
			return QTabs[TableName];
		//	deb						("Create_QTab (CREATING !)");

		// Creates
		QTabs[TableName]			= Bros.Lib.QTab.GetNew(DTab);
		var QTab					= QTabs[TableName];
		Bros.Lib.QTab
			.Set					(QTab, "HostPanelName",	"Panel_" + TableName)
			.Set					(QTab, "OnGoBack",		function ()
				{
				//	var B			= C;							// To simulate Error
				//	deb			("ON GO BACK !!!");
				// Select QTab Panel
				var Effect			= "auto";
				//	Effect			= "none";
				//	Effect			= "bottom";
				Bros.Lib.Elem.SelectPanel("Panel_Calendar", Effect);
				Update				();
				})
			;

		return QTabs[TableName];
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Insert Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Elements for Insert
	//---------------------------------------------------------------------------

	function Insert_CreateElements()
		{
		//	deb						("Insert_CreateElements");
		Bros.createelement			("menu")
				.onready			(function (Elem)
					{
					Insert_Menu		= Elem;
					})
				.additem			(Bros.Msg.CLD.InsertNewReminderOnThisDate,	ImageSrc_Reminders,	"", function (Elem)
					{
					Insert_New_Reminder();
					})
				.additem			(Bros.Msg.CLD.InsertNewPersonOnThisDate,	ImageSrc_People,	"", function (Elem)
					{
					Insert_New_Person();
					})
			;
		};

	//---------------------------------------------------------------------------
	// Insert Build
	//---------------------------------------------------------------------------

	function Insert_Build(Event)
		{
		//	deb						("Insert_Build", ImageSrc_Insert);
		//	PCS						(Event);

	// XPTUTCDATE
	//	var Year					= Event.DayDate.getFullYear();
	//	var Month					= Event.DayDate.getMonth();
	//	var Day						= Event.DayDate.getDate();
	// XPTUTCDATE
		var Year					= Bros.Lib.UDate.GetYear	(Event.DayDate);
		var Month					= Bros.Lib.UDate.GetMonth	(Event.DayDate);
		var Day						= Bros.Lib.UDate.GetDay		(Event.DayDate);
		//	deb						(Year, Month, Day);

		// Build ImageTag
		var ImageTag				= "";
		ImageTag				   += "<img";
		ImageTag				   += " src='" + ImageSrc_Insert + "'";
		//	ImageTag			   += " onmouseover=\"this.style.cursor='pointer';\" ";
		ImageTag				   += " onmouseover=\"this.style.cursor='pointer';this.style.backgroundColor='" + Color_MouseOver + "';\" ";
		ImageTag				   += " onmouseout=\"this.style.backgroundColor='';\" ";
		ImageTag				   += " onclick='Bros.Temp_Calendar_Insert_OnClick(" + Year + ", " + Month + ", " + Day + ");'";
		ImageTag				   += ">";

		// Put ImageTag on Event.Cell.Content
		Event.Cell.Content			= ImageTag;
		};

	//---------------------------------------------------------------------------
	// Insert OnClick
	//---------------------------------------------------------------------------

	Bros.Temp_Calendar_Insert_OnClick = function Insert_OnClick(Year, Month, Day)
		{
		//	deb						("Bros.Temp_Calendar_Insert_OnClick", Year, Month, Day);
		Do_Insert_OnClick			(Year, Month, Day);
		};

	//---------------------------------------------------------------------------
	// Insert OnClick
	//---------------------------------------------------------------------------

	function Do_Insert_OnClick(Year, Month, Day)
		{
		//	deb						("Do_Insert_OnClick", Year, Month, Day);

		// Store
		G_Year						= Year;
		G_Month						= Month;
		G_Day						= Day;

		// XPTMOUSEMOVE
		//	var Pos					= Bros.GetMousePos(Bros.MouseMove_e);
		var Pos						= Bros.GetMousePosMainElement(Bros.MouseMove_e);
		Pos[0]					   -= Bros.ApplyZoom(100);			// Adjust left just in case of clickink too much on the right)
		//	deb						("Pos = " + Pos);
		//
		//
		Bros.element(Insert_Menu).popup(Pos);
		};

	//---------------------------------------------------------------------------
	// Do Insert New ...
	//---------------------------------------------------------------------------

	function Do_Insert_New(QTab_Name, DCol_Name)
		{
		//	deb						("Do_Insert_New", G_Year, G_Month, G_Day, QTab_Name, DCol_Name);

		// Define QTab
		var QTab					= QTabs[QTab_Name];

		// Select QTab Panel
		var Effect					= "auto";
		//	Effect					= "none";
		//	Effect					= "top";
		Bros.Lib.Elem.SelectPanel	(QTab.HostPanelName, Effect);

		// Set Event OnInsertNewRecord
		//	PCS						(QTab);
		QTab.OnInsertNewRecord		= function (Event)
			{
			//	deb					("QTab.OnInsertNewRecord");
			//	PCS					(Event.Reco);
		// XPTUTCDATE
		//	Event.Reco[DCol_Name]	= new Date(G_Year, G_Month, G_Day, 12, 0, 0, 0);
		// XPTUTCDATE
			Event.Reco[DCol_Name]	= Bros.Lib.UDate.GetNewDate(G_Year, G_Month, G_Day, 12, 0, 0, 0);
			};
		Bros.Lib.QTab.InsertRecord	(QTab);
		};

	//---------------------------------------------------------------------------
	// Insert New Reminder
	//---------------------------------------------------------------------------

	function Insert_New_Reminder()
		{
		//	deb						("Insert_New_Reminder", G_Year, G_Month, G_Day);
		//	PCS						(QTabs.Reminders);
		Do_Insert_New				("Reminders",	"DATEBEGUIN");
		};

	//---------------------------------------------------------------------------
	// Insert New Person
	//---------------------------------------------------------------------------

	function Insert_New_Person()
		{
		//	deb						("Insert_New_Person", G_Year, G_Month, G_Day);
		Do_Insert_New				("People",		"BIRTHDAY");
		};

//###########################################################################
//###########################################################################
