//###########################################################################
//###########################################################################

		// Creates the Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// DebugCount
		var DebugCount				= 10;

		// What to Build ?
		AppC.MainMenu.Build			= ! false;
		AppC.ButtonsPanel.Build		= ! false;
		AppC.StatusPanel.Build		=   false;

		// Window Caption
		APPC.windowcaption			(AppC, "Bros Test DI");

		// Define IP (IP = ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_TextEditor/";

		// Define Here your Main Menu
		APPC.addmenufolder			(AppC, "Main");
			APPC.addmenuitem		(AppC, "Show IS_A",	IP + "Img_0030_File_Open.png",		"Ctrl+O",	Menu_Show_IS_A)		.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Clear",		IP + "Img_0080_File_SaveAs.png",	"",			Menu_Show_IS2)		.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Show IS_B",	IP + "Img_0080_File_SaveAs.png",	"",			Menu_Show_IS_B)		.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Show IS_C",	IP + "Img_0080_File_SaveAs.png",	"",			Menu_Show_IS_C)		.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Show IS_C",	IP + "Img_0080_File_SaveAs.png",	"",			Menu_Show_IS_D)		.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Exit",		IP + "Img_0100_File_Exit.png",		"Alt+F4",	Menu_File_Exit)		.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.Tools);
			APPC.addmenuitemreload	(AppC);//.Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);

		// Define Here your Status Panel
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Now, everything will be created automatically for you
		APPC.createall				(AppC);

		// Create Here your application elements
		Bros
			.createelement			("panel")
				.name				("MyPanel")
				.align				("client")
				.borderstyle		(Bros.bsEdit)
			;

	//	// This Method (Event indeed) will be called if this application is opened and you shut down and the returned value will be saved for the next sign-in
	//	APPC.ongetappargs(AppC, function ()
	//		{
	//		return "Something that make sense for this application";
	//		});
	//
	//	// Here you will get the value saved in APPC.ongetappargs above and you can do something with the AppArgs
	//	var AppArgs					= APPC.getappargs(AppC);
	//	//	deb						("AppArgs = " + AppArgs);
	//	if (AppC.StatusPanel.Build)
	//		Bros.element("MyStatusPanelInfo").html("&nbsp;" + AppArgs);


		var IS_A, ISP;
		var MyObj_A					= {};
		Build_IS_A					();
//		var MyObj_B					= {};
//		Build_IS_B					();

		var IS_D;
		var MyObj_D					= {};
		Build_IS_D					();

Menu_Show_IS_A();
//Menu_Show_IS_B();
//Menu_Show_IS_C();
//Menu_Show_IS_D();

	//---------------------------------------------------------------------------
	// Update Number Appearance
	//---------------------------------------------------------------------------

	function UpdateNumberAppearance(DI, Item_Caption, Item_ThousandSeparator, Item_DecimalSeparator)
		{
		//	deb						("UpdateNumberAppearance", DI, Item_Caption, Item_ThousandSeparator, Item_DecimalSeparator);
		//	return;

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Item_Caption)			.get(DI, "componentelement");
		var Elem_Thous				= Bros.lib.di.item(DI, Item_ThousandSeparator)	.get(DI, "componentelement");
		var Elem_Decim				= Bros.lib.di.item(DI, Item_DecimalSeparator)	.get(DI, "componentelement");

		// Gets the values
		var Value_Thous				= Bros.element(Elem_Thous).value();
		var Value_Decim				= Bros.element(Elem_Decim).value();
		//	deb						(Value_Thous, Value_Decim);

		//	Bros.element(Elem_Decim).value(".").text(".");
		}

	//---------------------------------------------------------------------------
	// Build_IS_A
	//---------------------------------------------------------------------------

	function Build_IS_A()
		{
		//	deb						("Build_IS_A");

		// Setup DI
		MyObj_A.MyBoolFalse			=   false;
		MyObj_A.MyBoolTrue			= ! false;
		MyObj_A.MyBoolOptions		= ! false;
		//
		MyObj_A.MyNumber			= 1234.5;
		MyObj_A.MyNumber_Options	= 22.22 * 2;
		//
		MyObj_A.MyString			= "Andre";
		MyObj_A.MyString_Options	= "Cy Salem !!!";
		//
		MyObj_A.Passw				= "123456";
		MyObj_A.Passw_Options		= "654321";
		//
		MyObj_A.MyStringTA			= "Andre Garcia";
		//
		MyObj_A.MyDate				= new Date(1958, 9, 14, 0, 0, 0, 0);
		MyObj_A.MyDate_Options		= new Date(2015, 9, 14, 0, 0, 0, 0);
		//
	//	MyObj_A.Count				= 2;
	//	MyObj_A.Items				= [];
	//	for (var i = 0; i < MyObj_A.Count; i++)
	//		{
	//		var Item				= {
	//			Value				: "My Item Value " + i
	//			}
	//		MyObj_A.Items.push		(Item);
	//		}

		// Setup DI
		var DI						= Bros.Lib.DI.GetNew("My Testing A", "../../3_Site/Public/img/Bros/Examples/ImgEx_Bros.gif");


		// Preferences
		var Item_Caption, Item_ThousandSeparator, Item_DecimalSeparator;
		Bros.lib.di
			.additem				(DI, "Numbers appearance",				"",					Bros.Lib.Num.ToStr(1234.56))
			.additem				(DI, "",								"",					"<b>Numbers appearance, e.g: " + Bros.Lib.Num.ToStr(1234.56) + "</b>")
				.set				(DI, "onready", function (Item)
					{
					Item_Caption	= Item;
					})
			.additem				(DI, Bros.Msg.PHR.ThousandSeparator,	Bros.User.Pref,		"ThousandSeparator")
				.addoption			(DI, "Comma (,)",						",")
				.addoption			(DI, "Dot (.)",							".")
				.addoption			(DI, "None",							"")
				.set				(DI, "onready", function (Item)
					{
					Item_ThousandSeparator = Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					//	deb			("OnChange");
					UpdateNumberAppearance(DI, Item_Caption, Item_ThousandSeparator, Item_DecimalSeparator);
					})
			.additem				(DI, Bros.Msg.PHR.DecimalSeparator,		Bros.User.Pref,		"DecimalChar")
				.addoption			(DI, "Dot (.)",							".")
				.addoption			(DI, "Comma (,)",						",")
				.set				(DI, "onready", function (Item)
					{
					Item_DecimalSeparator = Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateNumberAppearance(DI, Item_Caption, Item_ThousandSeparator, Item_DecimalSeparator);
					})
			;

		Bros.Lib.DI
//			//.AddItem				(DI, "DI.PosStyle",						DI,			"PosStyle")
//			//	.AddOption			(DI, Bros.Lib.DI.PosStyle_LabLeft)
//			//	.AddOption			(DI, Bros.Lib.DI.PosStyle_LabTop)
//			//
			.AddItem				(DI, "My Bool Value false",				MyObj_A,	"MyBoolFalse")
			.AddItem				(DI, "My Bool Value true",				MyObj_A,	"MyBoolTrue",			  false)
//	//			.Set				(DI, "image.imagesrc",					"BrosPublic:/img/BrosApps/BrosApp_MyContacts/Img_620_Phone.png")
//	//			.Set				(DI, "image.imagewidth",				48)
//	//			.Set				(DI, "image.imageheight",				82)
			.AddItem				(DI, "My Bool Value",					MyObj_A,	"MyBoolOptions",		  false)
				.AddOption			(DI, "My Bool Value option FALSE",		  false)
				.AddOption			(DI, "My Bool Value option TRUE",		! false)
				//.Set				(DI, "onchange",						function (Elem)
				//	{
				//	deb				("onchange");
				//	})
			//
			.AddItem				(DI, "My Number Value",					MyObj_A,	"MyNumber")
				.Set				(DI, "image.imagesrc",					"BrosPublic:/img/BrosApps/BrosApp_MyContacts/Img_620_Phone.png")
				.Set				(DI, "decimals",						3)
.Set				(DI, "image.imagewidth",				48)
//			//	.AddItem			(DI, "",								MyObj_A,	"MyNumber_Options",		33.33)
			.AddItem				(DI, "My Number<br>Options Value",		MyObj_A,	"MyNumber_Options",		33.33)
				.Set				(DI, "image.imagesrc",					"BrosPublic:/img/BrosApps/BrosApp_MyContacts/Img_620_Phone.png")
				.Set				(DI, "image.imagewidth",				48)
				.Set				(DI, "image.imageheight",				82)
				.Set				(DI, "popupmenu.imagewidth",			48)
				.Set				(DI, "popupmenu.imageheight",			32)
				.AddOption			(DI, "My select option 1", 11.11, "BrosPublic:/img/Icons/_32/Icon_Google.gif")
				.AddParentOption	(DI, "My select options:", 66.66, "BrosPublic:/img/BrosApps/BrosApp_MyContacts/Img_620_Phone.png")
					.AddOption		(DI, "My select option 2", 22.22)
					.AddParentOption(DI, "My select more options:")
						.AddOption	(DI, "My select option 3", 33.33)
						.AddOption	(DI, "My select option 4", 44.44, "BrosPublic:/img/Icons/_32/Icon_Google.gif")
						.ParentOption(DI)
					.AddOption		(DI, "My select option 5", 55.55, "../../3_Site/Public/img/Bros/Examples/ImgEx_Bros.gif")
					.ParentOption	(DI)
				.AddOption			(DI, "My select option 6", 66.66, "BrosPublic:/img/BrosApps/BrosApp_MyContacts/Img_620_Phone.png")
				.Set				(DI, "onready", function (Item)
					{
//						PCS			(Item, ! false);
					})
			//
			.AddItem				(DI, "My String Value",					MyObj_A,	"MyString")
				.Set				(DI, "maxlength",						10)
				.Set				(DI, "enabled",							false)
//			//	.Set				(DI, "type",							"password")
//				.Set				(DI, "type",							"editarea")
//				.Set				(DI, "mode",							"codeeditor")
//			//	.Set				(DI, "mode",							"texteditor")
//			//	.Set				(DI, "height",							50)
			.AddItem				(DI, "My String<br>Options Value",		MyObj_A,	"MyString_Options",		"Cy Salem")
//				.Set				(DI, "type",							"password")
//				.AddOption			(DI, "My String Option A",				"Andre Garcia")
//				.AddOption			(DI, "My String Option B",				"Cy Salem")
			//
			.AddItem				(DI, "My Password",						MyObj_A,	"Passw")
				.Set				(DI, "type",							"password")
			.AddItem				(DI, "My Password Options",				MyObj_A,	"Passw_Options")
				.Set				(DI, "type",							"password")
				.AddOption			(DI, "My Password Option A",			"123456")
				.AddOption			(DI, "My Password Option B",			"654321")
			//
			.AddItem				(DI, "My String Text Area",				MyObj_A,	"MyStringTA")
				.Set				(DI, "type",							"editarea")
				.Set				(DI, "mode",							"texteditor")
				.Set				(DI, "mode",							"codeeditor")
				.Set				(DI, "width",							200)
				.Set				(DI, "height",							300)
			//
			.AddItem				(DI, "My Date Value",					MyObj_A,	"MyDate")
				.Set				(DI, "dateformat",		"%dd/%mm/%yyyy")
			//	.Set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn")
			//	.Set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn:%ss")
			.AddItem				(DI, "My Date Value",					MyObj_A,	"MyDate")
				.Set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn")
			.AddItem				(DI, "My Date Value",					MyObj_A,	"MyDate")
				.Set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn:%ss")
//.Set				(DI, "width",			300)
			.AddItem				(DI, "My Date Value",					MyObj_A,	"MyDate_Options")
.Set				(DI, "width",			300)
				.AddOption			(DI, "My Date Option A",				new Date(1958, 9, 14, 0, 0, 0, 0))
				.AddOption			(DI, "My Date Option B",				new Date(2015, 9, 14, 0, 0, 0, 0))
			//
				.AddButton			(DI, "Cancel",		"BrosPublic:/img/Icons/_16/Icon_Cancel.png", function (Elem)
					{
					deb				("OnClick Cancel");
					//	PCS			(Elem);
					Bros.Lib.DI.Exch_Restore(DI);
					})
				.AddButton			(DI, "Restore",		"BrosPublic:/img/Icons/_16/Icon_Restore.png", function (Elem)
					{
					deb				("OnClick Restore");
					//	PCS			(Elem);
					Bros.Lib.DI.Exch_Restore(DI);
					})
				.AddButton			(DI, "Defaults",	"BrosPublic:/img/Icons/_16/Icon_Default.png", function (Elem)
					{
					deb				("OnClick Defaults");
					Bros.Lib.DI.Exch_Defaults(DI);
					})
				.AddButton			(DI, "Apply",		"BrosPublic:/img/Icons/_16/Icon_Apply.png", function (Elem)
					{
					deb				("OnClick Apply");
					Bros.Lib.DI.Exch_Apply(DI);
					PCS				(MyObj_A, ! false, ! false);
					//	Bros.Lib.DI.SetCurrentItem(DI, MyObj_A, "MyBoolFalse");
					//	deb			(Bros.Lib.DI.Get(DI, "cHanged"));
//					deb				(Bros.Lib.DI.SetCurrentItem(DI, MyObj_A, "MyBoolFalse").Get(DI, "cHanged"));
					})
				.AddButton			(DI, "OK",			"BrosPublic:/img/Icons/_16/Icon_OK.png", function (Elem)
					{
					deb				("OnClick OK");
					PCS				(MyObj_A, ! false, ! false);
					})
			;

//		Bros.Lib.DI.SetCurrentItem(DI, MyObj_A, "MyBoolOptions").Set(DI, "onchange", function (Elem)
//			{
//			deb						("onchange");
//			});


	//	for (var i = 0; i < MyObj_A.Count; i++)
	//		{
	//	//	Bros.Lib.DI.AddItem		(DI, "My Item " + i,					MyObj_A,			"Items[" + i + "].Value")
	//		Bros.Lib.DI.AddItem		(DI, "My Item " + i,					MyObj_A.Items[i],	"Value", "DEFAULT " + i)
	//		}
		//	for (var i = 0; i < 5; i++)
		//		{
		//		Bros.Lib.DI
		//			.AddButton		(DI, "Cancel " + i, "../../3_Site/Public/img/Bros/Examples/ImgEx_Bros.gif", function (Elem, e)
		//				{
		//				deb			("OnClick Cancel " + i, Elem.Caption);
		//				})
		//		}
		IS_A						= DI;
		//	PCS						(DI);
		//	PCS						(DI.Items		[0]);
		//	PCS						(DI.Buttons		[0]);
		//	//	PCS					(DI.Elem_Buttons[0]);
		//	PCS						(MyObj_A);
		}

	//---------------------------------------------------------------------------
	// Build_IS_B
	//---------------------------------------------------------------------------

	function Build_IS_B()
		{
		//	deb						("Build_IS_B");

		var Count					= DebugCount;
		var AddOptions				=   false;
//AddOptions				= ! false;

		// Setup DI
		MyObj_B.MyValue				=   false;
			MyObj_B.MyValue			= "Andre Garcia";

		// Setup DI
		var DI						= Bros.lib.di.getnew("My Loop Data", "../../3_Site/Public/img/Bros/Examples/ImgEx_Bros.gif");
		for (var i = 0; i < Count; i++)
			{
			Bros.lib.di.additem		(DI, "My Value " + (i + 1), MyObj_B, "MyValue");
			if (AddOptions)
				{
				Bros.lib.di
					.addoption		(DI, "My Bool Value option FALSE",		  false)
					.addoption		(DI, "My Bool Value option TRUE",		! false)
					;
				}
			}
		Bros.lib.di
			.addbutton			(DI, "Apply",		"BrosPublic:/img/Icons/_16/Icon_Apply.png", function (Elem)
				{
				deb				("OnClick Apply");
				Bros.lib.di.apply(DI);
				PCS				(MyObj_B, ! false, ! false);
				//	Bros.Lib.DI.SetCurrentItem(DI, MyObj_B, "MyBoolFalse");
				//	deb			(Bros.Lib.DI.Get(DI, "cHanged"));
				deb				(Bros.Lib.DI.SetCurrentItem(DI, MyObj_B, "MyValue").Get(DI, "cHanged"));
				})
			;

		IS_B						= DI;
		}

	//---------------------------------------------------------------------------
	// Menu Methods
	//---------------------------------------------------------------------------

	function Menu_File_Exit()
		{
		Bros.element(APPC.windowname(AppC)).close();
		}

	function Menu_Show_IS_A()
		{
		//	deb						("Menu_Show_IS_A");
		//	alert					("Menu_Show_IS_A");
//		Bros.___R					();
//		Bros.___B					();
		Bros.Lib.DI.Build			(IS_A, "MyPanel");
//		Bros.___E					("Menu_Show_IS_A");
		//	PCS						(ISP);
		}

	function Menu_Show_IS2()
		{
		//	deb						("Menu_Show_IS2");
		Bros.element("MyPanel").deletechildren();
		}

	function Menu_Show_IS_B()
		{
		//	deb						("Menu_Show_IS_B");
		Bros.Lib.DI.Build			(IS_B, "MyPanel");
		}

	function Menu_Show_IS_C()
		{
		//	deb						("Menu_Show_IS_C");
		Bros.element("MyPanel")
			.deletechildren			()
			.scrollbars				("both")
			;
		var Count					= DebugCount;
		Bros.___R					();
		Bros.___B					();
		for (var i = 0; i < Count; i++)
			{
			Bros.createelement		("checkbox")
				.caption			("checkbox " + (i + 1))
				;
			}
		Bros.___E					("Menu_Show_IS_C");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Test D
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_Show_IS_D
	//---------------------------------------------------------------------------

	function Menu_Show_IS_D()
		{
		//	deb						("Menu_Show_IS_D");
		Bros.Lib.DI.Build			(IS_D, "MyPanel");
		}

	//---------------------------------------------------------------------------
	// Build_IS_C
	//---------------------------------------------------------------------------

	function Build_IS_D()
		{
		//	deb						("Build_IS_D");

		// Setup DI
		var MyObj					= MyObj_D;
		MyObj.MyBool				=   false;
		MyObj.MyNum					= 12.345;
		MyObj.MyStr					= "Teste";
		MyObj.MyDate				= new Date(1958, 9, 14, 0, 0, 0, 0);

		// Setup DI
		var DI						= Bros.Lib.DI.GetNew("My Test D", "../../3_Site/Public/img/Bros/Examples/ImgEx_Bros.gif");
		IS_D						= DI;

		// Configure
		//	for (var i = 0; i < 30; i++)
		var Size					= 30;
		Bros.lib.di
			.additem				(DI, "My Bool",			MyObj,		"MyBool")
			.additem				(DI, "My Num",			MyObj,		"MyNum")
			.additem				(DI, "My Str",			MyObj,		"MyStr")
//				.set				(DI, "MaxLength",		Size)
//				.set				(DI, "Size",			Size)
//				.set				(DI, "height",			40)
			.additem				(DI, "My Date",			MyObj,		"MyDate")
			//	.set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn:%ss")
			//	.set				(DI, "dateformat",		"%dd/%mm/%yyyy %hh:%nn")
			//	.set				(DI, "dateformat",		"%dd/%mm/%yyyy")
			;
		}

//###########################################################################
//###########################################################################
