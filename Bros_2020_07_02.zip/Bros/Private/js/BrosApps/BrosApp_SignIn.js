//###########################################################################
//###########################################################################
//##
//## Bros Application - Sign In
//##
//###########################################################################
//###########################################################################

		//	deb						("Bros Application - Sign In");
		//	PCS						(application);

	//---------------------------------------------------------------------------
	// Globals
	//---------------------------------------------------------------------------

		// Building properties
		var GAMB					= 10;
		var B_Left_Cap				=   8 + GAMB;
		var B_Left_Input			=  72 + GAMB;
		var B_Left_ButtonOffset		=   8;
		//
		var B_Top					=   8;
		var B_Top_Delta				=   8;
		var B_Top_LabelOffset		=   2;
		//
		var B_Width_Input			= 360;							// Original 352
		var B_Width_WinOffset		=  18 + GAMB;
		var B_Width_Button_SignIn	=  72;							// Original  72
		var B_Width_Button_CrNewAcc	= 160;							// Original 152
		var B_Width_Button_ForgPass	= 112;							// Original 112
		//
		var B_Height_Input			=  21;							// Original 21
		var B_Height_Button			=  24;							// Original 24
		var B_Height_WinOffset		=  28;

		var ContractVersion			= "3.1";

		var Contract				= [];
		//	Contract.push			('<table cellpadding=10 border=0><tr><td><B><FONT FACE="Arial" SIZE=4><P ALIGN="CENTER">Bros</P><P ALIGN="CENTER">(Browser Operational System');
		//	Contract.push			(')</P></B></FONT><FONT FACE="Arial" SIZE=2></FONT><B><FONT FACE="Arial" COLOR="#ff0000"><P ALIGN="CENTER">This is a Contract.</P><P ALIGN="C');
		//	Contract.push			('ENTER"></P><P ALIGN="CENTER">By using Bros - Browser Operational System, software you accept ALL the terms and the conditions of this agree');
		//	Contract.push			('ment.</P><P ALIGN="CENTER"></P><P ALIGN="CENTER">It is a license agreement, not to sell. This software is provided in accordance with the t');
		//	Contract.push			('erms transcribed below: </P><P ALIGN="CENTER"></P><P ALIGN="CENTER">IMPORTANT: This license should be read carefully before using this soft');
		//	Contract.push			('ware. The installation and use of the software indicates that the client is aware of the terms of this license and agree with them.</P></B>');
		//	Contract.push			('</FONT><FONT FACE="Arial" SIZE=2><P ALIGN="JUSTIFY">For this particular instrument from side to <B>XPNET COMUNICA&Ccedil;&Otilde;ES LTDA</B');
		//	Contract.push			('>., hereinafter called the LICENSOR, and on the other hand, your lordship, hereafter LICENSED (or LICENSEE), have mutually adjusted this "A');
		//	Contract.push			('greement for Software License", which is governed by the following terms and conditions:</P><B><U><P>SECTION ONE: OBJECT</P><DIR></U><P ALI');
		//	Contract.push			('GN="JUSTIFY">1.1 </B>The object of this contract assignment for a non-exclusive license to use the software called <B>Bros (Browser Operati');
		//	Contract.push			('onal System)</B>, owned by LICENSOR.</P><B><P ALIGN="JUSTIFY">1.2 </B>Treatment is a executable program that allows LICENSED to operate pro');
		//	Contract.push			('grams under Bros.</P><B><P ALIGN="JUSTIFY">1.3</B> It is already now expressly provided that the rights of intellectual property on the <B>');
		//	Contract.push			('Bros (Browser Operational System)</B>, are not the subject of this agreement, which remain the sole property of LICENSOR, being prohibited ');
		//	Contract.push			('its use by third parties without the prior consent of LICENSOR.</P></DIR><B><U><P>SECTION TWO: LICENSE</P><DIR></U><P ALIGN="JUSTIFY">2.1</');
		//	Contract.push			('B> Licensing is done on any user quantity and is for free under BSD License.</P><P ALIGN="JUSTIFY"></P></DIR><DIR><B><P ALIGN="JUSTIFY">2.2');
		//	Contract.push			('</B> The software is only distributed through web usage. </P><B><P ALIGN="JUSTIFY">2.3</B> It can be used anyway. </P><P ALIGN="JUSTIFY"></');
		//	Contract.push			('P><B><P ALIGN="JUSTIFY">2.4</B> By accepting the terms of this contract, the user (ie the LICENSED) are aware that all data and information');
		//	Contract.push			('entered by him or shown him by the program screens were read and accepted, being the sole responsibility of the inaccuracies data informed ');
		//	Contract.push			('by him, being exempted from any liability to LICENSOR. The client is aware that the obtained data and / or filled by him, shall be saved in');
		//	Contract.push			('the local database from the client not having to LICENSOR any responsibility for maintenance of the database.</P><P ALIGN="JUSTIFY"></P><B>');
		//	Contract.push			('<P ALIGN="JUSTIFY">2.5</B> The license to use the program is by the transferor, the holder of the current account, the one that will make t');
		//	Contract.push			('he payment. It is the responsibility of the customer to claim that it is the transferor, or has permission from the transferor to provide t');
		//	Contract.push			('he necessary data, freeing up the LICENSOR by the possible vices of consent form adopted.</P><P ALIGN="JUSTIFY"></P></DIR><B><U><P>SECTION ');
		//	Contract.push			('THREE: EXPIRY DATE LICENSE</P><DIR></U><P ALIGN="JUSTIFY">3.1</B> This contract is concluded for an indefinite term, counted from the date ');
		//	Contract.push			('of acceptance, ie, the LICENSEE may use the SOFTWARE for as long as desired, and shall during the time you are using the SOFTWARE remain co');
		//	Contract.push			('mpliant with the monthly or annual payment. </P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">3.2</B> LICENSEE may terminate this agreement ');
		//	Contract.push			('at any time provided that expressly inform the LICENSOR with 30 days notice. In no event any amounts paid will be returned. The LICENSOR ma');
		//	Contract.push			('y terminate this contract if the failure by LICENSEE of its contractual obligations.</P><P ALIGN="JUSTIFY"></P></DIR><B><U><P>SECTION FOUR:');
		//	Contract.push			('PRICES AND CONDITIONS</P><DIR></U><P ALIGN="JUSTIFY">4.1 </B>LICENSEE shall pay to LICENSOR, the license to use the Software, the value of ');
		//	Contract.push			('the plan chosen by LICENSEE at the time of ordering, either the monthly or annual plan, as do the accepted time of payment. </P><B><P ALIGN');
		//	Contract.push			('="JUSTIFY"></P><P ALIGN="JUSTIFY">4.2 </B>Upon confirmation of payment by the bank, will be sent electronically to the e-mail LICENSEE the ');
		//	Contract.push			('License Code to use the software.</P><B><P ALIGN="JUSTIFY"></P></DIR><U><P ALIGN="JUSTIFY">SECTION FIVE: THE OBLIGATIONS OF LICENSOR</P><DI');
		//	Contract.push			('R></B></U><B><P ALIGN="JUSTIFY">5.1</B> The LICENSOR makes no representation that its software and technology upgrades will present itself ');
		//	Contract.push			('free from any defect or vice quality, even hidden or unknown.</P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">5.2</B> The LICENSOR is not r');
		//	Contract.push			('esponsible for misuse of the program by unattended of instructions, Article 14, Paragraph 3 and subsections of the CDC - Code of Consumer P');
		//	Contract.push			('rotection.</P><B><P ALIGN="JUSTIFY">5.3</B> The LICENSOR disclaims all liability whatsoever, direct or indirect, on the figures presented, ');
		//	Contract.push			('nor is it responsible or co-responsible for the implementation of the values obtained, labor actions, or claims of any kind.</P><B><P ALIGN');
		//	Contract.push			('="JUSTIFY">5.4</B> This agreement does not obligate LICENSOR to provide any free support, be it direct or indirect, via telephone, email, l');
		//	Contract.push			('etter or any other way.</P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">5.5 </B>This program should always be operated in its lastest versi');
		//	Contract.push			('on getting the users responsibility and will be aware that according to the contracts of the latest versions even use earlier versions.</P>');
		//	Contract.push			('<P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">5.6</B> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, IN');
		//	Contract.push			('CLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE A');
		//	Contract.push			('UTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISI');
		//	Contract.push			('NG FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. </P><P ALIGN="JUSTIFY"></P></DIR><B><U><P ');
		//	Contract.push			('ALIGN="JUSTIFY">SECTION SIX: THE FORUM</P><DIR></B></U><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">6.1</B> To resolve any disputes arising');
		//	Contract.push			('from this contract, the parties elect the district of S&atilde;o Paulo.</P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">6.2</B> Upon the us');
		//	Contract.push			('e of this program, the LICENSEE will be accepting all the terms of this agreement.</P></DIR></FONT></td></tr></table>');
		//	Contract.push			('<hr>v. ' + ContractVersion);
		//
		Contract.push				('<table cellpadding=10 border=0><tr><td>');
		//
		Contract.push				('<B><FONT FACE="Verdana" SIZE=2><P ALIGN="CENTER">GENERAL USE CONDITIONS </P><P ALIGN="CENTER">&quot;BROS&quot;</P></B></FONT><FONT SIZE=3><');
		Contract.push				('P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="CENTER">Latest Update: August 20, 2015</P></B></FONT><FONT SIZE=3><P ');
		Contract.push				('ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">READ WITH ATTENTION:</B> WHEN ACCESSING, USING OR REGISTERING ');
		Contract.push				('WITH THE OPERATIONAL SYSTEM <B>BROS</B>, YOU COMPLETELY AGREE WITH THE CONDITIONS SET FORTH HEREIN, AS WELL AS OTHER POLICIES AND/OR RULES ');
		Contract.push				('REFERRED TO HEREIN. SHOULD YOU NOT AGREE WITH ALL THOSE CONDITIONS, DO NOT USE THE OPERATIONAL SYSTEM OR OTHER PRODUCTS AND SERVICES OF <B>');
		Contract.push				('XPNET</B>.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">This General Use Conditions ');
		Contract.push				('(hereinafter referred to as "<B><U>CGU</B></U>") regulate the use of the operational system <B>BROS</B> (hereinafter referred to as &quot;<');
		Contract.push				('B><U>System</B></U>&quot;), available at <B>www.xpnet.com.br</B>, and of any and all product or service of <B>BROS</B> (hereinafter referre');
		Contract.push				('d to as &quot;<B><U>Developer</B></U>&quot;) included in the System or related thereto. </P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">When ');
		Contract.push				('using the System, you declare to be over 18 years old or, in the event of a minor, to be accompanied by a legal representative and to be le');
		Contract.push				('gally capable to accept the CGU. Should you be using the System in the name of entity and/or legal entity, you guarantee to be authorized t');
		Contract.push				('o accept the CGU in behalf of respective entity and/or legal entity, as well as guarantees that such entity and/or legal entity agrees in i');
		Contract.push				('ndemnifying the Developer for any breach of the CGU.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P AL');
		Contract.push				('IGN="JUSTIFY">The Developer undertakes to assure its privacy. We recommend checking the &quot;<B><U>Privacy Policy</B></U>&quot; (<B>see ww');
		Contract.push				('w.xpnet.com.br</B>) in order to obtain detailed information on the how the System collects, uses and discloses the user\'s information.</P><');
		Contract.push				('/FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">SYSTEM USE </P></B></FONT><FONT SIZE=3><');
		Contract.push				('P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The Developer assures you, provided that the CGU are complied w');
		Contract.push				('ith, the right to use the System. However, it is expressly prohibited to perform acts implying or which might imply breach of rights of the');
		Contract.push				('Developer, such as: (a) to reproduce or retransmit the System, whether partially or as a whole; (b) to use data mining devices and/or compa');
		Contract.push				('rable in order to collect and/or extract data out of the System; (c) to handle or show the System and/or respective contents using comparab');
		Contract.push				('le classification or navigation technology and; (d) to perform reverse engineering of the System.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"');
		Contract.push				('></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">OPERATION OF THE SYSTEM </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></');
		Contract.push				('FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The System is characterized for being an operational system, developed in javascript la');
		Contract.push				('nguage, which performs comparable functions to those assessed in conventional operational systems, but which does not depend of installatio');
		Contract.push				('n, operating directly through any browser or navigator (e.g. Google Chrome, Internet Explorer, Firefox, Safari, Opera etc.). Through the Sy');
		Contract.push				('stem, the users may:</P><P ALIGN="JUSTIFY"></P><UL><P ALIGN="JUSTIFY"><LI>install and use applications and computer programs compatible wit');
		Contract.push				('h the System;</LI></P></UL><P ALIGN="JUSTIFY"></P><UL><P ALIGN="JUSTIFY"><LI>use applications and native programs of the System, including ');
		Contract.push				('a tool turned to the development of applications and programs compatible with the System;</LI></P></UL><P ALIGN="JUSTIFY"></P><UL><P ALIGN=');
		Contract.push				('"JUSTIFY"><LI>create and store files, including upon integration with repository files service (e.g. Dropbox);</LI></P></UL><P ALIGN="JUSTI');
		Contract.push				('FY"></P><UL><P ALIGN="JUSTIFY"><LI>apply themes and/or personalize the appearance of the System.</LI></P></UL><P ALIGN="JUSTIFY"></P><P ALI');
		Contract.push				('GN="JUSTIFY">In order to use the System, you shall register, providing certain information to the Developer, receiving in contra account to');
		Contract.push				('a personal and nontransferable access password to the System. You shall be the sole responsible for the keeping, confidential, your access ');
		Contract.push				('password to the System. Any use which is made of the System, or information and files inserted in it, upon use of password, shall be your s');
		Contract.push				('ole liability, and the Developer shall be totally free from the liabilities arising out of such activities.</P><P ALIGN="JUSTIFY"></P><P AL');
		Contract.push				('IGN="JUSTIFY">The Developer shall not answer for or guarantee the proper operation of the applications or computer programs developed by th');
		Contract.push				('ird parties, through the System and/or which are compatible with the System, even if available for download in website and/or repository ma');
		Contract.push				('intained by the Developer, as well as does not guarantee or answers for the contents the users publish or share through the System.</P></FO');
		Contract.push				('NT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The System depend of stable connection with th');
		Contract.push				('e Internet and may not operate correctly due to problems in the navigator, public networks and/or even due to connection problems of either');
		Contract.push				('party involved, situations which are out of the Developer\'s control and, therefore, shall not be the Developer\'s liability. The user is als');
		Contract.push				('o aware that the System may present other errors, still unknown by the Developer, which possibly may obstruct the access of the users, not ');
		Contract.push				('store properly the data arising out of the users\' activities, etc.</P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">When using the System, you ');
		Contract.push				('may send and receive information, whether through files, email messages, contacts, etc. (hereinafter referred to as "<B><U>Private Informat');
		Contract.push				('ion</B></U>"). Your Private Information are solely and exclusively yours. The Developer shall not make a surveillance and/or any prior cont');
		Contract.push				('rol about the Private Information circulating or which shall be stored through the System and such CGU do not give the Developer any right ');
		Contract.push				('on the Private Information, releasing the System and the Developer of any liability on the Private Information circulating or hosted in the');
		Contract.push				('System. By force of complaints from third parties and/or legal decisions, the Developer may, at its own discretion, remove definitely or ma');
		Contract.push				('ke available to third parties the Private Information.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2>');
		Contract.push				('<P ALIGN="JUSTIFY">RIGHTS ON THE SYSTEM </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUS');
		Contract.push				('TIFY">The System, as well as the whole contents found and made available in it, including, but not limited to, texts, graphs, data, images,');
		Contract.push				('videos, sounds, illustrations, computer programs, source-codes, brands, slogans, domain names, database, corporate name, logotypes, icons, ');
		Contract.push				('trade dress, as well as the selection and organization of such components, belonging exclusively to the Developer and/or its partners and m');
		Contract.push				('ay not be copied, reproduced or used, whether partially or as a whole, without the prior written permission of the Developer\'s legal repres');
		Contract.push				('entative.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">It is expressly prohibited th');
		Contract.push				('e use of <I>metamarcas</I> or any other kind of "hidden code" containing the expression "<B>BROS</B>" or any other expressions identical or');
		Contract.push				('comparable to the brands, logotypes, slogans, domain names and corporate names with respect to the System, without prior written permission');
		Contract.push				('of the legal representative of the Developer, except cases expressly authorized in this CGU.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P>');
		Contract.push				('</FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">CLAIMING RIGHTS </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FA');
		Contract.push				('CE="Verdana" SIZE=2><P ALIGN="JUSTIFY">If you believe that the System or any content inserted therein breach your property rights or your c');
		Contract.push				('ontrol, you may give notice to the Developer through e-mail <B>suporte@xpnet.com.br</B>, but the Developer reserve the right to remove or m');
		Contract.push				('aintain such content, in accordance with the rules and guidance of the Law no. 12.965/2014, currently in force in the Federative Republic o');
		Contract.push				('f Brazil.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">In addition, you are aware th');
		Contract.push				('at the Developer cannot be held responsible for any damages arising out of the contents created or published by third parties, except in th');
		Contract.push				('e cases expressly provided for in Law no. 12.965/2014, in force in Brazil.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FA');
		Contract.push				('CE="Verdana" SIZE=2><P ALIGN="JUSTIFY">DATA COLLECTION AND PRIVACY </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Ve');
		Contract.push				('rdana" SIZE=2><P ALIGN="JUSTIFY">The Developer undertakes to assure your privacy, in compliance with the operations of the System. We recom');
		Contract.push				('mend checking the Privacy Policy (see <B>www.xpnet.com.br</B>) in order to obtain detailed information on how the System and the Developer ');
		Contract.push				('collect, use and disclose information of the users.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ');
		Contract.push				('ALIGN="JUSTIFY">LINKS</P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">You shall not');
		Contract.push				('be able to fit brands, logotypes, slogans, domain names, corporate names or other information or technology belonging to the Developer with');
		Contract.push				('out the Developer\'s legal representative express written consent.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana"');
		Contract.push				('SIZE=2><P ALIGN="JUSTIFY">The Developer does not recommend, as well as it shall not answer for, directly or not, quality, contents, nature ');
		Contract.push				('or reliability of the websites, products or services of third parties accessed through links available in the System, as well as websites, ');
		Contract.push				('products or services of third parties containing links for the System. Such websites, products or services are not under the control of the');
		Contract.push				('Developer and the Developer is not responsible for them. When you leave the System, the CGU shall not be applicable any longer. We suggest ');
		Contract.push				('checking the provisions and policies of any website, system and/or application to where you are guided to.</P></FONT><FONT SIZE=3><P ALIGN=');
		Contract.push				('"JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">Due to the provisions set forth in the paragraphs above, you agree in n');
		Contract.push				('ot making the Developer liable for losses, damages or other problems of any kind which may arise out of the use of websites containing link');
		Contract.push				('s for the System, or whose links are available in the System, as well as it is aware that any negotiation with such websites does not invol');
		Contract.push				('ve, binds and/or oblige the Developer.</P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">INTERACTIVE AREAS </P></B><P ALIGN="JUSTIFY"><BR>Thr');
		Contract.push				('ough the System you may access areas and interactive services, such as websites, discussion forums, social networks, etc., or tools for dir');
		Contract.push				('ect communication with the interactive services of third parties (Facebook, Twitter, etc.), in which you or third parties may create, publi');
		Contract.push				('sh and/or store messages, comments or other contents (hereinafter referred to as "<B><U>Interactive Areas</B></U>"). </P><P ALIGN="JUSTIFY"');
		Contract.push				('></P><P ALIGN="JUSTIFY">When using an Interactive Area, remember that such areas are open to the users and that any personal information pu');
		Contract.push				('blished or provided by you may be visualized by others. We are not liable for information sent by you with respect to the Interactive Areas');
		Contract.push				(', or by the way in which other persons might use such information, including sending unrequested messages. </P></FONT><FONT SIZE=3><P ALIGN');
		Contract.push				('="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">INDEMNIFICATION </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P>');
		Contract.push				('</FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">You hereby agree in hold harmless and indemnify the Developer, its employees, agents,');
		Contract.push				('collaborators, outsourced parties and independent providers from and against any claim, damage, cost, charges, liabilities and/or expenses ');
		Contract.push				('(including, but not limited to, attorney\'s fees) arising out or related to any contents you may publish, store and/or transmit in the Syste');
		Contract.push				('m or through the System, at your own discretion, to your use or incapacity of use the System or tools, breaching or supposedly breaching th');
		Contract.push				('e CGU and other policies of the System, to its unauthorized use of the contents of the Developer or breach to any rights of third parties.<');
		Contract.push				('/P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">DISCLAIMER </P></B></FONT><FONT SIZE');
		Contract.push				('=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">THE USE THE USER MAKES OF THE SYSTEM IS ON ITS OWN ACCOUNT ');
		Contract.push				('AND RISK. THE USER IS THE SOLE RESPONSIBLE FOR ANY LOSS OR DAMAGE ARISING OUT THEREOF. THE SYSTEM IS PROVIDED &quot;AS IT IS&quot; AND &quo');
		Contract.push				('t;ACCORDING TO AVAILABILITY&quot;. ACCORDING TO THE LIMITS ALLOWED BY THE LAW, THE DEVELOPER EXPRESSLY DISCLAIMS ALL RESPONSIBILITIES, WARR');
		Contract.push				('ANTIES OR CONDITIONS OF ANY NATURE, WHETHER EXPRESS OR IMPLICIT.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" ');
		Contract.push				('SIZE=2><P ALIGN="JUSTIFY">THE DEVELOPER DOES NOT GUARANTEE THAT: (A) THE SYSTEM SHALL MEET YOUR NEEDS; (B) THE SYSTEM SHALL OPERATE WITHOUT');
		Contract.push				('INTERRUPTIONS, PUNCTUALLY, SAFE OR FREE FROM ERRORS; (C) THE CONTENTS AVAILABLE OR CREATED IN THE SYSTEM SHALL BE ACCURATE OR RELIABLE; (D)');
		Contract.push				('THE QUALITY OF THE SYSTEM SHALL MEET YOUR EXPECTATIONS, AND; (E) ANY ERRORS IN THE CONTENTS AND/OR SYSTEM SHALL BE EFFECTIVELY CORRECTED.</');
		Contract.push				('P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">THE DEVELOPER DOES NOT PERFORM, AND HAS NO LEGAL PREROGATIVE OF PERFORMING, MONITORING, SURVEIL');
		Contract.push				('LANCE, EDITION OR APPROVAL OF THE CONTENT, OF THE FILES, PROGRAMS AND APPLICATIONS USED IN THE SYSTEM OR OF THE FORM OF USE OF THE SYSTEM B');
		Contract.push				('Y THE USERS.</P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">THE DEVELOPER SHALL NOT BE LIABLE FOR THE CONTENTS, FILES, PROGRAMS AND APPLICATI');
		Contract.push				('ONS USED IN THE SYSTEM OR OF THE FORM OF USE OF THE SYSTEM BY THE USERS, AND THE USERS SHALL BE LIABLE FOR CARRYING FOR THE BEST INTERESTS ');
		Contract.push				('THEREOF, REASON WHY, THE USER EXPRESSLY ACKNOWLEDGES AND AGREED THAT THE DEVELOPER CANNOT BE HELD RESPONSIBLE BEFORE THE USER OR ANY THIRD ');
		Contract.push				('PARTY, FOR LOSSES AND DAMAGES OF ANY KIND, WHICH BECOME KNOWN AS A CONSEQUENCE OF THE USE OF THE SYSTEM.</P><P ALIGN="JUSTIFY"></P><P ALIGN');
		Contract.push				('="JUSTIFY">THE DEVELOPER DOES NOT GUARANTEE THAT THE CONTENTS OF THE SYSTEM, INSERTED AND/OR MADE AVAILABLE BY THIRD PARTIES, IS FREE FROM ');
		Contract.push				('CONTAMINATION WITH VIRUS OR OTHER CONTAMINATING, HAZARDOUS OR DESTRUCTIVE ELEMENTS. THE DEVELOPER MAKE AN EFFORT TO GUARANTEE THE RELIABILI');
		Contract.push				('TY BOTH OF THE CONTENTS AND OF THE SYSTEM, BUT IT CANNOT GUARANTEE THE ACCURACY, CORRECTION OR RELIABILITY THEREOF.</P></FONT><FONT SIZE=3>');
		Contract.push				('<P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">LIABILITY LIMITATION </P></B></FONT><FONT SIZE=3><P ALIGN="');
		Contract.push				('JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">THE DEVELOPER, ITS OFFICERS, EMPLOYEES OR AGENTS SHALL NOT BE LIABLE IN ');
		Contract.push				('THE EVENT OF ANY DIRECT, INDIRECT, ACCIDENTAL, SPECIAL, CONSEQUENT DAMAGES, ETC. (EVEN IF THE DEVELOPER HAD BEEN WARNED ON THE POSSIBILITY ');
		Contract.push				('OF SUCH DAMAGES), ARISING OUT OF: (A) THE USE OR IMPOSSIBILITY OF USE OF THE SYSTEM; (B) THE UNAUTHORIZED ACCESS, ALTERATION OF TRANSMISSIO');
		Contract.push				('NS OR DATA OF THE USERS; (C) THE STATEMENTS OR ACTS PRACTICED BY THIRD PARTIES THROUGH THE SYSTEM; (D) THE RELIABILITY OF THE USER IN ANY I');
		Contract.push				('NFORMATION OBTAINED IN THE SYSTEM OR ARISING OUT OF MISTAKES, OMISSIONS, INTERRUPTIONS, REMOVAL OF FILES, DEFECTS , VIRUSES, DELAYS IN THE ');
		Contract.push				('OPERATION OR TRANSMISSION OR PERFORMANCE FAULTS, WHETHER ARISING OUT OF <I>FORCE MAJEURE</I>, LACK OF COMMUNICATION, THEFT, DESTRUCTION OR ');
		Contract.push				('UNAUTHORIZED ACCESS TO REGISTRATIONS, PROGRAMS OR SERVICES OF THE DEVELOPER; (E) THE IMPOSSIBILITY OF USE OR LOSS OF DATA CONNECTED TO THE ');
		Contract.push				('SYSTEM OR USERS; OR (F) ANY OTHER PROBLEM RELATED TO THE SYSTEM.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdan');
		Contract.push				('a" SIZE=2><P ALIGN="JUSTIFY">REMOVALS AND LIMITATIONS </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2');
		Contract.push				('><P ALIGN="JUSTIFY">Nothing of what is written in the CGU has the purpose to remove or limit any condition, guarantee, right or liability w');
		Contract.push				('hich cannot be legally removed or limited. Some jurisdictions do not allow the removal of certain guarantees or conditions or the limitatio');
		Contract.push				('n or removal or liability for losses and damages. Consequently, only the limitations which are allowed by the law in its jurisdiction shall');
		Contract.push				('be applicable to the user.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">EARLIER T');
		Contract.push				('ERMINATION AND DISCONTINUANCE </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">Notw');
		Contract.push				('ithstanding the CGU, the Developer reserves the right of, without prior notice and in compliance with its own and sole discretion, block yo');
		Contract.push				('ur use and access to the System. The Developer, also, reserves the right of, without prior notice and according to its own and sole discret');
		Contract.push				('ion, conduct any changes in the System and/or respective functionalities (e.g. inclusion of advertising or banners, removal or modules, etc');
		Contract.push				('.), as well as discontinue the System, whether partially or as a whole.</P><B><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">VALIDITY AND EFFECT');
		Contract.push				('IVENESS OF THE CLAUSES </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">Any waiver ');
		Contract.push				('or alteration of the provisions of the CGU shall only be effective if submitted in writing and signed by the Developer legal representative');
		Contract.push				('. If one clause of the CGU is annulled or considered inapplicable, the other clauses, whenever possible, shall remain valid and effective. ');
		Contract.push				('The rights which are not expressly granted are reserved to the Developer.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FAC');
		Contract.push				('E="Verdana" SIZE=2><P ALIGN="JUSTIFY">ALTERATIONS IN THE CGU</P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" ');
		Contract.push				('SIZE=2><P ALIGN="JUSTIFY">The Developer reserves the right to alter the CGU, as well as any other policy of the System, at any moment and a');
		Contract.push				('t its own discretion. The alterations shall become effective at the moment of respective publishing in the System. The use of the System af');
		Contract.push				('ter the publishing shall be construed acceptance of possible alterations of the CGU. Thus, we advise the users to read again the CGU whenev');
		Contract.push				('er they access the System. If you do not agree with the provisions altered of the CGU, you may discontinue the use of the System.</P></FONT');
		Contract.push				('><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">APPLICABLE LAW AND JURISDICTION </P></B></FON');
		Contract.push				('T><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">Any litigation related to the use of the System');
		Contract.push				(', the services offered through the System or respective contents shall be submitted to the courthouse of the Judicial District of S&atilde;');
		Contract.push				('o Paulo, State of S&atilde;o Paulo, Brazil, which shall prevail on any other, the most privileged it shall be, and shall be judged accordin');
		Contract.push				('g to the Federative Republic of Brazil.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTI');
		Contract.push				('FY">QUESTIONS AND CLARIFICATIONS </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">Q');
		Contract.push				('uestions and comments on the System or on the CGU may be submitted to the Developer through the e-mail <B>suporte.com.br</B>.</P></FONT><hr');
		Contract.push				('><B><FONT FACE="Verdana" SIZE=2><P ALIGN="CENTER">PRIVACY POLICY </P><P ALIGN="CENTER">&quot;BROS&quot;</P></B></FONT><FONT SIZE=3><P ALIGN');
		Contract.push				('="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="CENTER">Latest Update: August 20, 2015</P></B></FONT><FONT SIZE=3><P ALIGN="');
		Contract.push				('JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">READ WITH ATTENTION:</B> WHEN ACCESSING, USING AND/OR REGISTERING WIT');
		Contract.push				('H <B>BROS</B> OPERATIONAL SYSTEM AND/OR OTHER PRODUCTS AND SERVICES MADE AVAILABLE BY <B>XPNET</B> YOU STRICTLY AGREE WITH THE PRIVACY POLI');
		Contract.push				('CIES SET FORTH HEREIN, AS WELL AS OTHER POLICIES AND/OR RULES REFERRED TO HEREIN. SHOULD YOU DISAGREE WITH ALL SUCH CONDITIONS, DO NOT USE ');
		Contract.push				('THE SYSTEM OF <B>XPNET</B>. </P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">This priva');
		Contract.push				('cy policy (hereinafter referred to as &quot;<B><U>Privacy Policy</B></U>&quot;) regulates the collection and use of information by the oper');
		Contract.push				('ational system <B>BROS</B> (hereinafter referred to as &quot;<B><U>System</B></U>&quot;), of <B>XPNET</B>. (hereinafter referred to as &quo');
		Contract.push				('t;<B><U>Developer</B></U>&quot;), available at <B>www.xpnet.com.br</B>. </P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">When using the System');
		Contract.push				(', you declare to be over 18 years old or, in the event of being a minor, to be accompanied by a legal representative and to be legally capa');
		Contract.push				('ble to accept the Privacy Policy. Should you be using the System in the name of entity and/or legal entity, you guarantee to be authorized ');
		Contract.push				('to accept the Privacy Policy in the name of respective entity and/or legal entity.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FO');
		Contract.push				('NT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">When using the System you declare to completely understand the provisions of this policy and ag');
		Contract.push				('ree with them, as well as it declares to completely understand and agree with the &quot;<B><U>General Use Conditions</B></U>&quot; (see <B>');
		Contract.push				('www.xpnet.com.br</B>). </P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">The System belongs to the Developer and may be accessed in and out of ');
		Contract.push				('Brazil. The information collected may be withheld, as well as stored, processed, accessed and used in jurisdiction whose laws referring to ');
		Contract.push				('privacy or protection of personal data are different and less comprehensive then those adopted in the jurisdiction of domicile, under Law n');
		Contract.push				('o. 12.965/2014, in force in Brazil.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">');
		Contract.push				('COLLECTION OF INFORMATION </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">When you');
		Contract.push				('access the System, personal information may be requested and collected. For instance, the following information may be collected at the mom');
		Contract.push				('ent of the registration of a new user:</P><P ALIGN="JUSTIFY"></P><UL><P ALIGN="JUSTIFY"><LI>full name;</LI></P><P ALIGN="JUSTIFY"><LI>e-mai');
		Contract.push				('l;</LI></P><P ALIGN="JUSTIFY"><LI>gender;</LI></P><P ALIGN="JUSTIFY"><LI>age;</LI></P><P ALIGN="JUSTIFY"><LI>username;</LI></P><P ALIGN="JU');
		Contract.push				('STIFY"><LI>password.</LI></P></UL><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">HOW THE DEVELOPER USES THE INFORMATION </P></B></FONT><FONT ');
		Contract.push				('SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The Developer uses the information collected for the fo');
		Contract.push				('llowing purposes:</P><P ALIGN="JUSTIFY"></P><UL><P ALIGN="JUSTIFY"><LI>making easier the identification and access of the user to the Syste');
		Contract.push				('m;</LI></P><P ALIGN="JUSTIFY"><LI>to provide the interactivity required to the System;</LI></P><P ALIGN="JUSTIFY"><LI>to perform researches');
		Contract.push				('and marketing of user\'s relationship;</LI></P><P ALIGN="JUSTIFY"><LI>to operate and perfect the System;</LI></P><P ALIGN="JUSTIFY"><LI>to a');
		Contract.push				('ssist in the creation or development of the System;</LI></P><P ALIGN="JUSTIFY"><LI>to show personalized contents, according to the interest');
		Contract.push				('s of the users; </LI></P><P ALIGN="JUSTIFY"><LI>to prepare statistics generally, including to third parties, and;</LI></P><P ALIGN="JUSTIFY');
		Contract.push				('"><LI>to provide assistance services to the user.</LI></P></UL><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">The information collected by the S');
		Contract.push				('ystem may be stored and processed in any country in which the Developer or its affiliates, subsidiaries, partners or agents have offices, a');
		Contract.push				('nd when using the System, you agree with the transference of such information abroad.</P><P ALIGN="JUSTIFY"></P><B><P ALIGN="JUSTIFY">INFOR');
		Contract.push				('MATION SHARING </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The Developer prese');
		Contract.push				('rves the privacy of the data of the user and undertakes not to share personal information with companies, organizations and other persons, ');
		Contract.push				('expect (a) if expressly authorized by you, through acceptance of a document made available by the Developer, or (b) in one of the following');
		Contract.push				('circumstances:</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P><DIR><DIR></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">&#9679; <B>for');
		Contract.push				('external processing: </B>the Developer may provide its information to companies, organization or reliable persons with purpose to process a');
		Contract.push				('nd organize them, upon confidentiality and security instructions to be provided by the Developer.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"');
		Contract.push				('></P></DIR></DIR><UL></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY"><LI>for provision of services to the Developer: </B>the Devel');
		Contract.push				('oper may share its information with companies, organizations or persons providing services in its behalf. For instance, it may contract oth');
		Contract.push				('er companies in order to store data, assist in the direct marketing, perform audit services, etc. Such companies shall receive permission f');
		Contract.push				('or obtaining only the information required to provide the service properly and shall be obliged to maintain the confidentiality of the info');
		Contract.push				('rmation, not being able to use them for any other purpose. Whenever possible and compatible with the System operations, the information sha');
		Contract.push				('ll be provided so as to preserve the anonymity of the users.</LI></P></UL></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P><DIR><DIR></FONT><FONT');
		Contract.push				('FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">&#9679;</FONT><FONT FACE="Times New Roman" SIZE=1>&#9;</FONT><B><FONT FACE="Verdana" SIZE=2>for le');
		Contract.push				('gal reasons: </B>the Developer may disclose or share your information if believes, in good faith, that the access, use, conservation or dis');
		Contract.push				('closure of the information is reasonably required in order to (a) comply with any laws, regulation, legal decision or governmental request;');
		Contract.push				('(b) comply with CGU or investigate possible breaches; (c) detect or prevent frauds and solve technical or safety matters; (d) assure the se');
		Contract.push				('curity of the System; (e) safe keep the rights and prevent liabilities of the Developer, and; (f) avoid losses to the property or safety of');
		Contract.push				('the Developer or users.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></DIR></DIR></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The');
		Contract.push				('Developer may share impersonal identification information publically attached. For instance, it may share information publically in order t');
		Contract.push				('o show a tendency on the general use of the System.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALI');
		Contract.push				('GN="JUSTIFY">WE SHALL REQUEST YOUR AUTHORIZATION BEFORE USING INFORMATION FOR PURPOSES OTHER THAN THOSE DEFINED IN THIS PRIVACY POLICY.</P>');
		Contract.push				('</FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">THE USE OF COOKIES AND OTHER TECHNOLOGI');
		Contract.push				('ES </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The System may use cookies or o');
		Contract.push				('ther identification technologies in order to assist the personalization of your experience. Cookies are small storage text files in the mem');
		Contract.push				('ory of your computer. A cookie contains information, including personal ones, which may be read after by a server located in the dominium i');
		Contract.push				('ssuing it. The information the cookies collect include date and time of your visit, navigation background, etc.</P></FONT><FONT SIZE=3><P A');
		Contract.push				('LIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The cookies bring several benefits, once they allow the identifica');
		Contract.push				('tion of old users when they return to the System, enabling the direction to personalized contents and/or comparable services. The cookies a');
		Contract.push				('lso save time, making it unnecessary to input the same information several times.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><');
		Contract.push				('FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">SAFETY OF YOUR PERSONAL INFORMATION</P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT>');
		Contract.push				('<FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The safety of the information is very important to us. We follow the safety standards of the');
		Contract.push				('sector to assist in the protection of the information collected. However, there is no electronic storage method completely safe. </P><P ALI');
		Contract.push				('GN="JUSTIFY"></P><P ALIGN="JUSTIFY">THUS, ALTHOUGH WE MAKE AN EFFORT TO PROTECT THE INFORMATION COLLECTED, WE CANNOT GUARANTEE ABSOLUTE SAF');
		Contract.push				('ETY.</P><B><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">ALTERATION IN THIS PRIVACY POLICY </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P><');
		Contract.push				('/FONT><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">The Developer reserves the right to alter the Privacy Policy, as well as any other pol');
		Contract.push				('icy of the System, at any moment and at its own discretion. The alterations shall become effective at the moment of respective publishing i');
		Contract.push				('n the System. The use of the System after publishing shall consist of acceptance of possible alterations of the Privacy Policy. Thus, we ad');
		Contract.push				('vise the users to read again the Privacy Policy whenever they access the System. If you do not agree with the Privacy Policy provisions and');
		Contract.push				('/or future versions of such policy, you may discontinue the use of the System.</P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">In the event of');
		Contract.push				('significant alterations of this Privacy Policy or of the form in which the Developer uses your information, a specific notice may be sent t');
		Contract.push				('hrough e-mail previously registered by the user.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><B><FONT FACE="Verdana" SIZE=2><P ALI');
		Contract.push				('GN="JUSTIFY">APPLICABLE LAW AND JURISDICTION </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FONT FACE="Verdana" SIZE=2><P ALIGN');
		Contract.push				('="JUSTIFY">Any litigation related to the System, respective products and services or this Privacy Policy shall be submitted to the courthou');
		Contract.push				('se of the Judicial District of S&atilde;o Paulo, State of S&atilde;o Paulo, Brazil, which shall prevail on any other, the most privileged i');
		Contract.push				('t shall be, and shall be judged under the laws of the Federative Republic of Brazil.</P></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><');
		Contract.push				('B><FONT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">QUESTIONS AND CLARIFICATIONS </P></B></FONT><FONT SIZE=3><P ALIGN="JUSTIFY"></P></FONT><FO');
		Contract.push				('NT FACE="Verdana" SIZE=2><P ALIGN="JUSTIFY">You may get in touch with the Developer, including seeking for clarifications on the Privacy Po');
		Contract.push				('licy, through the e-mail <B>suporte@xpnet.com.br</B>.</P></FONT><FONT SIZE=3></FONT>');
		//	Contract.push			('<hr>v. ' + ContractVersion);
		Contract.push				('<hr><FONT FACE="Verdana" SIZE=2>Latest Update: August 20, 2015</FONT>');
		//
		Contract.push				('</td></tr></table>');
		//
		Contract					= Contract.join("");

		// Security
		var SecurityExpected		= "";

		// EMail Sent Message
		var EMailSentMsg			= "Bros sent you an e-mail with your sign-in credentials.";
		EMailSentMsg			   += "<p>The e-mail have <b>Bros Team</b> as sender.";
		EMailSentMsg			   += "<p>and have <b>Your Bros sign in credentials</b> as subject.";
		EMailSentMsg			   += "<p>please, check your e-mail box in a few moments to get your sign-in credentials.";
		EMailSentMsg			   += "<p>The e-mail was sent to: ";

	//---------------------------------------------------------------------------
	// Main
	//---------------------------------------------------------------------------

		CreateWindow				();
		FillWindow_SignIn			();
		//	DebugSignIn				();

	//---------------------------------------------------------------------------
	// Debug Sign-In
	//---------------------------------------------------------------------------

	function DebugSignIn()
		{
		//	deb						("DebugSignIn");
		//	deb						("Bros.IsInDebug = " + Bros.IsInDebug);
		//	deb						("Bros.User.USERTOKEN = " + Bros.User.USERTOKEN);
		if ((! Bros.IsInDebug) || (Bros.User.USERTOKEN != ""))
			{
			//Bros.element("MyWindowSignIn").close();
			return;
			}
		Do_SignIn					();
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Building Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Window
	//---------------------------------------------------------------------------

	function CreateWindow()
		{
		//	deb						("CreateWindow");
		Bros
			.createelement			("window")
				.name				("MyWindowSignIn")
				.resizable			(  false)
				.onready			(function (Elem)
					{
					//	deb			("onready");			 // X (Close)	Exp/Norm	Min			ToTray		Help
					Elem.Handler.UpdateButtonsVisibility(Elem, [! false,	  false,	  false,	  false,	  false]);
					})
		Bros.parent					();
		}

	//---------------------------------------------------------------------------
	// Fill Window with Sign In
	//---------------------------------------------------------------------------

	function FillWindow_SignIn()
		{
		//	deb						("FillWindow_SignIn");
		var Left, Top, Width, Height;

		Bros
			.element				("MyWindowSignIn")
				.deletechildren		()
			;
		//---------------------------------------------------------------------------
		Top							= B_Top;
		Height						= B_Height_Input;
		Bros
				.createelement		("label")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("User Name")
			;
		Bros
				.createelement		("edit")
					.name			("MyUserName")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Bros
				.createelement		("label")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Password")
			;
		Bros
				.createelement		("edit")
					.name			("MyPassword")
					.mode			("password")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		//Bros
		//		.createelement		("label")
		//			.left			(B_Left_Cap, Top + B_Top_LabelOffset)
		//			.caption		("Remember Password")
		//	;
		Bros
				.createelement		("checkbox")
					.name			("MyAutoLogin")
					.left			(B_Left_Input, Top)
					.autosize		(! false)
					.caption		(Bros.Msg.SGI.AutoNextLogin)
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		SecurityExpected			= GetRandomSecurity();
		Bros
				.createelement		("label")
					.name			("MyLabelSecurity")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Type: <b><s>" + SecurityExpected + "</s></b>")
			;
		Bros
				.createelement		("edit")
					.name			("MySecurity")
					.left			(B_Left_Input, Top, B_Width_Input, B_Height_Input)
			;
		Bros
				.createelement		("button")
					.left			(B_Left_Cap, Top + Height + 8, 56, B_Height_Button)
					.caption		("Change")
					.onclick		(function (Elem, e) {
						//	FillWindow_CreateNewAccount();
						SecurityExpected = GetRandomSecurity();
						Bros.element("MyLabelSecurity").caption("Type: <b><s>" + SecurityExpected + "</s></b>");
						})
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Left						= B_Left_Input;
		Width						= B_Width_Button_SignIn;
		Bros
				.createelement		("button")
					.left			(Left, Top, 72, B_Height_Button)
					.caption		("<b>Sign In</b>")
					.onclick		(function (Elem, e) {
						Do_SignIn	();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_CrNewAcc;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("Create New Account (Free)")
					.onclick		(function (Elem, e) {
						FillWindow_CreateNewAccount();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_ForgPass;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("Forgot Password ?")
					.onclick		(function (Elem, e) {
						FillWindow_ForgotPassword();
						})
			;
		//---------------------------------------------------------------------------
		if (Bros.User.IsSignedIn())
			{
			Top					   += Height + B_Top_Delta;
			Left					= B_Left_Input;
			Width					= B_Width_Button_SignIn;
			Bros
				.createelement		("button")
					.left			(Left, Top, 72, B_Height_Button)
					.caption		("<b>Sign Out</b>")
					.onclick		(function (Elem, e) {
						Do_SignOut	();
						})
			;
			}
		//---------------------------------------------------------------------------
		Width						= B_Left_Input + B_Width_Input + B_Width_WinOffset;
		Height						= Top + B_Height_Button + B_Top_Delta + B_Height_WinOffset;
		SetWindowDim				(Width, Height, "Sign In");
		}

	//---------------------------------------------------------------------------
	// Fill Window with Create New Account
	//---------------------------------------------------------------------------

	function SetWindowDim(Width, Height, Caption)
		{
		//	deb						("SetWindowDim", Width, Height);
		Bros
			.element				("MyWindowSignIn")
				.caption			(Caption)
				//	.width			(Width + 40,	Height + 40)
				// ABOVE IS A GAMB ! Changing Windows, sometimes, scrollbars appears. So, enlarge a little bit then shrink solved the problem!
				//	.width			(Width,			Height)
				// NO ! NO ! NO ! Did not solved. I made var GAMB = 10; (see on top program)
				.width				(Width,			Height)
				.centralize			()
			;
		}

	//---------------------------------------------------------------------------
	// Fill Window with Create New Account
	//---------------------------------------------------------------------------

	function FillWindow_CreateNewAccount()
		{
		//	deb						("FillWindow_CreateNewAccount");
		var Left, Top, Width, Height;

		Bros
			.element				("MyWindowSignIn")
				.deletechildren		()
			;
		//---------------------------------------------------------------------------
		Top							= B_Top;
		Height						= B_Height_Input;
		Bros
				.createelement		("label")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Your e-mail")
			;
		Bros
				.createelement		("edit")
					.name			("YourEMail")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Height						= B_Height_Input;
		Bros
				.createelement		("label")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
					.caption		("(you will receive your sign in credentials by e-mail)")
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		SecurityExpected			= GetRandomSecurity();
		Bros
				.createelement		("label")
					.name			("MyLabelSecurity")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Type: <b><s>" + SecurityExpected + "</s></b>")
			;
		Bros
				.createelement		("edit")
					.name			("MySecurity")
					.left			(B_Left_Input, Top, B_Width_Input, B_Height_Input)
			;
		Bros
				.createelement		("button")
					.left			(B_Left_Cap, Top + Height + 8, 56, B_Height_Button)
					.caption		("Change")
					.onclick		(function (Elem, e) {
						//	FillWindow_CreateNewAccount();
						SecurityExpected = GetRandomSecurity();
						Bros.element("MyLabelSecurity").caption("Type: <b><s>" + SecurityExpected + "</s></b>");
						})
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Height						= 300;
		//Bros
		//		.createelement		("label")
		//			.left			(B_Left_Cap, Top + B_Top_LabelOffset)
		//			.caption		("Remember Password")
		//	;
		Bros
				.createelement		("panel")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
					.borderstyle	(Bros.bsEdit)
					.color			(Bros.clWhite)
					.selectable		(! false)
					.scrollbars		("both")
					.html			(Contract)
					.parent			()
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Height						= B_Height_Input;
		//Bros
		//		.createelement		("label")
		//			.left			(B_Left_Cap, Top + B_Top_LabelOffset)
		//			.caption		("Remember Password")
		//	;
		Bros
				.createelement		("checkbox")
					.name			("CB_IAgree")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
					.caption		("I Agree the contract")
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Left						= B_Left_Input;
		Width						= B_Width_Button_SignIn;
		Bros
				.createelement		("button")
					.left			(Left, Top, 72, B_Height_Button)
					.caption		("Sign In")
					.onclick		(function (Elem, e) {
						FillWindow_SignIn();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_CrNewAcc;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("<b>Create New Account (Free)</b>")
					.onclick		(function (Elem, e) {
						Do_CreateNewAccount();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_ForgPass;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("Forgot Password ?")
					.onclick		(function (Elem, e) {
						FillWindow_ForgotPassword();
						})
			;
		//---------------------------------------------------------------------------
		Width						= B_Left_Input + B_Width_Input + B_Width_WinOffset;
		Height						= Top + B_Height_Button + B_Top_Delta + B_Height_WinOffset;
		SetWindowDim				(Width, Height, "Create New Account (Free)");
		}

	//---------------------------------------------------------------------------
	// Get Random Security
	//---------------------------------------------------------------------------

	function GetRandomSecurity()
		{
		//	deb						("GetRandomSecurity");
		var Security				= Math.round(Math.random(10000) * 10000);
		if (Security				< 1000)
			{
			//	deb					("Security [" + Security + "] < 1000");
			Security			   += 1000;
			}
		return Security;
		}

	//---------------------------------------------------------------------------
	// Fill Window with Forgot Password
	//---------------------------------------------------------------------------

	function FillWindow_ForgotPassword()
		{
		//	deb						("FillWindow_ForgotPassword");
		var Left, Top, Width, Height;

		Bros
			.element				("MyWindowSignIn")
				.deletechildren		()
			;
		//---------------------------------------------------------------------------
		Top							= B_Top;
		Height						= B_Height_Input;
		Bros
				.createelement		("label")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Your e-mail")
			;
		Bros
				.createelement		("edit")
					.name			("YourEMail")
					.left			(B_Left_Input, Top, B_Width_Input, Height)
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		SecurityExpected			= GetRandomSecurity();
		Bros
				.createelement		("label")
					.name			("MyLabelSecurity")
					.left			(B_Left_Cap, Top + B_Top_LabelOffset)
					.caption		("Type: <b><s>" + SecurityExpected + "</s></b>")
			;
		Bros
				.createelement		("edit")
					.name			("MySecurity")
					.left			(B_Left_Input, Top, B_Width_Input, B_Height_Input)
			;
		Bros
				.createelement		("button")
					.left			(B_Left_Cap, Top + Height + 8, 56, B_Height_Button)
					.caption		("Change")
					.onclick		(function (Elem, e) {
						//	FillWindow_CreateNewAccount();
						SecurityExpected = GetRandomSecurity();
						Bros.element("MyLabelSecurity").caption("Type: <b><s>" + SecurityExpected + "</s></b>");
						})
			;
		//---------------------------------------------------------------------------
		Top						   += Height + B_Top_Delta;
		Left						= B_Left_Input;
		Width						= B_Width_Button_SignIn;
		Bros
				.createelement		("button")
					.left			(Left, Top, 72, B_Height_Button)
					.caption		("Sign In")
					.onclick		(function (Elem, e) {
						FillWindow_SignIn();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_CrNewAcc;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("Create New Account (Free)")
					.onclick		(function (Elem, e) {
						FillWindow_CreateNewAccount();
						})
			;
		Left					   += Width + B_Left_ButtonOffset;
		Width						= B_Width_Button_ForgPass;
		Bros
				.createelement		("button")
					.left			(Left, Top, Width, B_Height_Button)
					.caption		("<b>Send-me an e-mail</b>")
					.onclick		(function (Elem, e) {
						Do_ForgotPassword();
						})
			;
		//---------------------------------------------------------------------------
		Width						= B_Left_Input + B_Width_Input + B_Width_WinOffset;
		Height						= Top + B_Height_Button + B_Top_Delta + B_Height_WinOffset;
		SetWindowDim				(Width, Height, "Forgot Password ?");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Close Window
	//---------------------------------------------------------------------------

	function CloseWindow()
		{
		//	deb						("CloseWindow");
		Bros
			.elementpush			()
			.element				("MyWindowSignIn")
				.close				()
			.elementpop				()
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Create New Account Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create New Account
	//---------------------------------------------------------------------------

	function Do_CreateNewAccount()
		{
		//	deb						("Do_CreateNewAccount");
		//	return;
		//	Bros.ClearMsgsContainer	();

		// Get Values
		var EMail					= Bros.element("YourEMail").text();
		var Security				= Bros.element("MySecurity").text();
		var IAgree					= Bros.element("CB_IAgree").value();
		//	deb						("EMail = " + EMail, "Security = " + Security, "SecurityExpected = " + SecurityExpected, "IAgree = " + IAgree);

		// For Testing
		//	EMail					= "Andre.Garcia@TRixtec.com.bR";
		//	Security				= SecurityExpected;
		//	IAgree					= 1;

		// Validate Params
		var ErrorMsg				= "";
		ErrorMsg				   += Bros.EMail_Validate(EMail);						// EMail
		ErrorMsg				   += Validate_Security(Security, SecurityExpected);	// SecurityExpected
		ErrorMsg				   += Validate_IAgree(IAgree);							// Agree ?
		if (ErrorMsg != "")																// Error ?
			{
			//	Bros.ShowError		(ErrorMsg, CloseWindow);
			// Here does not close window to allow user to correct fields
			Bros.ShowError			(ErrorMsg);
			return;
			}
		//	return;

		// Setup Params and Sends Request
		var Params					= {
		//	 EMail					: "andre.garcia@trixtec.com.br"
			 EMail					: EMail
			,ContractVersion		: ContractVersion
			,Contract				: Contract
			//	,Contract			: "Test"
			}
		Bros.User.U_SendRequestOnResult("CreateNewAccount", Params, function (ErrorMsg)
			{
			//	deb					("Do_CreateNewAccount, ErrorMsg :<hr>" + (ErrorMsg == "" ? "No Errors" : ErrorMsg) + "<hr>");
			//	return;
			if (ErrorMsg != "")
				{
				//	Bros.ShowError	("Error occur:\n\n" + ErrorMsg, CloseWindow);
				// Here does not close window to allow user to do something (if possible)
				Bros.ShowError		("Error occur:\n\n" + ErrorMsg);
				return;
				}
			// For Testing
			//	Bros.ShowMsg		(EMailSentMsg + "<b>" + EMail + "</b>");
			//	return;
			Bros.ShowMsg			(EMailSentMsg + "<b>" + EMail + "</b>", CloseWindow);
			});
		}

	//---------------------------------------------------------------------------
	// Validate I Agree
	//---------------------------------------------------------------------------

	function Validate_IAgree(IAgree)
		{
		//	deb						("Validate_IAgree", IAgree);
		if (IAgree != 1)
			return "If need to agree the contract terms to use Bros for free.<p>";
		return "";
		}

	//---------------------------------------------------------------------------
	// Validate Security
	//---------------------------------------------------------------------------

	function Validate_Security(Security, SecurityExpected)
		{
		//	deb						("Validate_Security", Security, SecurityExpected);
		if (Bros.SkipTypeVerify && Bros.IsInDebug)					// For fast sign-in debug
			return "";
		if (Security == "")
			return "Please, fill the field <b>Type: <s>" + SecurityExpected + "</s></b> with the showed value.<p>";
		if (Security != SecurityExpected)
			return "Please, fill the field <b>Type: <s>" + SecurityExpected + "</s></b> with the <b>correct</b> showed value.<br>(press <b>Change</b> to switch value if desired)<p>";
		return "";
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Forgot Password Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Forgot Password
	//---------------------------------------------------------------------------

	function Do_ForgotPassword()
		{
		//	deb						("Do_ForgotPassword");
		//	return;
		//	Bros.ClearMsgsContainer	();

		// Get Values
		var EMail					= Bros.element("YourEMail").text();
		var Security				= Bros.element("MySecurity").text();
		//	deb						("EMail = " + EMail, "Security = " + Security, "SecurityExpected = " + SecurityExpected);

		// For Testing
		//	EMail					= "aNDre.Garcia@TRixtec.com.bR";
		//	EMail					= "Andre.Garcia@TRixtec.com.bR";
		//	EMail					= "Andre.Garcia@XPnet.com.bR";
		//	Security				= SecurityExpected;
		//	deb						("EMail = " + EMail, "Security = " + Security, "SecurityExpected = " + SecurityExpected);

		// Validate Params
		var ErrorMsg				= "";
		ErrorMsg				   += Bros.EMail_Validate(EMail);						// EMail
		ErrorMsg				   += Validate_Security(Security, SecurityExpected);	// SecurityExpected
		if (ErrorMsg != "")																// Error ?
			{
			//	Bros.ShowError		(ErrorMsg, CloseWindow);
			// Here does not close window to allow user to correct fields
			Bros.ShowError			(ErrorMsg);
			return;
			}
		//	return;

		// Setup Params and Sends Request
		var Params					= {
			 EMail					: EMail
			}
		Bros.User.U_SendRequestOnResult("ForgotPassword", Params, function (ErrorMsg)
			{
			//	deb					("ErrorMsg = " + ErrorMsg);
			//	return;
			if (ErrorMsg != "")
				{
				//	Bros.ShowError	("Error occur:\n\n" + ErrorMsg, CloseWindow);
				// Here does not close window to allow user to do something (if possible)
				Bros.ShowError		("Error occur:\n\n" + ErrorMsg);
				//Bros.ShowError	("Error occur:\n\n" + ErrorMsg, function (Elem)
				//	{
				//	//	deb			("OnClose ShowError");
				//	CloseWindow		();
				//	});
				return;
				}
			// For Testing
			//	Bros.ShowMsg		(EMailSentMsg + "<b>" + EMail + "</b>");
			//	return;
			Bros.ShowMsg			(EMailSentMsg + "<b>" + EMail + "</b>", CloseWindow);
			//Bros.ShowMsg			(EMailSentMsg + "<b>" + EMail + "</b>", function ()
			//	{
			//	//	deb				("OnClose ShowMsg");
			//	CloseWindow			();
			//	});
			});
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Sign In/Out Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Sign In
	//---------------------------------------------------------------------------

	function Do_SignIn()
		{
		//	deb						("Do_SignIn");
		//	return;
		//	Bros.ClearMsgsContainer	();

		// Get Values
		var MyUserName				= Bros.element("MyUserName").text();
		var MyPassword				= Bros.element("MyPassword").text();
		var MySecurity				= Bros.element("MySecurity").text();
		var MyAutoLogin				= ((Bros.element("MyAutoLogin").value() == 1) ? "S" : "N");
		//	alert					("MyAutoLogin = " + MyAutoLogin);

		// For Testing
		//	if (Bros.IsInDebug)
		//		{
		//		if (MyUserName == "")
		//			{
		//			MyUserName		= "UTEST";
		//			MyPassword		= "PTEST";
		//			//
		//			MySecurity		= SecurityExpected;
		//			}
		//		}
		//	deb						("MyUserName = " + MyUserName, "MyPassword = " + MyPassword, "MySecurity = " + MySecurity, "SecurityExpected = " + SecurityExpected);

		// Validate Params
		var ErrorMsg				= "";
		ErrorMsg				   += Bros.User.Validate_UserName(MyUserName);			// MyUserName
		ErrorMsg				   += Bros.User.Validate_Password(MyPassword);			// MyPassword
		ErrorMsg				   += Validate_Security(MySecurity, SecurityExpected);	// SecurityExpected
		if (ErrorMsg != "")																// Error ?
			{
			//	Bros.ShowError		(ErrorMsg, CloseWindow);
			// Here does not close window to allow user to correct fields
			Bros.ShowError			(ErrorMsg);
			return;
			}
		//	return;

		// Do_SignIn
		Bros.User.Do_SignIn(MyUserName, MyPassword, MyAutoLogin, function (ErrorMsg)
			{
			//	deb					("ErrorMsg = " + ErrorMsg);
			//	return;
			if (ErrorMsg != "")
				{
				//	Bros.ShowError	("Error occur:\n\n" + ErrorMsg, CloseWindow);
				// Here does not close window to allow user to do something (if possible)
				Bros.ShowError		(ErrorMsg);
				return;
				}
			// For Testing
			//	Bros.ShowMsg		("Sign-in OK !", CloseWindow);
			//	deb					("Sign-in OK !");
			// If ErrorMsg == "" this code will NOT be reached because Bros.User.Do_SignInOK will call Bros.RebootUser instead
			CloseWindow				();
			});
		}

	//---------------------------------------------------------------------------
	// Sign Out
	//---------------------------------------------------------------------------

	function Do_SignOut()
		{
		//	deb						("Do_SignOut");
		// Close the window first to avoid saving it as an open window
		Bros.element("MyWindowSignIn").close();

		// Do_SignOut
		Bros.User.Do_SignOut		();
		}

//###########################################################################
//###########################################################################
