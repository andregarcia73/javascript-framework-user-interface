//###########################################################################
//###########################################################################
//##
//## Bros Application - Navigator
//##
//###########################################################################
//###########################################################################

	//---------------------------------------------------------------------------
	// Bros Application - Navigator
	//---------------------------------------------------------------------------

		//	deb						("App_SiteBrowser", "Application.AppArguments = " + Application.AppArguments);
		//	PCS						(Application);

		// Temporary adjustment
		var URL						= Application.AppArguments;
// ???
		if (Bros.IsInDebug)
			{
			if (URL.substr(0, 8) == "Programs")
				URL					= "../../3_Site/" + URL;
			}
		//	deb						("App_SiteBrowser", "Application.AppArguments = " + Application.AppArguments, "URL = " + URL);

		var ID_ToUse				= "BrosB_999_" + Bros.NextElementID;

		var Result					= [];

		// http://jsfiddle.net/BXSbt/8/
		Result.push					("<div style='");
		Result.push					("width:100%;");
		Result.push					("height:100%;");
		Result.push					("position:relative;");
		Result.push					("'>");

		Result.push					("<iframe");
		Result.push					(" id='If_" + ID_ToUse + "'");
		Result.push					(" style='");
		Result.push					("width:100%;");
		Result.push					("height:100%;");
		Result.push					("border:none;");
		Result.push					("background-color:FFFFFF;");
		//	Result.push				("background:transparent;");		// http://jsfiddle.net/BXSbt/8/
		Result.push					("'");
		Result.push					(" src='" + URL + "'");
		//	Result.push				(" allowtransparency=\"true\"");	// http://jsfiddle.net/BXSbt/8/
		//	Result.push				(" onmouseout='document.getElementById(\"Ov_" + ID_ToUse + "\").style.visibility = \"visible\";'"); // Works but I bind below
		Result.push					(" >");
		Result.push					("</iframe>");

		// http://jsfiddle.net/BXSbt/8/
		Result.push					("<div");
		Result.push					(" id='Ov_" + ID_ToUse + "'");
		Result.push					(" style='");
		Result.push					("left:0;");
		Result.push					("top:0;");
		Result.push					("width:100%;");
		Result.push					("height:100%;");
		Result.push					("position:absolute;");
		Result.push					("'");
		Result.push					(" onmousedown='this.style.visibility = \"hidden\";'");
		Result.push					(">");
		//	Result.push				("Overlay " + ID_ToUse);
		Result.push					("</div>");

		// First div
		Result.push					("</div>");

		Bros
			.createelement			("window")
//.left				(810, 10, 450, 480)
//.left				(50,  20, 700, 350)
.width				(700, 350)
				.onready			(function (Elem)
					{
					NavWindow		= Elem;
					NavWindow.ID_ToUse = ID_ToUse;
					})
				.createelement		("panel")
					.align			("client")
					.borderstyle	(Bros.bsEdit)
					.selectable		(! false)
					.html			(Result.join(""))
					.parent			()
			;

		// Bind events
		$("#If_" + ID_ToUse).mouseout(function (e)
			{
			$("#Ov_" + ID_ToUse)
				.css				("visibility", "visible");
			})

		// OnHideWindow
		NavWindow.OnHideWindow		= function (Bobj)
			{
			//	deb					("NavWindow.OnHideWindow", Bros.CElm.WhoAmI(Bobj), "Bobj.ID_ToUse = " + Bobj.ID_ToUse);
			// That is because when user click on overlay it disappear (as it need to), then when mouses out iframe (appear) and minimize, overlay
			// stay on top (but window not) so, if user click on (colorless but visible) overlay the window reappear (as it need NOT to)
			$("#Ov_" + Bobj.ID_ToUse)
				.css				("visibility", "hidden");
			};

		// OnShowWindow
		NavWindow.OnShowWindow		= function (Bobj)
			{
			//	deb					("NavWindow.OnHideWindow", Bros.CElm.WhoAmI(Bobj), "Bobj.ID_ToUse = " + Bobj.ID_ToUse);
			// That is because when user click on overlay it disappear (as it need to), then when mouses out iframe (appear) and minimize, overlay
			// stay on top (but window not) so, if user click on (colorless but visible) overlay the window reappear (as it need NOT to)
			$("#Ov_" + Bobj.ID_ToUse)
				.css				("visibility", "visible");
			};

//###########################################################################
//###########################################################################
