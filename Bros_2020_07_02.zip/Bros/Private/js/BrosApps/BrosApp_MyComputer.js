//###########################################################################
//###########################################################################
//##
//## Bros Application - My Computer
//##
//###########################################################################
//###########################################################################

		// Clear container Bros Messages
		//if (Bros.IsInDebug)
		//	Bros.ClearMsgsContainer	();

		// Data Inputs
		var DI_Menu_Appearance		= null;
		var DI_Menu_User_Credentials= null;
		var DI_Menu_Add_Program		= null;

		// User Credentials
		var User_Cred				= {};
		User_Cred.USERDNAME			= "";
		User_Cred.USERNAME			= "";
		User_Cred.USERPASS			= "";
		User_Cred.New_USERNAME		= "";
		User_Cred.New_USERPASS		= "";
		User_Cred.New_USERPASS_C	= "";

		// Add Program
		var AddP					= {};
		AddP.StartMenu				= "";
		AddP.Caption				= "";
		AddP.ImageSrc				= "";
		AddP.ScriptSrc				= "";
		AddP.Arguments				= "";

		// Definitions
		var Have_Selector			= ! Bros.lib.sys.isonmobile();
		//	Have_Selector			=   false;
		// XPTBROSPUBLIC
		var Value_WebSite			= Bros.FS.A_BrosPrivate_Js_BApps + "BrosApp_Navigator.js";
		var Caption_SelectAProgram	= Bros.Msg.PHR.SelectAProgram;
		//
		// XPTNONEOPTION
		var Option_None				= "XXXNONEXXX";

		// Aspect
		var SelectorPanel_Width		= 150;
		//
		var ButtonsImage_WidthHeight= 16;
		//
		var Labels_Height			= 20;

		// For LabelDatas
		var LabD					= {
			 Left					: 24
			,Top					:  0
			//
			,Width					:  0
			//
			,Spacement				:  6
			};

		// Define IP (IP = ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_MyComputer/";

		// ProgramOptions
		var ProgramOptions			= [
			 {Caption:Bros.Msg.WRD.Appearance,		ImageSrc:IP + "Img_105_Appearance.png",	ShortCut:"",	RunMethod:Menu_Appearance			}
			,{Caption:Bros.Msg.PHR.UserCredentials,	ImageSrc:IP + "Img_110_UserCred.png",	ShortCut:"",	RunMethod:Menu_User_Credentials		}
			,{Caption:Bros.Msg.PHR.AddProgram,		ImageSrc:IP + "Img_120_AddProgram.png",	ShortCut:"",	RunMethod:Menu_Add_Program			}
			];

		// Creates the Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// What to Build ?
		//	AppC.MainMenu.Build		= ! false;
		AppC.ButtonsPanel.Build		= Bros.IsInDebug;
		AppC.StatusPanel.Build		=   false;

		// Window Caption
		APPC.windowcaption			(AppC, Bros.Msg.PHR.MyComputer);

		// Main Menu
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.Options);
		if (Bros.IsInDebug)
			APPC.addmenuitemreload	(AppC);
		// ProgramOptions
		for (var i = 0; i < ProgramOptions.length; i++)
			{
			var ProgramOption		= ProgramOptions[i];
			APPC.addmenuitem		(AppC, ProgramOption.Caption, ProgramOption.ImageSrc, ProgramOption.ShortCut, ProgramOption.RunMethod)	.Set("ShowButton", ! false)	.Set("ShowMenuSpaceBefore", (i == 0) && Bros.IsInDebug);
			}
		APPC.endmenufolder			(AppC);

		// Define Here your Status Panel
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");


		// Now, everything will be created automatically for you
		APPC.createall				(AppC);

		// Creates MainWindow
		Create_MainWindow			();

	//===========================================================================
	//===========================================================================
	//==
	//== Creation Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Creates MainWindow
	//---------------------------------------------------------------------------

	function Create_MainWindow()
		{
		//	deb						("Create_MainWindow");

		// Creates Selector
		Create_Selector				();

		// Creates Work Panel
		Bros
			.createelement			("panel")
				.name				("WorkPanel")
				.align				("client")
				.borderstyle		(Bros.bsEdit)
				.scrollbars			("both")
				.parent				()
			;
		}

	//---------------------------------------------------------------------------
	// Creates Selector
	//---------------------------------------------------------------------------

	function Create_Selector()
		{
		//	deb						("Create_Selector", Have_Selector);

		// Have ?
		if (! Have_Selector)
			return;

		// Creates Panel
		Bros
			.createelement			("panel")
				.align				("left")
				.width				(SelectorPanel_Width)
				.borderstyle		(Bros.bsEdit)
			;

		// ProgramOptions
		for (var i = 0; i < ProgramOptions.length; i++)
			{
			var ProgramOption		= ProgramOptions[i];
			Bros
				.createelement		("button")
					.caption		(ProgramOption.Caption)
					.imagesrc		(ProgramOption.ImageSrc)
					.align			("top")
					.imagewidth		(ButtonsImage_WidthHeight, ButtonsImage_WidthHeight)
					.halign			("left")
					.borderstyle	(Bros.bsNone)
					.ispushpull		(! false)
					// NOT WORKING !!
					//	.onclickon	("down")
					.onready		(function (Elem)
						{
						// Stores
						Elem.ProgramOption	= ProgramOption;
						ProgramOption.SelectorButton = Elem;
						})
					.onclick		(function (Elem, e)
						{
						//	PCS		(Elem.ProgramOption);
						// WHILE onclickon("down") not work
						if (Bros.value() == 0)
							{
							Clear_Window();
							return;
							}
						//	Update_Window	(Elem.ProgramOption.Caption);	// Work on button but not on speed button
						Elem.ProgramOption.RunMethod();
						})
				//.createelement		("panel")
				//	.align			("top")
				//	.height			(10)
				//	.borderstyle	(Bros.bsNone)
				//	.parent			()
				;
			}

		// End
		Bros.parent					();
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Get Program Option by Caption
	//---------------------------------------------------------------------------

	function GetProgramOption(ProgramOption_Caption)
		{
		//	deb						("GetProgramOption", ProgramOption_Caption);

		// Search
		for (var i = 0; i < ProgramOptions.length; i++)
			{
			var ProgramOption		= ProgramOptions[i];
			if (ProgramOption.Caption == ProgramOption_Caption)
				return ProgramOption;
			}

		// Not Found !
		Bros.FatalErrorMNO			("GetProgramOption", "Program Option not found.", "ProgramOption_Caption = " + ProgramOption_Caption);
		}

	//---------------------------------------------------------------------------
	// Clear Window
	//---------------------------------------------------------------------------

	function Clear_Window()
		{
		//	deb						("Clear_Window");

		// Clear WorkPanel
		Bros
			.element				("WorkPanel")
				.deletechildren		()
				//	.html			("C")
			;

		// Releases all buttons
		if (Have_Selector)
			{
			for (var i = 0; i < ProgramOptions.length; i++)
				{
				var TempProgramOption= ProgramOptions[i];
				Bros.element		(TempProgramOption.SelectorButton).value(0);
				}
			}
		}

	//---------------------------------------------------------------------------
	// Update Window according the Program Option Caption
	//---------------------------------------------------------------------------

	function Update_Window(ProgramOption_Caption)
		{
		//	deb						("Update_Window", ProgramOption_Caption);

		// Get Program Option
		var ProgramOption			= GetProgramOption(ProgramOption_Caption);
		//	PCS						(ProgramOption);

		// Releases other buttons (and set the current Program Option in case of firing via Menu)
		if (Have_Selector)
			{
			for (var i = 0; i < ProgramOptions.length; i++)
				{
				var TempProgramOption= ProgramOptions[i];
				Bros.element		(TempProgramOption.SelectorButton).value(TempProgramOption == ProgramOption ? 1 : 0);
				}
			}
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Menu Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_Appearance
	//---------------------------------------------------------------------------

	function Menu_Appearance()
		{
		//	deb						("Menu_Appearance");

		// Update Window
		Update_Window				(Bros.Msg.WRD.Appearance);

		Menu_Appearance_DI_Create	();
		Bros.lib.di.build			(DI_Menu_Appearance, "WorkPanel");
		}

	//---------------------------------------------------------------------------
	// Menu_User_Credentials
	//---------------------------------------------------------------------------

	function Menu_User_Credentials()
		{
		//	deb						("Menu_User_Credentials");

		// Update Window
		Update_Window				(Bros.Msg.PHR.UserCredentials);

		Menu_User_Credentials_DI_Create();

		User_Cred.USERDNAME			= Bros.User.USERDNAME;
		User_Cred.USERNAME			= "";
		User_Cred.USERPASS			= "";
		User_Cred.New_USERNAME		= "";
		User_Cred.New_USERPASS		= "";
		User_Cred.New_USERPASS_C	= "";

		Bros.lib.di.build			(DI_Menu_User_Credentials, "WorkPanel");
		}

	//---------------------------------------------------------------------------
	// Menu_Add_Program
	//---------------------------------------------------------------------------

	function Menu_Add_Program()
		{
		//	deb						("Menu_Add_Program");

		// Update Window
		Update_Window				(Bros.Msg.PHR.AddProgram);

		Menu_Add_Program_DI_Create();
		}

	//===========================================================================
	//===========================================================================
	//==
	//== New Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Setup Common DI Properties
	//---------------------------------------------------------------------------

	function SetupCommonDI(DI)
		{
		//	deb						("SetupCommonDI");
		//	PCS						(DI, ! false);
		//	DI.Panel_Top_Props.Color= "FFFFFF";
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Appearance
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_Appearance_DI_Create
	//---------------------------------------------------------------------------

	function Menu_Appearance_DI_Create()
		{
		//	deb						("Menu_Appearance_DI_Create", DI_Menu_Appearance);

		// Created ?
		if (DI_Menu_Appearance != null)
			return;
		//	deb						("Menu_Appearance_DI_Create (CREATING)");

		// Default Preferences
		//	deb						("Bros.Lib.Langs.Languages = " + Bros.Lib.Langs.Languages);
		//	for (var i = 0; i < Bros.Lib.Langs.Languages.length; i++)
		//		{
		//		PCS					(Bros.Lib.Langs.Languages[i]);
		//		}
		//	var MyLang				= Bros.Lib.Arr.ObjGet (Bros.Lib.Langs.Languages, "PropName", Bros.User.Pref.SysLanguage, "Menu_Appearance_DI_Create");
		// Above was raising error if not found, so, changed to below
		var MyLang					= Bros.Lib.Arr.ObjFind(Bros.Lib.Langs.Languages, "PropName", Bros.User.Pref.SysLanguage);
		if (MyLang == null)
			MyLang					= Bros.User.Pref;				// If not found, get properties from Bros.User.Pref
		//	deb						("MyLang = " + MyLang);
		//	PCS						(MyLang);
		//	deb						(MyLang.ThousandSeparator);

		// Creates
		DI_Menu_Appearance			= Bros.lib.di.getnew(Bros.Msg.WRD.Appearance, "BrosPublic:/img/BrosApps/BrosApp_MyComputer/Img_105_Appearance.png");
		var DI						= DI_Menu_Appearance;			// For code elegance
		SetupCommonDI				(DI);

		// XPTLANGUAGE
		// Languages
		Bros.lib.di.additem			(DI, Bros.Msg.WRD.Language,				Bros.User.Pref,		"SysLanguage");
		var Lang;
		//	deb						("Bros.Lib.Langs.Languages.length = " + Bros.Lib.Langs.Languages.length);
		for (var i = 0; i < Bros.Lib.Langs.Languages.length; i++)
			{
			var Lang				= Bros.Lib.Langs.Languages[i];
			//	PCS					(Lang);
			Bros.lib.di.addoption	(DI,									Lang.Caption,		Lang.PropName);
			}

		// Style
		Bros.lib.di.additem			(DI, Bros.Msg.WRD.Style,				Bros.User.Pref,		"Sysc_SelectValue");
		for (var i = 0; i < Bros.SyscStyles.length; i++)
			{
			var SyscStyle			= Bros.SyscStyles[i];
			//	PCS					(SyscStyle);
			Bros.lib.di.addoption	(DI,									SyscStyle.Caption,	SyscStyle.SelectValue);
			}

		// Preferences
		var Pars					= {};
		Bros.lib.di
			.additem				(DI, Bros.Msg.PHR.AnimateWindows,		Bros.User.Pref,		"AnimateWindows",		! false)
			//
			.additem				(DI, "",								"",					Appear_Number_Get(Bros.User.Pref.ThousandSeparator, Bros.User.Pref.DecimalChar))
				.set				(DI, "onready", function (Item)
					{
					Pars.CapNumber	= Item;
					})
			.additem				(DI, Bros.Msg.PHR.ThousandSeparator,	Bros.User.Pref,		"ThousandSeparator",	MyLang.ThousandSeparator)
				.addoption			(DI, Bros.Msg.WRD.Comma + " (,)",		",")
				.addoption			(DI, Bros.Msg.WRD.Dot	+ " (.)",		".")
			// XPTNONEOPTION
			//	.addoption			(DI, Bros.Msg.WRD.None,					Option_None)
				.set				(DI, "onready", function (Item)
					{
					Pars.ThousandSeparator = Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			.additem				(DI, Bros.Msg.PHR.DecimalSeparator,		Bros.User.Pref,		"DecimalChar",			MyLang.DecimalChar)
				.addoption			(DI, Bros.Msg.WRD.Dot	+ " (.)",		".")
				.addoption			(DI, Bros.Msg.WRD.Comma + " (,)",		",")
				.set				(DI, "onready", function (Item)
					{
					Pars.DecimalSeparator = Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			//
			// DateFormat
			//
			.additem				(DI, "",								"",					Appear_Date_Get(Bros.User.Pref.DateFormat))
				.set				(DI, "onready", function (Item)
					{
					Pars.CapDate	= Item;
					})
			.additem				(DI, Bros.Msg.PHR.DateFormat,			Bros.User.Pref,		"DateFormat",			MyLang.DateFormat)
				.addoption			(DI, "%mm/%dd/%yyyy")
				.addoption			(DI, "%dd/%mm/%yyyy")
				.set				(DI, "onready", function (Item)
					{
					Pars.DateFormat	= Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			//
			// DateTimeFormat
			//
			.additem				(DI, "",								"",					Appear_DateTime_Get(Bros.User.Pref.DateTimeFormat))
				.set				(DI, "onready", function (Item)
					{
					Pars.CapDateTime= Item;
					})
			.additem				(DI, Bros.Msg.PHR.DateTimeFormat,		Bros.User.Pref,		"DateTimeFormat",		MyLang.DateTimeFormat)
				.addoption			(DI, "%mm/%dd/%yyyy %hh:%nn")
				.addoption			(DI, "%mm/%dd/%yyyy %hh:%nn:%ss")
				.addoption			(DI, "%mm/%dd/%yyyy %hh:%nn:%ss:%iii")
				//
				.addoption			(DI, "%dd/%mm/%yyyy %hh:%nn")
				.addoption			(DI, "%dd/%mm/%yyyy %hh:%nn:%ss")
				.addoption			(DI, "%dd/%mm/%yyyy %hh:%nn:%ss:%iii")
				.set				(DI, "onready", function (Item)
					{
					Pars.DateTimeFormat	= Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			//
			// TimeFormat
			//
			.additem				(DI, "",								"",					Appear_Time_Get(Bros.User.Pref.TimeFormat))
				.set				(DI, "onready", function (Item)
					{
					Pars.CapTime	= Item;
					})
			.additem				(DI, Bros.Msg.PHR.TimeFormat,			Bros.User.Pref,		"TimeFormat",			MyLang.TimeFormat)
				.addoption			(DI, "%hh:%nn")
				.addoption			(DI, "%hh:%nn:%ss")
				.addoption			(DI, "%hh:%nn:%ss:%iii")
				.set				(DI, "onready", function (Item)
					{
					Pars.TimeFormat	= Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			//
			// YearTo2000
			//
			.additem				(DI, "",								"",					Appear_Year_Get(Bros.User.Pref.YearTo2000))
				.set				(DI, "onready", function (Item)
					{
					Pars.CapYearTo2000 = Item;
					})
			.additem				(DI, Bros.Msg.PHR.YearTo2000,			Bros.User.Pref,		"YearTo2000",			30)
				.addoption			(DI,  0)
				.addoption			(DI, 10)
				.addoption			(DI, 20)
				.addoption			(DI, 30)
				.addoption			(DI, 40)
				.addoption			(DI, 50)
				.addoption			(DI, 60)
				.addoption			(DI, 70)
				.addoption			(DI, 80)
				.addoption			(DI, 90)
				.set				(DI, "onready", function (Item)
					{
					Pars.FormatYearTo2000 = Item;
					})
				.set				(DI, "onchange", function (Item)
					{
					UpdateItems		(DI, Pars);
					})
			;

		// Buttons
		Bros.lib.di
			.addbutton				(DI, Bros.Msg.VRB.Cancel,				"BrosPublic:/img/Icons/_16/Icon_Cancel.png", function (Elem)		// BrosPublic:/img/Icons/_16/Icon_Restore.png
				{
				Bros.lib.di.restore	(DI);
				UpdateItems			(DI, Pars);
				})
			.addbutton				(DI, Bros.Msg.WRD.Defaults,				"BrosPublic:/img/Icons/_16/Icon_Default.png", function (Elem)
				{
				Bros.lib.di.defaults(DI);
				UpdateItems			(DI, Pars);
				})
			.addbutton				(DI, Bros.Msg.VRB.Apply,				"BrosPublic:/img/Icons/_16/Icon_OK.png", function (Elem)			// BrosPublic:/img/Icons/_16/Icon_Apply.png
				{
				Bros.lib.di.apply	(DI);

				// XPTNONEOPTION
				// Temporarily disabled due to too much confusion because select assumes value as Caption when option value is ""
				// Converts Option_None
				//	deb				("Bros.User.Pref.ThousandSeparator = " + Bros.User.Pref.ThousandSeparator);
				//	if (Bros.User.Pref.ThousandSeparator == Option_None)
				//		Bros.User.Pref.ThousandSeparator = "";

				// Language or Style Changed ?
				var Lang_Changed	= Bros.lib.di.item(DI, Bros.User.Pref, "SysLanguage")		.get(DI, "changed");
				//var Style_Changed	= Bros.lib.di.item(DI, Bros.User.Pref, "Sysc_SelectValue")	.get(DI, "changed");	// Line commented after New implementations (below)
				//	deb				("Lang_Changed = " + Lang_Changed, "Style_Changed = " + Style_Changed);

				// If changes the language, Apply Language Preferences
				if (Lang_Changed)
					Bros.Lib.Langs.Lang_ApplyPref();
				//	alert			("OOOPS, before reboot");

				// New implementation (reboot if something changed). This is necessary, for example, on QTabs where it reads DateTime format on setup and need to boot to gqt new settings)
				// If something changed, save and reboot
				if (Bros.Lib.DI.SomethingChanged(DI))
					{
					Bros.User.Sysc_Change(Bros.User.Pref.Sysc_SelectValue, ! false);	// Force = ! false
					// Return here because Sysc_Change already save config
					return;
					}

				// Old implementation (reboot only if changed Language or Style)
				//	if (Lang_Changed || Style_Changed)
				//		{
				//		Bros.User.Sysc_Change(Bros.User.Pref.Sysc_SelectValue, ! false);	// Force = ! false
				//		// Return here because Sysc_Change already save config
				//		return;
				//		}
				//
				//	// Save Config
				//	Bros.User.Config.Save(function (ErrorMsg)
				//		{
				//		if (Bros.lib.dlg.didshowerror(ErrorMsg))
				//			return;
				//		});
				})
			//.addbutton			(DI, "OK",							"BrosPublic:/img/Icons/_16/Icon_OK.png", function (Elem)
			//	{
			//	Bros.lib.di.apply	(DI);
			//	// Usually put here close the window code
			//	})
			;

		//	PCS						(DI, ! false, ! false);
		}

	//---------------------------------------------------------------------------
	// Get Number Appearance example
	//---------------------------------------------------------------------------

	function Appear_Number_Get(ThousandSeparator, DecimalChar)
		{
		//	deb						("Appear_Number_Get", ThousandSeparator, DecimalChar);
		return Bros.Msg.PHR.NumbersAppearanceEG		+ ": <b>" + Bros.Lib.Num.ToStr(1234.56, -1, ThousandSeparator, DecimalChar) + "</b>";
		}

	//---------------------------------------------------------------------------
	// Get Date Appearance example
	//---------------------------------------------------------------------------

	function Appear_Date_Get(Format)
		{
		//	deb						("Appear_Date_Get", Format);
	// XPTUTCDATE
	//	return Bros.Msg.PHR.DateAppearanceEG		+ ": <b>" + Bros.Lib.Date.ToStr(new Date(), Format) + "</b>";
	// XPTUTCDATE
		return Bros.Msg.PHR.DateAppearanceEG		+ ": <b>" + Bros.Lib.UDate.ToStr(Bros.Lib.UDate.GetNewDate(), Format) + "</b>";
		}

	//---------------------------------------------------------------------------
	// Get DateTime Appearance example
	//---------------------------------------------------------------------------

	function Appear_DateTime_Get(Format)
		{
		//	deb						("Appear_DateTime_Get", Format);
	// XPTUTCDATE
	//	return Bros.Msg.PHR.DateTimeAppearanceEG	+ ": <b>" + Bros.Lib.Date.ToStr(new Date(), Format) + "</b>";
	// XPTUTCDATE
		return Bros.Msg.PHR.DateTimeAppearanceEG	+ ": <b>" + Bros.Lib.UDate.ToStr(Bros.Lib.UDate.GetNewDate(), Format) + "</b>";
		}

	//---------------------------------------------------------------------------
	// Get Time Appearance example
	//---------------------------------------------------------------------------

	function Appear_Time_Get(Format)
		{
		//	deb						("Appear_Time_Get", Format);
	// XPTUTCDATE
	//	return Bros.Msg.PHR.TimeAppearanceEG		+ ": <b>" + Bros.Lib.Date.ToStr(new Date(), Format) + "</b>";
	// XPTUTCDATE
		return Bros.Msg.PHR.TimeAppearanceEG		+ ": <b>" + Bros.Lib.UDate.ToStr(Bros.Lib.UDate.GetNewDate(), Format) + "</b>";
		}

	//---------------------------------------------------------------------------
	// Get Year Appearance example
	//---------------------------------------------------------------------------

	function Appear_Year_Get(Format)
		{
		//	deb						("Appear_Year_Get", Format);
		var Result					= "";
		for (var Year = 0; Year < 100; Year += 10)
			{
			if (Year <= Format)
				Result				   += "<b>20" + (Year == 0 ? "00" : Year) + "</b>";
			else
				Result				   += "19" + (Year == 0 ? "00" : Year);
			Result					   += " ";
			}
		return Result;
		}

	//---------------------------------------------------------------------------
	// Update Number Appearance
	//---------------------------------------------------------------------------

	function UpdateItems(DI, Pars)
		{
		//	deb						("UpdateItems", DI, Pars);

		//---------------------------------------------------------------------------
		// Number appearance
		//---------------------------------------------------------------------------

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Pars.CapNumber)			.get(DI, "componentelement");
		var Elem_Thous				= Bros.lib.di.item(DI, Pars.ThousandSeparator)	.get(DI, "componentelement");
		var Elem_Decim				= Bros.lib.di.item(DI, Pars.DecimalSeparator)	.get(DI, "componentelement");

		// Gets the values
		var Value_Thous				= Bros.element(Elem_Thous).value();
		var Value_Decim				= Bros.element(Elem_Decim).value();
		// XPTNONEOPTION
		//	deb						(Value_Thous, Value_Decim);

		// Adjust the Values
		switch (Value_Thous)
			{
			case ",":
				Value_Decim			= ".";
				break;
			case ".":
				Value_Decim			= ",";
				break;
			// XPTNONEOPTION
			default:				// Converts Option_None
				Value_Thous			= "";
			}

		// Update Decimal Element
		Bros.element(Elem_Decim).value(Value_Decim).text(Value_Decim == "." ? Bros.Msg.WRD.Dot + " (.)" : Bros.Msg.WRD.Comma + " (,)");

		// Update Number Appearance example
		Bros.element(Elem_Label).caption(Appear_Number_Get(Value_Thous, Value_Decim));

		//---------------------------------------------------------------------------
		// Date appearance
		//---------------------------------------------------------------------------

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Pars.CapDate)			.get(DI, "componentelement");
		var Elem_Value				= Bros.lib.di.item(DI, Pars.DateFormat)			.get(DI, "componentelement");

		// Gets the values
		var Value					= Bros.element(Elem_Value).value();
		//	deb						("Value = " + Value);

		// Update Appearance example
		Bros.element(Elem_Label).caption(Appear_Date_Get(Value));

		//---------------------------------------------------------------------------
		// Date Time appearance
		//---------------------------------------------------------------------------

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Pars.CapDateTime)		.get(DI, "componentelement");
		var Elem_Value				= Bros.lib.di.item(DI, Pars.DateTimeFormat)		.get(DI, "componentelement");

		// Gets the values
		var Value					= Bros.element(Elem_Value).value();
		//	deb						("Value = " + Value);

		// Update Appearance example
		Bros.element(Elem_Label).caption(Appear_DateTime_Get(Value));

		//---------------------------------------------------------------------------
		// Time appearance
		//---------------------------------------------------------------------------

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Pars.CapTime)			.get(DI, "componentelement");
		var Elem_Value				= Bros.lib.di.item(DI, Pars.TimeFormat)			.get(DI, "componentelement");

		// Gets the values
		var Value					= Bros.element(Elem_Value).value();
		//	deb						("Value = " + Value);

		// Update Appearance example
		Bros.element(Elem_Label).caption(Appear_Time_Get(Value));

		//---------------------------------------------------------------------------
		// YearTo2000 appearance
		//---------------------------------------------------------------------------

		// Gets the elements
		var Elem_Label				= Bros.lib.di.item(DI, Pars.CapYearTo2000)		.get(DI, "componentelement");
		var Elem_Value				= Bros.lib.di.item(DI, Pars.FormatYearTo2000)	.get(DI, "componentelement");

		// Gets the values
		var Value					= Bros.element(Elem_Value).value();
		//	deb						("Value = " + Value);

		// Update Appearance example
		Bros.element(Elem_Label).caption(Appear_Year_Get(Value));
		}

	//===========================================================================
	//===========================================================================
	//==
	//== User Credentials
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_User_Credentials_DI_Create
	//---------------------------------------------------------------------------

	function Menu_User_Credentials_DI_Create()
		{
		//	deb						("Menu_User_Credentials_DI_Create", DI_Menu_User_Credentials);

		// Created ?
		if (DI_Menu_User_Credentials != null)
			return;
		//	deb						("Menu_User_Credentials_DI_Create (CREATING)");

		// Creates
		DI_Menu_User_Credentials	= Bros.lib.di.getnew(Bros.Msg.PHR.UserCredentials,	"BrosPublic:/img/BrosApps/BrosApp_MyComputer/Img_110_UserCred.png");
		var DI						= DI_Menu_User_Credentials;		// For code elegance
		SetupCommonDI				(DI);

		// Configures
		var C						= "<br>(" + Bros.Msg.WRD.Confirmation.toLowerCase() + ")";
		Bros.lib.di
			.additem				(DI, Bros.Msg.PHR.UserDisplayName,	User_Cred,		"USERDNAME")
			.additem				(DI, Bros.Msg.PHR.CurrentUserName,	User_Cred,		"USERNAME")
			.additem				(DI, Bros.Msg.PHR.CurrentPassword,	User_Cred,		"USERPASS")			.set(DI, "type", "password")
			.additem				(DI, Bros.Msg.PHR.NewUserName,		User_Cred,		"New_USERNAME")
			.additem				(DI, Bros.Msg.PHR.NewPassword,		User_Cred,		"New_USERPASS")		.set(DI, "type", "password")
			.additem				(DI, Bros.Msg.PHR.NewPassword + C,	User_Cred,		"New_USERPASS_C")	.set(DI, "type", "password")
			.addbutton				(DI, Bros.Msg.VRB.Change,							"BrosPublic:/img/Icons/_16/Icon_OK.png", function (Elem)
				{
				//	PCS				(User_Cred);
				Bros.lib.di.apply	(DI);
				//	PCS				(User_Cred);
				DoChangeCredentials	();
				})
			;
		}

	//---------------------------------------------------------------------------
	// Do Change Credentials
	//---------------------------------------------------------------------------

	function DoChangeCredentials(OnClose)
		{
		//	deb						("DoChangeCredentials");

		// Recover Values
		var Cred					= User_Cred;

		// Analize
		var ErrorMsg				= "";

		// Blanks ?
		if (Cred.USERDNAME		== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.UserDisplayName	+ "<p>";
		if (Cred.USERNAME		== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.CurrentUserName	+ "<p>";
		if (Cred.USERPASS		== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.CurrentPassword	+ "<p>";
		if (Cred.New_USERNAME	== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.NewUserName		+ "<p>";
		if (Cred.New_USERPASS	== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.NewPassword		+ "<p>";
		if (Cred.New_USERPASS_C	== "")	ErrorMsg += Bros.Msg.VRB.Supply + ": " + Bros.Msg.PHR.NewPassword + " (" + Bros.Msg.WRD.Confirmation.toLowerCase() + ")" + "<p>";

		// Match password ?
		if (Cred.New_USERPASS != Cred.New_USERPASS_C)
			ErrorMsg			   += Bros.Msg.PHR.NewPassword + " " + Bros.Msg.PHR.DoesNotMatch.toLowerCase()	+ "<p>";

		// Error ?
		if (ErrorMsg != "")
			{
			Bros.lib.dlg.showerror	(ErrorMsg, function ()
				{
				//	Bros.RunOnResult(OnClose, ErrorMsg);
				});
			// Clear data ? NO ! allows user to change them.
			return;
			}

		// For Testing
		//	var Cred				= {};
		//	Cred.USERDNAME			= "Andre Garcia!339";
		//	Cred.USERNAME			= "3";
		//	Cred.USERPASS			= "3";
		//	Cred.New_USERNAME		= "3";
		//	Cred.New_USERPASS		= "3";
		//	//	Cred.USERDNAME		= "";
		//	//	Cred.USERNAME		= "";
		//	//	Cred.USERPASS		= "";
		//	//	Cred.New_USERNAME	= "";
		//	//	Cred.New_USERPASS	= "";
		//	//
		//	//	Cred.USERDNAME		= "Andre D";
		//	//	Cred.USERNAME		= "C";
		//	//	Cred.USERPASS		= "C";
		//	//	Cred.New_USERNAME	= "D";
		//	//	Cred.New_USERPASS	= "D";

		// Change Credentials
		Bros.User.ChangeCredentials(Cred, function (ErrorMsg)
			{
			//	deb					("Bros.User.Change Credentials, ErrorMsg = " + ErrorMsg);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			//	Credentials Changed
			Bros.lib.dlg.showmsg	(Bros.Msg.PHR.CredentialsChanged, function ()
				{
				Clear_Window		();
				//	Bros.RunOnResult(OnClose, "");
				})
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Add_Program_DI_Create
	//---------------------------------------------------------------------------

	function Menu_Add_Program_DI_Create()
		{
		//	deb						("Menu_Add_Program_DI_Create", DI_Menu_Add_Program);

		// Created ?
		if (DI_Menu_Add_Program != null)
			{
			Menu_Add_Program_DI_Build();
			return;
			}
		//	deb						("Menu_Add_Program_DI_Create (CREATING)");

		// Creates
		DI_Menu_Add_Program			= Bros.lib.di.getnew(Bros.Msg.PHR.AddProgram,		"BrosPublic:/img/BrosApps/BrosApp_MyComputer/Img_120_AddProgram.png");
		var DI						= DI_Menu_Add_Program;			// For code elegance
		SetupCommonDI				(DI);

		// Define the ImgPathMenu
		var ImgPathMenu				= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS;

		// Configures
		Bros.lib.di.additem			(DI, Bros.Msg.PHR.StartMenu,			AddP,			"StartMenu")
			.addoption				(DI, Bros.Msg.PHR.WebSites,				Bros.MenuName_WebSites, ImgPathMenu + "Img_Men_Start_1_WebSites.gif")
			.addoption				(DI, Bros.Msg.WRD.Personal,				Bros.MenuName_Personal, ImgPathMenu + "Img_Men_Start_2_Personal.gif")
			;
		Bros.lib.di.additem			(DI, Bros.Msg.WRD.Caption,				AddP,			"Caption");
		Bros.lib.di.additem			(DI, Bros.Msg.PHR.ImageSource,			AddP,			"ImageSrc")
			.set					(DI, "popupmenu.imagewidth",			32)
			.set					(DI, "popupmenu.imageheight",			32)
			.addparentoption		(DI, "Icons")
			;

		// Reads Available Icons 32
		var This					= this;
		var FullFileName			= "BrosPublic:/img/Icons/_32";
		// XPTADJUSTROOTFOLDER
		//	var FullFileName		= "ReadOnly_Bros:/img/Icons/_32";
		Bros.lib.fs.getfilefolders(FullFileName, function(ErrorMsg, FFs)	// FFs = Result FileFolderInfo
			{
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			//	deb					("FFs.length = " + FFs.length);
			var Path				= Bros.FS.A_BrosPublic_Img_I32;
			for (var i = 0; i < FFs.length; i++)
				{
				var FF				= FFs[i];
				//	PCS				(FF);
				//	deb				(FF.NAME, Path + FF.NAME);
				Bros.lib.di
					.addoption		(DI, FF.NAME, Path + FF.NAME, Path + FF.NAME)
					;
				}

			// Continue
			Bros.lib.di.additem		(DI, Bros.Msg.PHR.ScriptSource,			AddP,			"ScriptSrc")
				.addoption			(DI, Bros.Msg.PHR.WebSite,				Value_WebSite)
				.addoption			(DI, Caption_SelectAProgram)
				.set				(DI, "onchange", function (Item)
					{
					Bros.Lib.DI.SetCurrentItem(DI, AddP, "ScriptSrc");
					var Elem		= Bros.lib.di.get(DI, "componentelement");
					//	deb			("onchange");
					//	PCS			(Elem);
					//	deb			(Bros.value() == Caption_SelectAProgram, Bros.value());
					if (Bros.value() != Caption_SelectAProgram)
						return;
					Bros.lib.dlg.fileopen(function (ErrorMsg, FullFileName)
						{
						//	deb		(" Bros.lib.dlg.fileopen", ErrorMsg, FullFileName);
						if (Bros.DidShowError(ErrorMsg))
							return;
						if (FullFileName == "")
							return;
						Bros.element(Elem)
							.text	(FullFileName)
							.value	(FullFileName)
							;
						});
					})
				;
			Bros.lib.di.additem		(DI, Bros.Msg.PHR.ApplicationArguments,	AddP,			"Arguments");
			Bros.lib.di.addbutton	(DI, Bros.Msg.PHR.AddProgram,							"BrosPublic:/img/Icons/_16/Icon_Plus.png", function (Elem)		// BrosPublic:/img/Icons/_16/Icon_OK.png
				{
				Bros.lib.di.apply	(DI);
				//	PCS				(AddP);
				DoAddProgram			(function (ErrorMsg)
					{
					//	deb				("ErrorMsg = " + ErrorMsg);
					if (ErrorMsg != "")
						return;
					Bros.User.Config.Save(function (ErrorMsg)
						{
						// Realized that does not fire errors if is not signed-in
						//	deb	("ErrorMsg = " + ErrorMsg);
						if (Bros.lib.dlg.didshowerror(ErrorMsg))
							return;
						//	if (ErrorMsg != "")
						//		{
						//		Bros.ShowError("Save Config error:\n\n" + ErrorMsg);
						//		return;
						//		}
						//	Bros.ShowMsg("User Config Saved !");
						});
					});
				})
				;

			Menu_Add_Program_DI_Build();
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Add_Program_DI_Build
	//---------------------------------------------------------------------------

	function Menu_Add_Program_DI_Build()
		{
		//	deb						("Menu_Add_Program_DI_Build");
		AddP.StartMenu				= "";
		AddP.Caption				= "";
		AddP.ImageSrc				= "";
		AddP.ScriptSrc				= "";
		AddP.Arguments				= "";
		//
		Bros.lib.di.build			(DI_Menu_Add_Program, "WorkPanel");
		}

	//---------------------------------------------------------------------------
	// Do Add Program
	//---------------------------------------------------------------------------

	function DoAddProgram(OnClose)
		{
		//	deb						("DoAddProgram");
		var Elem					= {};
		Elem.startmenu				= AddP.StartMenu;
		// Provide here somehow
		//	Elem.name				= Bros.element("AddP_Name")			.value();
		Elem.caption				= AddP.Caption;
		Elem.imagesrc				= AddP.ImageSrc;
		Elem.scriptsrc				= AddP.ScriptSrc;
		Elem.apparguments			= AddP.Arguments;
		Elem.singleinstance			=   false;
		//	PCS						(Elem);
		//	Bros.FatalErrorMNO		("DoAddProgram", "Stopped for Testing");


		// Analize
		var ErrorMsg				= "";

		// startmenu
		if (Elem.startmenu == "")
			ErrorMsg			   += Bros.Msg.PHR.SelectAStartMenu			+ "<p>";

		// caption
		if (Elem.caption == "")
			ErrorMsg			   += Bros.Msg.PHR.SupplyACaption			+ "<p>";

		// imagesrc
		if (Elem.imagesrc == "")
			ErrorMsg			   += Bros.Msg.PHR.SelectAnImage			+ "<p>";

		// scriptsrc
		if (Elem.scriptsrc == "")
			ErrorMsg			   += Bros.Msg.PHR.SelectOneScriptSource	+ "<p>";

		// apparguments
		if ((Elem.apparguments == "") && (Elem.scriptsrc == Value_WebSite))
			ErrorMsg			   += Bros.Msg.PHR.SelectAppArgsAsURL		+ "<p>";

		// Error ?
		if (ErrorMsg != "")
			{
			Bros.ShowError			(ErrorMsg, function ()
				{
				Bros.RunOnResult	(OnClose, ErrorMsg);
				});
			return;
			}

		// Add A Program
		//	PCS						(Elem);
		Bros.elementpush			()
			.createelement			("application")
				.startmenu			(Elem.startmenu)
				// Apply here when Provide here somehow above
				//	.name			(Elem.name)						// Apply Name to allow refresh find the named application
				.caption			(Elem.caption)
				.imagesrc			(Elem.imagesrc)
				.scriptsrc			(Elem.scriptsrc)
				.apparguments		(Elem.apparguments)
				// Eliminate here when Provide here somehow above
				.onready			(function (Elem)
					{
					//	PCS			(Elem);
					Bros.name		(Elem.Name);					// Apply Name to allow refresh find the named application
					})
			.elementpop				()
			;

		// Informs
		Bros.ShowMsg				(Bros.Msg.PHR.ProgramAdded, function ()
			{
			Clear_Window			();
			Bros.RunOnResult		(OnClose, ErrorMsg);
			});
		}

//###########################################################################
//###########################################################################
