//###########################################################################
//###########################################################################
//##
//## Bros Application - Application Manual
//##
//###########################################################################
//###########################################################################

	//---------------------------------------------------------------------------
	// Build Window
	//---------------------------------------------------------------------------

		var Panel_Width				= 347;
		var Panel_Height			= 285;

		// For Study Methods
		var Do_ShowElementsInheritance		=   false;
		var Do_ShowElementsMethods			=   false;
		var Do_AnalyzeHelpPages				=   false;
		//
		//	Do_ShowElementsInheritance		= ! false;
		//	Do_ShowElementsMethods			= ! false;
		//	Do_AnalyzeHelpPages				= ! false;				// Uncomment here to see if all Elements and Methods are implemented here
		//
		var TabToUse						= "[tab]";

		var DebugShowBeforeAPI				=   false;
		//	DebugShowBeforeAPI				= ! false;

		var ShowElapsedTimes				=   false;
		//	ShowElapsedTimes				= ! false;

		// For calculations
		var WindowLeft						=   10;
		var WindowTop						=   10;
		var WindowWidth						= 1250;
		var WindowHeight					=  540;

		var PanelLeftWidth					=  240;					// was 180
		var PanelMiddleWidth				=  620;					// Math.round(2 * (WindowWidth - PanelLeftWidth) / 3);
		var PanelMsgsHeight					=  200;					// Math.round(WindowHeight / 3);
		var PanelMsgs						= null;

		var PanelLeftSpacement				= "";
		for (var i = 1; i < 37; i++)
			PanelLeftSpacement			   += "&nbsp;"

		var MyWindow;
		Bros
			.createelement					("window")
				.caption					(Bros.Msg.PHR.BrosApp_LCenter)
				.left						(WindowLeft, WindowTop, WindowWidth, WindowHeight)
				.onready					(function (Elem)
					{
					MyWindow				= Elem;
					})

				// Left Panel
				.createelement				("panel")
					.name					("PanelLeft")
					.width					(PanelLeftWidth)
					.parent					()
				.createelement				("splitter")
					.align					("left")
					.borderstyle			(Bros.bsNone)

				// Middle Panel
				.createelement				("panel")
					.align					("left")
					.width					(PanelMiddleWidth)
					.borderstyle			(Bros.bsNone)

					// Middle Top Panel
					.createelement			("panel")
						.borderstyle		([])
						.height				(200)
						.align				("top")
						.createelement		("panel")
							.name			("PanelRight")
							.width			(180)
							.parent			()
						.createelement		("splitter")
							.align			("right")
							.borderstyle	(Bros.bsNone)
						.createelement		("panel")
							.name			("PanelTop")
							.parent			()
						.parent				()
					.createelement			("splitter")
						.align				("top")
						.borderstyle		(Bros.bsNone)

					// Middle Bottom Panel
					.createelement			("panel")
						.borderstyle		([])
						.align				("client")

						// Bottom Top Panel
						.createelement		("panel")
							.borderstyle	([])
							.align			("top")
							.height			(39)
							.createelement	("button")
								.left		(7, 7, 75, 25)
								.caption	("Run again")
								.onclick	(function(Elem, e)
									{
									Run		();
									})
							.createelement	("button")
								.left		(90, 7, 75, 25)
								.name		("HelpBack")
								.caption	("Help Back")
								.visible	(  false)
								.onclick	(function (Elem, e)
									{
									HelpBack();
									})
							.createelement	("button")
								.left		(173, 7, 75, 25)
								.caption	("Clear Msgs")
								.onclick	(function (Elem, e)
									{
									Bros.ClearMsgsContainer();
									})
							.createelement	("checkbox")
								.name		("AutoRun")
								.left		(256, -2, 75, 25)
								.autosize	(! false)
// XPTBUGAPPLC App Learning Center setiing checkbox value 1
//.deb		("AAAA")
.value		(1)
//.deb		("BBBB")
.value		(0)
								.caption	("Run on each link click")
							.createelement	("checkbox")
								.name		("AutoClearMsgs")
								.left		(256, 17, 75, 25)
								.autosize	(! false)
								.caption	("Clear Msgs on each Run")
							.parent			()

						// Bottom Bottom editarea
						.createelement		("editarea")
							.name			("EditArea")
							.mode			("codeeditor")
							.align			("client")
						.parent				()
					.parent					()
				.createelement				("splitter")
					.align					("left")
					.borderstyle			(Bros.bsNone)

				.createelement				("panel")
					.borderstyle			([])
					.align					("top")
					.height					(PanelMsgsHeight)
					.onready				(function (Elem)
						{
						PanelMsgs			= Elem;
						})
					.parent					()
				.createelement				("splitter")
					.align					("top")
					.borderstyle			(Bros.bsNone)

					.createelement			("panel")
						.name				("ExecutionPanel")
						.borderstyle		(Bros.bsEdit)
						.align				("client")
						.color				("808080")
						//	.color			("3A6EA5")
						//	.color			("AAAAAA")
						.scrollbars			("both")
						.parent				()
			;

		Bros.BuildMsgsContainer		(PanelMsgs, Bros.bsEdit);
		UpdatePanel					("PanelLeft",	"left");
		UpdatePanel					("PanelRight",	"right");
		UpdatePanel					("PanelTop",	"client");
//return;

		// Configure Help Pages
		var HelpPages				= [];
		ConfigureHelpPages			();

		// Build Panel Left (index)
		BuildPanelLeft				();

		// Processed Links
		var ProcessedLinks			= [];

		// To avoid infinite recursion in GetScriptToRun
		var GSTR_LoopCount			= 0;
		var GSTR_LoopCount_Max		= 20;

		// Restore values
		var Last_AutoRun			= Number(Bros.Cookie_Retrieve("Bros_AppLearningCenter_AutoRun"));
		var Last_AutoClearMsgs		= Number(Bros.Cookie_Retrieve("Bros_AppLearningCenter_AutoClearMsgs"));
// BUG HERE
Bros.element			("AutoRun")
	.value				(1);
		//	deb						(Last_AutoRun, Last_AutoClearMsgs);
		if ((Last_AutoRun != null) && (Last_AutoClearMsgs != null))
			{
			Bros.element			("AutoRun")
				.value				(Last_AutoRun)
				.element			("AutoClearMsgs")
				.value				(Last_AutoClearMsgs)
				;
			}

		// Debug
		if (Bros.IsInDebug)
			{
			var Last_LinkType		= Bros.Cookie_Retrieve("Bros_AppLearningCenter_LinkType");
			var Last_LinkName		= Bros.Cookie_Retrieve("Bros_AppLearningCenter_LinkName");
			var Last_LinkTextStr	= Bros.Cookie_Retrieve("Bros_AppLearningCenter_LinkTextStr");
			//	deb					("Last_LinkType = " + Last_LinkType, "Last_LinkName = " + Last_LinkName);
			if ((Last_LinkType != null) && (Last_LinkName != null))
				{
				ProcessLink			({LinkType:Last_LinkType, LinkName:Last_LinkName, LinkTextStr:Last_LinkTextStr});
				//	Run				();								// Simulates Run button click
				}
			}
		else
			{
			// Starts in main page (but not run !)
			ProcessLink				({LinkType:"Bros",		LinkName:"Hello_World", "LinkTextStr":"Bros"	});
			}

		// For Study Methods
		if (Bros.IsInDebug && Do_ShowElementsInheritance)
			ShowElementsInheritance	();
		if (Bros.IsInDebug && Do_ShowElementsMethods)
			ShowElementsMethods		();
		if (Bros.IsInDebug && Do_AnalyzeHelpPages)
			AnalyzeHelpPages		();


	//---------------------------------------------------------------------------
	// UpdatePanel
	//---------------------------------------------------------------------------

	function UpdatePanel(PanelName, Align)
		{
		//	deb						("UpdatePanel", PanelName, Align);
		Bros
			.elementpush			()
			.element				(PanelName)
			.align					(Align)
			.halign					("left")
			.valign					("top")
			.selectable				(! false)
			.borderstyle			(Bros.bsEdit)
			.color					("FFFFFF")
			.scrollbars				("both")
			.elementpop				()
			;
		};

	//---------------------------------------------------------------------------
	// Run
	//---------------------------------------------------------------------------

	function Run()
		{
		//	deb						("Run", Bros.element("EditArea").value());

		// Auto Clear Msgs ?
		if (Bros.element("AutoClearMsgs").value())
			Bros.ClearMsgsContainer	();

		// ShowElapsedTimes ?
		if (Bros.IsInDebug && ShowElapsedTimes)
			{
			Bros.___R				();
			Bros.___B				();
			}

		// Disable All Window Timers
		Bros.CTim.DisableAllTimers	();

		var ToRun					= Bros.element("EditArea").value();
		Bros.element				("ExecutionPanel")
			.html					("")
			;
		Bros.DeleteChildElements	(Bros.Cobj);
		try
			{
// Bros.Eval !!
			eval					(ToRun);
			}
		catch (e)
			{
			Bros.FatalErrorMNO		("Bros.BrosApp_App_Manual", "Error:<br>" + Bros.GetErrorDescription(e), "ToRun = <pre>" + ToRun + "</pre>");
			}

		// ShowElapsedTimes ?
		if (Bros.IsInDebug && ShowElapsedTimes)
			Bros.___E				("Run Elapsed");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Methods to build a page
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Update some Panel HTML
	//---------------------------------------------------------------------------

	function UpdatePanelHTML(Result, PanelName)
		{
		//	deb						("UpdatePanelHTML", PanelName);

		var Temp					= [];

		// CSS
		PushStyles					(Temp);

		// Table beguin
		Temp.push					("<table border=0 cellpadding=" + Bros.ApplyZoom(2) + " width=100%>");
		Temp.push					("<tr>");
		Temp.push					("<td style='font-size:" + Bros.ApplyZoom(Bros.Sysc.Prps_Win.Font.size) + "'>");

		// Content
		Temp.push					(Result.join(""));

		// Table end
		Temp.push					("</td>");
		Temp.push					("</tr>");
		Temp.push					("</table>");

		// Result
		Bros.element				(PanelName)
			.html					(Temp.join(""))
			;

		// Apply jQuery
		ApplyjQuery					();
		}

	//---------------------------------------------------------------------------
	// PushStyles
	//---------------------------------------------------------------------------

	function PushStyles(Result)
		{
		//	deb						("PushStyles");
		Bros.Push_CSS_Beguin		(Result);
		//
		Bros.Push_CSS_Class_B		(Result, "BrosAppManual_Link");
		Bros.Push_CSS_Class			(Result, "color",				"0000FF");
		Bros.Push_CSS_Class_E		(Result);
		//
		Bros.Push_CSS_Class_B		(Result, "BrosAppManual_TB");
		Bros.Push_CSS_Class_E		(Result);
		//
		Bros.Push_CSS_Class_B		(Result, "BrosAppManual_TD");
		Bros.Push_CSS_Class			(Result, "padding",		0);
		Bros.Push_CSS_Class			(Result, "white-space",			"nowrap");
		Bros.Push_CSS_Class			(Result, "font-size",			Bros.ApplyZoom(Bros.Sysc.Prps_Win.Font.size));
		Bros.Push_CSS_Class_E		(Result);
		//
		Bros.Push_CSS_End			(Result);
		}

	//---------------------------------------------------------------------------
	// Apply jQuery
	//---------------------------------------------------------------------------

	function ApplyjQuery()
		{
		//	deb						("ApplyjQuery");
		$(".BrosAppManual_Link")
			.hover					(function (e)
				{
				//	deb				("In");
				$(this)
					.css			("text-decoration", "underline")
					.css			("cursor",			"pointer")
					;
				}, function ()
				{
				//	deb				("Out");
				$(this)
					.css			("text-decoration", "none")
					;
				})
			.click					(function (e)
				{
				Bros.StopEventPropagation(e);
				//	deb				($(this).attr("Tag_LinkType"), $(this).attr("Tag_LinkName"), $(this).attr("Tag_TextStr"));
				ProcessLink			({"LinkType": $(this).attr("Tag_LinkType"), "LinkName": $(this).attr("Tag_LinkName"), "LinkTextStr": $(this).attr("Tag_TextStr")});
				})
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Get LinkID
	//---------------------------------------------------------------------------

	function GetLinkID(LinkType, LinkName)
		{
		//	deb						("GetLinkID", LinkType, LinkName, MyWindow.ElementID);
		return LinkType + LinkName + MyWindow.ElementID;
		};

	//---------------------------------------------------------------------------
	// Set Link Aspect
	//---------------------------------------------------------------------------

	function SetLinkAspect(LinkObj, On)
		{
		//	deb						("SetLinkAspect", GetLinkID(LinkObj.LinkType, LinkObj.LinkName));
		$("#" + GetLinkID(LinkObj.LinkType, LinkObj.LinkName))
		//	.css					("font-weight",			(On ? "bold"	: "normal"))
			.css					("background-color",	(On ? "C0C0C0"	: "FFFFFF"))
			;
		};

	//---------------------------------------------------------------------------
	// Build and return some link
	//---------------------------------------------------------------------------

	function GetLink(TextStr, LinkType, LinkName)
		{
		//	deb						("GetLink", TextStr, LinkType, LinkName);
		var Result					= "";
		Result					   += "<span class='BrosAppManual_Link' ";
		Result					   += " id='" + GetLinkID(LinkType, LinkName) + "' ";
		Result					   += " Tag_LinkType='"		+ LinkType	+ "'";
		Result					   += " Tag_LinkName='"		+ LinkName	+ "'";
		Result					   += " Tag_TextStr='"		+ TextStr	+ "'";
		//	Result				   += " onclick='deb(\""	+ LinkName	+ "\");' ";
		Result					   += ">";
		Result					   += TextStr;
		Result					   += "</span>";
		return Result;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Link Processing Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// ProcessLink
	//---------------------------------------------------------------------------

	function ProcessLink(LinkObj)
		{
		//	deb						("ProcessLink");
		//	PCS						(LinkObj);
		//	return;	
		//	Bros.___R				();
		//	Bros.___B				();
		//	Bros.___L				("ProcessLink start");

		// Is already showing ?
		// (Works but I disable it to reload same page in case to reload example script)
		//if (ProcessedLinks.length > 0)
		//	{
		//	var LastLinkObj			= ProcessedLinks[ProcessedLinks.length - 1];
		//	if ((LinkObj.LinkType == LastLinkObj.LinkType) && (LinkObj.LinkName == LastLinkObj.LinkName))
		//		return;
		//	}

		// Set Links Aspect
		if (ProcessedLinks.length > 0)
			SetLinkAspect			(ProcessedLinks[ProcessedLinks.length - 1], false);		// Off
		SetLinkAspect				(LinkObj, ! false);										// On

		// Set MyWindow as Bros current element to get access to named elements
		// (it's necessary here because this event is not controlled by Bros)
		Bros.element				(MyWindow);
	
		BuildOtherPanels			(LinkObj);

		// Store in Processed Links
		ProcessedLinks.push			(LinkObj);

		// Update HelpBack button visibility
		Bros.element				("HelpBack")
			.visible				(ProcessedLinks.length > 1)
			;

		// Store cookies
		//	PCS						(LinkObj);
		Bros.Cookie_Store			("Bros_AppLearningCenter_AutoRun",			Bros.element("AutoRun")			.value());
		Bros.Cookie_Store			("Bros_AppLearningCenter_AutoClearMsgs",	Bros.element("AutoClearMsgs")	.value());
		//
		Bros.Cookie_Store			("Bros_AppLearningCenter_LinkType",			LinkObj.LinkType);
		Bros.Cookie_Store			("Bros_AppLearningCenter_LinkName",			LinkObj.LinkName);
		Bros.Cookie_Store			("Bros_AppLearningCenter_LinkTextStr",		LinkObj.LinkTextStr);

		// Auto Run ?
		if (Bros.element("AutoRun").value())
			{
			//	//	Bros.___R		();
			//	//	Bros.___B		();
			//	Bros.___L			("ProcessLink before Run");
			Run						();
			//	Bros.___E			("ProcessLink after  Run");
			}
		}

	//---------------------------------------------------------------------------
	// HelpBack
	//---------------------------------------------------------------------------

	function HelpBack(LinkObj)
		{
		//	deb						("HelpBack", ProcessedLinks.length);

		// Enough ?
		if (ProcessedLinks.length < 2)
			return;

		// Set Links Aspect
		SetLinkAspect				(ProcessedLinks[ProcessedLinks.length - 1], false);		// Off

		// Pop the current LinkObj
		ProcessedLinks.pop			();

		// Pop the LinkObj to be re-shown
		var LinkObj					= ProcessedLinks.pop();

		// Re-process
		ProcessLink					(LinkObj);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Build Panel Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Build Panel Left
	//---------------------------------------------------------------------------

	function BuildPanelLeft()
		{
		//	deb						("BuildPanelLeft");
		var Result					= [];
		//
		//	Result.push				("Bros - Browser Operational System")
		//	Result.push				("<hr>")
		Result.push					(GetLink("Hello World", "Bros", "Hello_World")  + "<br>")

		// Push API Library
		if (Bros.IsInDebug && DebugShowBeforeAPI)
			{
			Result.push				("<table border=0 class='BrosAppManual_TB' >")
			PushAPILibrary			(Result);
			Result.push				("</table>")
			}

		// Elements
		Result.push					("<hr>")
		Result.push					("<b>Elements</b><p>")
		//	PCS						(Bros.RegisteredClasses)
		for (var RegClass_Name in Bros.RegisteredClasses)
			{
			//	deb					(RegClass_Name);
			Result.push				(GetLink(RegClass_Name, "Element", RegClass_Name)  + "<br>")
			}

//		Result.push					("<p><b>soon</b><p>")
//		Result.push					("updown<br>")
//		Result.push					("navigator<br>")
//		Result.push					("list<br>")
////	Result.push					("datepicker<br>")
//		Result.push					("keyboard<br>")

		// Methods
		Result.push					("<hr>")
		Result.push					("<table border=0 class='BrosAppManual_TB' >")
		//
		Result.push					("<tr>")
		Result.push					("<td class='BrosAppManual_TD' >")
		Result.push					("<b>Methods" + PanelLeftSpacement + "</b>")
		Result.push					("</td>")
		Result.push					("<td class='BrosAppManual_TD' >")
		Result.push					("<i>Type</i>")
		Result.push					("</td>")
		Result.push					("</tr>")
		//
		//	PCS						(Bros.RegisteredMethods)
		//	Result.push				(GetLink("element", "Method", "element")  + "<br>")
		//	for (var RegMethod_Name in Bros.RegisteredMethods)
		//		{
		//		//	deb				(RegMethod_Name);
		//		Result.push			(GetLink(RegMethod_Name, "Method", RegMethod_Name)  + "<br>")
		//		}
		var Methods					= [];
		for (var RegMethod_Name in Bros.RegisteredMethods)
			{
			//	deb					(RegMethod_Name);
			var RMethod				= Bros.RegisteredMethods[RegMethod_Name];
			// For Testing (to view PropName != Name)
			//	if (RMethod.ApplyGetSet)
			//		{
			//		if (RMethod.Name.toLowerCase() != RMethod.PropName.toLowerCase())
			//			PCS			(RMethod);
			//		}
			Methods.push			(RMethod);
			}
		Bros.Arr_Sort				(Methods, function (a, b)
			{
			if (a.Type < b.Type)
				return  1;
			if (a.Type > b.Type)
				return -1;
			if (a.Name > b.Name)
				return  1;
			return -1;
			});
		var LastType				= "";
		for (var i = 0; i < Methods.length; i++)
			{
			var RMethod				= Methods[i];
			var Complement			= "";
			if (LastType != RMethod.Type)
				Complement			= "&nbsp;<br>";
			LastType				= RMethod.Type;
			Result.push				("<tr>")
			Result.push				("<td class='BrosAppManual_TD' >")
			Result.push				(Complement + GetLink(RMethod.Name, "Method", RMethod.Name)  + "<br>")
			Result.push				("</td>")
			Result.push				("<td class='BrosAppManual_TD' >")
			Result.push				(Complement + "<i>" + RMethod.Type + "</i>")
			Result.push				("</td>")
			Result.push				("</tr>")
			}

//		Result.push					("<tr>")
//		Result.push					("<td class='BrosAppManual_TD' colspan=2>")
//		Result.push					("<p>&nbsp;<br><b>soon</b><p>")
//		Result.push					("borderstyleround<br>")
//		Result.push					("</td>")
//		Result.push					("</tr>")

		// Push API Library
		if (! (Bros.IsInDebug && DebugShowBeforeAPI))
			PushAPILibrary			(Result);

		// Table Ends
		Result.push					("</table>")

		// Update
		UpdatePanelHTML				(Result, "PanelLeft");
		}

	//---------------------------------------------------------------------------
	// Push API Library
	//---------------------------------------------------------------------------

	function PushAPILibrary(Result)
		{
		//	deb						("PushAPILibrary");
		//	PCS						(Bros.lib, ! false);

		// Title
		Result.push					("<tr><td class='BrosAppManual_TD'>")
		Result.push					("<p>&nbsp;<hr><b>API library" + PanelLeftSpacement + "</b><p>")
		Result.push					("</td><td>&nbsp;</td></tr>")

		// Scan Objects
		for (var Prop_Name in Bros.lib)
			{
			//	deb					("Prop_Name", Prop_Name);
			var Prop				= Bros.lib[Prop_Name];				// Ex.: fs
			// Have Doc ?
			if (! Prop.doc)
				continue;

			var Method_Name			= "<b>" + Prop.doc.title + "</b>";
			var Link_Name			= Prop.doc.title.replace(/ /gi, "_");
			var Link_Type			= "Bros";
			HelpPages.push			([Link_Type, Link_Name, "", Prop.doc.desc, ""]);

			// Title
			Result.push				("<tr><td class='BrosAppManual_TD' colspan=2>")
			//	Result.push			("&nbsp;<br><b>" + Prop.doc.title + "</b><p>")
			Result.push				("&nbsp;<br><b>" + GetLink(Method_Name, Link_Type, Link_Name) + "</b><p>")
			Result.push				("</td></tr>")

			// Scans SubProps
			for (var SubProp_Name in Prop)
				{
				//	deb				("SubProp_Name", SubProp_Name, typeof(Prop[SubProp_Name]));		// Ex.: read
				if (SubProp_Name == "doc")
					continue;

				// Only accepts objects (discarding Bros.lib.appc.GambPanelSpace for example)
				if (! Bros.VarIsFunction(Prop[SubProp_Name]))
					continue;

				var Method_Name		= "Bros.lib." + Prop_Name + "." + SubProp_Name;
				var Link_Name		= "Bros_lib_" + Prop_Name + "_" + SubProp_Name;
				var Link_Type		= "Bros";
				Result.push			("<tr>")
				Result.push			("<td class='BrosAppManual_TD' >")
				Result.push			(GetLink(Method_Name, Link_Type, Link_Name)  + "<br>")
				Result.push			("</td>")
				Result.push			("<td class='BrosAppManual_TD' >")
				Result.push			("<i>method</i>")
				Result.push			("</td>")
				Result.push			("</tr>")

				// Have Doc ?
				var Doc				= Prop.doc[SubProp_Name];
				//	deb				("Doc = " + Doc);
				if (! Doc)
					continue;

				// To temporaryly replace, for example, Bros.lib.fs.read with Bros_lib_fs_read
				var Doc2			= Doc[2];
				if (Bros.VarIsArray(Doc2))
					{
					if (Bros.VarIsString(Doc2[1]))
						{
						var RE		= /\./gi;
						//	deb		("Doc2[1] = " + Doc2[1]);
						Doc2[1]		= Doc2[1].replace(RE, "_");
						//	deb		("Doc2[1] = " + Doc2[1]);
						}
					}

				// Push page
				HelpPages.push		(["Bros", Link_Name, Doc[0], Doc[1], Doc2]);
				}
			}
		}

	//---------------------------------------------------------------------------
	// Build Other Panels
	//---------------------------------------------------------------------------

	function BuildOtherPanels(LinkObj)
		{
		//	deb						("BuildOtherPanels");
		//	PCS						(LinkObj);

		// Get HelpPage of LinkObj
		var HelpPage				= GetHelpPage(LinkObj);
		//	deb						(HelpPage);

		// Builds Panel Top
		var Result					= [];
		if (LinkObj.LinkType != "Bros")
			Result.push				(""		+ LinkObj.LinkType		+ ": ");
		//	Result.push				("<b>"	+ LinkObj.LinkName		+ "</b><br>");
		Result.push					("<b>"	+ LinkObj.LinkTextStr	+ "</b><br>");
		switch (LinkObj.LinkType)
			{
		//	case "Bros":
		//		Result.push			("&nbsp;");
		//		break;
			case "Element":
				Result.push			("Inheritance: ");
				Result.push			(GetInheritance(LinkObj.LinkName));
				break;
			case "Bros":
			case "Method":
				if (HelpPage == null)
					Result.push		("&nbsp;");
				else
					{
					Result.push		(HelpPage[2] == "" ? "&nbsp;" : "Syntax: ");
					Result.push		(HelpPage[2]);
					}
				break;
			default:
				Bros.FatalErrorMNO	("Bros.App_Manual.BuildOtherPanels (Point A)", "Unknown LinkObj.LinkType", "LinkObj.LinkType = " + LinkObj.LinkType);
			}
		Result.push					("<hr>");
		if (HelpPage != null)
			Result.push				(HelpPage[3]);
		UpdatePanelHTML				(Result, "PanelTop");

		// Builds Panel Right
		var Result					= [];
		switch (LinkObj.LinkType)
			{
			case "Bros":
				break;
			case "Element":
				Result.push			("Valid Methods for:<br>");
				//	Result.push		("<b>"	+ LinkObj.LinkName		+ "</b><hr>");
				Result.push			("<b>"	+ LinkObj.LinkTextStr	+ "</b><br>");
				Result.push			(GetValidMethods(LinkObj.LinkName));
				break;
			case "Method":
				Result.push			("Method : ");
				Result.push			("<b>"	+ LinkObj.LinkName + "</b><br>applies to:<hr>");
				Result.push			(GetAppliedElements(LinkObj.LinkName));
				break;
			default:
				Bros.FatalErrorMNO	("Bros.App_Manual.BuildOtherPanels (Point B)", "Unknown LinkObj.LinkType", "LinkObj.LinkType = " + LinkObj.LinkType);
			}
		UpdatePanelHTML				(Result, "PanelRight");

		// Builds EditArea
		var Result					= [];
		GSTR_LoopCount				= 0;
		Result.push					(GetScriptToRun(HelpPage));
		Bros.element				("EditArea")
			.value					(Result.join(""))
			;

		// Clear ExecutionPanel
		//Bros.element				("ExecutionPanel")
		//	.html					("")
		//	;
		}

	//---------------------------------------------------------------------------
	// Get HelpPage of LinkObj
	//---------------------------------------------------------------------------

	function GetHelpPage(LinkObj)
		{
		//	deb						("GetHelpPage", HelpPages.length);
		//	PCS						(LinkObj);
		for (var i in HelpPages)
			{
			HelpPage				= HelpPages[i];
			if (HelpPage[0] != LinkObj.LinkType)
				continue;
			//	deb					((HelpPage[1] == LinkObj.LinkName), (HelpPage[1] == LinkObj.LinkTextStr), HelpPage[1], LinkObj.LinkName, LinkObj.LinkTextStr);
		//	if (HelpPage[1] != LinkObj.LinkTextStr)
			if (HelpPage[1] != LinkObj.LinkName)
				continue;
			// Found !
			return HelpPage;
			}
		// Not Found !
		return null;
		}

	//---------------------------------------------------------------------------
	// Get Inheritance of an Element Class
	//---------------------------------------------------------------------------

	function GetInheritance(ElementClass)
		{
		//	deb						("GetInheritance", ElementClass);
		var Handler					= Bros.RegisteredClasses[ElementClass];
		//	PCS						(Handler);
		//	return Handler.Inheritance.length;

		// No Inheritance ?
		if (Handler.Inheritance.length == 0)
			return "(none)";

		// Build the result
		var Result					= "";
		for (var i in Handler.Inheritance)
			{
			var ElemClass			= Handler.Inheritance[i];
			if (Result != "")
				Result			   += " -> ";
			Result				   += GetLink(ElemClass, "Element", ElemClass);
			}
		Result					   += " -> ";
		Result					   += GetLink(ElementClass, "Element", ElementClass);
		//	Result				   += ElementClass;
		return Result;
		}

	//---------------------------------------------------------------------------
	// Get Valid Methods of an Element Class
	//---------------------------------------------------------------------------

	function GetValidMethods(ElementClass)
		{
		//	deb						("GetValidMethods", ElementClass);

		// Get's
		var Methods					= Bros.GetValidMethods(ElementClass);
		//	deb						("Methods.length = " + Methods.length);

		// Loop
		var Result					= [];
		var LastType				= "";
		for (var i = 0; i < Methods.length; i++)
			{
			var Method				= Methods[i];
			if (Result.length > 0)
				Result.push			("<br>");
			if (Method.Type == "ClassDivisor")
				{
				var FromTo			= "In ";
				if (Method.Name != ElementClass)
					{
					FromTo			= "Derived from ";
					LastType		= "";
					}
				if (Result.length > 0)
					Result.push		("<p>");
				Result.push			(FromTo + "<b>" + Method.Name + "</b>:");
				}
			else
				{
				if (LastType != Method.Type)
					{
					//	Result.push	("<i>Type: " + Method.Type + "</i><br>");
					Result.push		("<i>" + Method.Type + "</i><br>");
					LastType		= Method.Type;
					}
				Result.push			(GetLink(Method.Name, "Method", Method.Name));
				}
			}
		return Result.join("");
		}

	//---------------------------------------------------------------------------
	// Get Applied elements of a Method
	//---------------------------------------------------------------------------

	function GetAppliedElements(MethodName)
		{
		//	deb						("GetAppliedElements", MethodName);
		var Result					= "";
		for (var RegClass_Name in Bros.RegisteredClasses)
			{
			var Handler				= Bros.RegisteredClasses[RegClass_Name];
			//	deb					(RegClass_Name, Handler.ClassName, Handler.ValidMethods.length);
			if (! Bros.Arr_Have(Handler.ValidMethods, MethodName))
				continue;
			if (Result != "")
				Result			   += "<br>";
			Result				   += GetLink(RegClass_Name, "Element", RegClass_Name);
			}
		return Result;
		}

	//---------------------------------------------------------------------------
	// Get Sscript to run of LinkObj
	//---------------------------------------------------------------------------

	function GetScriptToRun(HelpPage)
		{
		//	deb						("GetScriptToRun", (HelpPage == null));

		// Avoid infinite recursion in GetScriptToRun
		if (GSTR_LoopCount >= GSTR_LoopCount_Max)
			{
			Bros.FatalErrorMNO		("Bros.App_Manual.GetScriptToRun", "Too much recursion", "GSTR_LoopCount_Max = " + GSTR_LoopCount_Max);
			return "";
			}
		GSTR_LoopCount++;

		// Have Help ?
		if (HelpPage == null)
			return "";

		// Is String ?
		if (Bros.VarIsString(HelpPage[4]))
			return HelpPage[4];

		// Is Array ?
		if (Bros.VarIsArray(HelpPage[4]))
			{
			HelpPage				= GetHelpPage({"LinkType" : HelpPage[4][0], "LinkName" : HelpPage[4][1], "LinkTextStr" : HelpPage[4][1]	});
			// Reenter
			return GetScriptToRun	(HelpPage);
			}

		Bros.FatalErrorMNO			("Bros.App_Manual.GetScriptToRun", "Unknown situation", "typeof(HelpPage[4]) = " + typeof(HelpPage[4]));
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Configuration Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Configure Help Pages
	//---------------------------------------------------------------------------

	function ConfigureHelpPages()
		{
		//	deb						("ConfigureHelpPages");

		//---------------------------------------------------------------------------
		// Bros
		//---------------------------------------------------------------------------

		var Help_Uncomment			= "// Comment or uncomment some below lines and Run again";
		//	Help_Uncomment		   += "\n// See deb results on System Monitor";
		var Help_StartExample		= Help_Uncomment + "\nBros";

		var Help_CreatePanel		=    '\n.createelement("panel")'
								//	   + '\n	.left(10, 10, 400, 250)'
								//	   + '\n	.left(10, 10, 350, 250)'
									   + '\n	.left(10, 10, ' + Panel_Width + ', ' + Panel_Height + ')'
									   ;

		var Help_StartExample_Panel	= Help_StartExample + Help_CreatePanel;

		var Help_Hello_World		=	    "// One application in 10 lines within a single javascript statement !!!"
									   + '\nBros.createelement("window")	// Creates a window'
									   + '\n	.left(10, 10, 350, 250)		// Left, Top, Width, Height'
									   + '\n	.caption("Hello World")		// Defines window caption'
									   + '\n	.createelement("panel")		// Creates a panel inside of window'
									   + '\n		.height(41).align("top").borderstyle(Bros.bsNone)'
									   + '\n		.createelement("button").caption("Click Me").onclick(function (Elem, e){'
									   + '\n			Bros.element("MyEditArea").value(Bros.element("MyEditArea").value() + "Hello World !");'	// \\n
									   + '\n			})'
									   + '\n		.parent()'
									   + '\n	.createelement("editarea").name("MyEditArea").align("client");'
									   ;

		var Help_Element			=	    Help_Uncomment
									   + '\nvar MyElementObject;'
									   + '\nBros'
									   + '\n.createelement	("element")'
									   + '\n	.left		(20)'
									   + '\n	.top		(30)					// Does NOT accept array'
									   + '\n	.width		(100)'
									   + '\n	.height		(150)					// Does NOT accept array'
									   + '\n//	.left		(30, 40)				// Accepts: Left, Top'
									   + '\n//	.left		(50, 60, 110, 60)		// Accepts: Left, Top, Width, Height'
									   + '\n//	.left		([70])					// Accepts array: [Left]'
									   + '\n//	.left		([80, 90])				// Accepts array: [Left, Top]'
									   + '\n//	.left		([100, 110, 120, 80])	// Accepts array: [Left, Top, Width, Height]'
									   + '\n//	.width		(130, 90)				// Accepts: Width, Height'
									   + '\n//	.width		([150])					// Accepts array: [Width]'
									   + '\n//	.width		([160, 100])			// Accepts array: [Width, Height]'
									   + '\n	.html		("Hello World<p>Hello World<p>Hello World")'
									   + '\n	.movable	(true)'
									   + '\n	.resizable	(true)'
									   + '\n	.scrollbars	("both")'
									   + '\n	.wraptext	(false)'
									   + '\n	.color		("FFFF00")'
									   + '\n//	.borderstyle(Bros.bsEdit)'
									   + '\n	.onready	(function (Elem)'
									   + '\n		{'
									   + '\n		deb		("onready");'
									   + '\n		MyElementObject = Elem;'
									   + '\n		})'
									   + '\n	.onresize	(function (Elem)'
									   + '\n		{'
									   + '\n		deb		("onresize", Bros.havescrollbars("horizontal"), Bros.havescrollbars("vertical"));'
									   + '\n		})'
									   + '\n;'
									   ;

		//###########################################################################
		//###########################################################################
		//##
		//## Bros
		//##
		//###########################################################################
		//###########################################################################

		HelpPages.push				(["Bros",	"Hello_World", ""
									,	'Let\'s start to see <b>Bros</b> in action.'
									   +'<p>Clik on [Run again] below.'
									   +'<p><b>Bros</b> offers you a complete framework to easily build your application windows, '
									   +'leaving you just to develop the logic of your programs.'
									,	Help_Hello_World
									]);

		//###########################################################################
		//###########################################################################
		//##
		//## Elements
		//##
		//###########################################################################
		//###########################################################################

		HelpPages.push				(["Element",	"element", ""
									,	'<b>element</b> is the base class of all elements.'
									   +'<p>You may not need to use this class.'
									,	Help_Element
									]);

		HelpPages.push				(["Element",	"label", ""
									,	'<b>label</b> is useful to identify your elements.'
									,	   Help_StartExample
									   + '\n.createelement		("panel")'
									   + '\n	.html			("")'
									   + '\n	.left			(10, 10, 200, 100)'
									   + '\n	.createelement	("label")'
									   + '\n//		.borderstyle(Bros.bsEdit)'
									   + '\n//		.width		(30)			// Will reset autosize (default)'
									   + '\n//		.autosize	(false)'
									   + '\n		.color		("FFFF00")'
									   + '\n		.caption	("This operational system is")'
									   + '\n//		.autosize	(true)			// Will adjust caption'
									   + '\n//		.resizable	(true)'
									   + '\n	.createelement	("edit")'
									   + '\n		.left		(10, 30)'
									   + '\n		.value		("Bros !")'
									   + '\n	.parent			()'
									   + '\n;'
									]);

		//	var Bros_Sysc_ImgSubPath_OS	= Bros.Sysc.ImgSubPath_OS;
		// Bellow instead above avoiding changing Sysc
		var Bros_Sysc_ImgSubPath_OS	= "Base/";
		var ImgSubPath_OS			= Bros.URL_Path_Img_Bros_OS + "Base/";
		var ImgSubPath_OS			= Bros.URL_Path_Img_Bros_OS + "Base/";

		HelpPages.push				(["Element",	"image", ""
									,	'Use <b>image</b> to show pictures.'
									,	   Help_StartExample
									   + '\n.createelement			("panel")'
									   + '\n	.left				(10, 10, 200, 150)'
									   + '\n	.createelement		("image")'
									   + '\n		.name			("MyImage")'
									   + '\n//		.imagewidth		(48)'
									   + '\n//		.imagewidth		(48, 16)'
									   + '\n//		.imagewidth		([48])'
									   + '\n//		.imagewidth		([48, 16])'
									   + '\n//		.imageheight	(16)'
									   + '\n//		.borderstyle	(Bros.bsNone)'
									   + '\n		.onload			(function (Elem, e, Success)'
									   + '\n			{'
									   + '\n			deb			("onload, Success = " + Success);'
									   + '\n			deb			("imagewidth      = " + Bros.imagewidth ());'
									   + '\n			deb			("imageheight     = " + Bros.imageheight());'
									   + '\n			deb			("getimagewidth   = " + Bros.getimagewidth ());'
									   + '\n			deb			("getimageheight  = " + Bros.getimageheight());'
									   + '\n			})'
								//	   + '\n		.imagesrc		("file:B:/BRW_1/ImgEx_4Pixels.bmp")'
								//	   + '\n		.imagesrc		("file:B:/BRW_1/ImgEx_4Pixels_bmp_Content.jpg")'
								//	   + '\n		.imagesrc		("file:Dropbox:/BRW_1/ImgEx_4Pixels.bmp")'
								//	   + '\n		.imagesrc		("file:Dropbox:/BRW_1/ImgEx_4Pixels_bmp_Content.jpg")'
									   + '\n		.imagesrc		("' + Bros.URL_Path_Img_Bros_OS + Bros_Sysc_ImgSubPath_OS + 'Img_Men_Start_2_Personal.gif") // Direct URL access (faster)'
									   + '\n	//	.imagesrc		("BrosPublic:/img/Bros/Examples/ImgEx_Bros.gif")			// Indirect URL access because BrosPublic: will be changed to a correct URL (also faster)'
									   + '\n	//	.imagesrc		("file:ReadOnly_Bros:/img/Bros/Examples/ImgEx_Bros.gif")	// File access (a little bit slower because the file will be read and then convert to Mime64 url)'
									   + '\n	//	//	.imagesrc	("file:B:/somepath/someimage")								// File access (same as above)'
									   + '\n	//	//	.imagesrc	("file:Dropbox:/somepath/someimage")						// Dropbox access (slower due to Dropbox handshaking plus read file as above)'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("Change Image")'
									   + '\n		.autosize		(true)'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyImage").imagesrc("' + Bros.URL_Path_Img_Bros_OS + Bros_Sysc_ImgSubPath_OS + 'Img_Men_Start_1_WebSites.gif")'
									   + '\n			})'
									   + '\n	.parent				()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"imagelabel", ""
									,	'<b>imagelabel</b> is an image together with a label.'
									   +'<p>It\'s used in buttons for example.'
									,	   Help_StartExample
									   + '\n.createelement			("imagelabel")'
									   + '\n	.width				(300, 200)'
// XPTBUGIMAGELABELAUTOSIZE - BUG HERE WHEN imagelabel starts with small width
//+ '\n	.width				(30)'
									   + '\n	.caption			("My imagelabel caption")'
									   + '\n	.imagesrc			("' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif")'
									   + '\n	.imagewidth			(32, 32)			// Accepts: Width, Height'
									   + '\n//	.imagewidth			(48)				// Auto adjust image height'
									   + '\n//	.imagewidth			(64, 32)			// Accepts: Width, Height'
									   + '\n//	.imagewidth			([80])				// Accepts array: [Width]'
									   + '\n//	.imagewidth			([96, 48])			// Accepts array: [Width, Height]'
									   + '\n//	.imageheight		(96)				// Does NOT accept array'
									   + '\n//	.imagealignment		("left")'
// XPTBUGIMAGELABELAUTOSIZE - BUG HERE WHEN imagelabel starts with small width
									   + '\n	.imagealignment		("top")'
									   + '\n//	.imagealignment		("right")'
									   + '\n//	.imagealignment		("bottom")'
									   + '\n	.outerspacement		(5)'
									   + '\n	.innerspacement		(10)'
									   + '\n	.halign				("center")'
									   + '\n	.valign				("top")'
									   + '\n//	.imagealignment		("right")'
									   + '\n//	.halign				("right")'
									   + '\n//	.valign				("bottom")'
									   + '\n	.autosize			(true)				// Adjusts ONLY width'
									   + '\n//	.resizable			(true)'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"button", ""
									,	'<b>button</b> allow you to fire events.'
									,	   Help_Uncomment
									   + '\nvar CountB1 = 0;'
									   + '\nBros'
									   + '\n.createelement				("panel")'
									   + '\n	.width					(350, 250)'
									   + '\n	.html					("")'
									   + '\n// Simple button'
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("(Click me)")'
									   + '\n		.width				(150)'
									   + '\n	//	.onclickon			("up")		// Fires onclick on mouse up	(default)'
									   + '\n	//	.onclickon			("down")	// Fires onclick on mouse down	(instead of on mouse up)'
									   + '\n	//	.onclickon			("both")	// Fires onclick on mouse up AND on mouse down'
									   + '\n	//	.onclickon			("none")	// Don\'t fires onclick (useless)'
									   + '\n	//	.ispushpull			(true)		// See behavior change here'
									   + '\n		.onclick(function	(Elem, e)'
									   + '\n			{'
									   + '\n			CountB1++;'
									   + '\n			Bros.caption	("Clicked on me " + CountB1 + " times !");'
									   + '\n			})'
									   + '\n	// More complex button'
									   + '\n	.createelement			("button")'
									   + '\n		.width				(150, 50)'
									   + '\n		.caption			("My button (Click me)")'
									   + '\n		.name				("MyComplexBtn")'
									   + '\n	//	.resizable			(true)'
									   + '\n	//	.borderstyle		(Bros.bsWhite2)'
									   + '\n	//	.color				("FF0000")'
									   + '\n		.imagesrc			("' + Bros.URL_Path_Img_Ex_Btn + 'Button_A_1_Up.gif")'
									   + '\n		.halign				("left")'
									   + '\n		//'
									   + '\n		.ispushpull			(true)	// Try comment only here'
									   + '\n		//'
									   + '\n		.goingdown			()'
									   + '\n			.name			("MyComplexBtn")'
									   + '\n			.imagesrc		("' + Bros.URL_Path_Img_Ex_Btn + 'Button_A_2_GoingDown.gif")'
									   + '\n			.caption		("I am going down")'
									   + '\n	//		.borderstyle	(Bros.bsBlack1)'
									   + '\n	//		.color			("FFFF00")'
									   + '\n	//		.pixelsoffset	([0, 0])'
									   + '\n			.halign			("left")'
									   + '\n	//		.font			({underline:true})'
									   + '\n	//		.imagealignment	("top")'
									   + '\n			.parent			()'
									   + '\n		.down				()'
									   + '\n			.imagesrc		("' + Bros.URL_Path_Img_Ex_Btn + 'Button_A_3_Down.gif")'
									   + '\n			.caption		("I am down")'
									   + '\n	//		.borderstyle	(Bros.bsBlack2)'
									   + '\n	//		.color			("0000FF")'
									   + '\n	//		.pixelsoffset	([0, 0])'
									   + '\n			.halign			("left")'
									   + '\n	//		.font			({bold:true})'
									   + '\n	//		.imagealignment	("right")'
									   + '\n	//		.halign			("right")'
									   + '\n			.parent			()'
									   + '\n		.goingup			()'
									   + '\n			.imagesrc		("' + Bros.URL_Path_Img_Ex_Btn + 'Button_A_4_GoingUp.gif")'
									   + '\n			.caption		("I am going up")'
									   + '\n	//		.borderstyle	(Bros.bsWhite1)'
									   + '\n	//		.color			("00FFFF")'
									   + '\n			.halign			("left")'
									   + '\n			.parent			()'
									   + '\n		.onclick(function	(Elem, e)'
									   + '\n			{'
									   + '\n			deb("Clicked ! value = " +  Bros.value());'
									   + '\n			// Use below if you do something else that select other elements in this function'
									   + '\n	//		deb("Clicked ! value = " +  Bros.element(Elem).value());'
									   + '\n			})'
									   + '\n	// Other button'
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("&nbsp;&nbsp;&nbsp;&nbsp;(I am off)")'
									   + '\n		.name				("AnotherBtn")'
									   + '\n		.width				(150, 50)'
									   + '\n		.halign				("left")'
									   + '\n		.borderstyle		(Bros.bsNone)'
									   + '\n		.imagesrc			("' + Bros.URL_Path_Img_Ex_Btn + 'Button_B_1_Up.png")'
									   + '\n		.imagewidth			(77, 26)'			// 154 x 54
									   + '\n		.ispushpull			(true)	// Try comment only here'
									   + '\n		.onclickon			("down")'
									   + '\n		//'
									   + '\n		.down				()'
									   + '\n			.imagesrc		("' + Bros.URL_Path_Img_Ex_Btn + 'Button_B_2_Down.png")'
									   + '\n			.caption		("&nbsp;&nbsp;&nbsp;&nbsp;(I am on)")'
									   + '\n			.borderstyle	(Bros.bsNone)'
									   + '\n			.pixelsoffset	(Bros.ofZero)'
									   + '\n		.onclick(function	(Elem, e)'
									   + '\n			{'
									   + '\n			deb("Clicked ! value = " +  Bros.value());'
									   + '\n			})'
// Not for a while
//									   + '\n	// One more button'
//									   + '\n	.createelement			("button")'
//									   + '\n		.caption			("&nbsp;&nbsp;&nbsp;&nbsp;(I am off)")'
//									   + '\n		.width				(220, 120)'
//									   + '\n		.halign				("left")'
//									   + '\n		.borderstyle		(Bros.bsNone)'
//									   + '\n		.imagesrc			("' + Bros.URL_Path_Img_Ex_Btn + 'Button_B_1_Up.png")'
//									   + '\n		.imagewidth			(77, 26)'			// 154 x 54
//									   + '\n		.ispushpull			(true)	// Try comment only here'
//									   + '\n		.onclickon			("down")'
//									   + '\n		//'
//									   + '\n		.onover				()'
//									   + '\n			.width			(220, 120)'
//									   + '\n			.imagewidth		(154, 54)'			// 154 x 54
//									   + '\n		.down				()'
//									   + '\n			.imagesrc		("' + Bros.URL_Path_Img_Ex_Btn + 'Button_B_2_Down.png")'
//									   + '\n			.caption		("&nbsp;&nbsp;&nbsp;&nbsp;(I am on)")'
//									   + '\n			.borderstyle	(Bros.bsNone)'
//									   + '\n			.pixelsoffset	(Bros.ofZero)'
//									   + '\n		.onclick(function	(Elem, e)'
//									   + '\n			{'
//									   + '\n			deb("Clicked ! value = " +  Bros.value());'
//									   + '\n			})'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"checkbox", ""
									,	'<b>checkbox</b> is an element to set (.value() = 1) or clear (.value() = 0).'
									,	   Help_Uncomment
									   + '\nvar Width				= 250;'
									   + '\nBros'
									   + '\n.createelement			("panel")'
									   + '\n	.html				("")'
									   + '\n	.left				(10, 10, Width + 20, 150)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB1")'
									   + '\n		.caption		("My Checkbox 1")'
									   + '\n		.imageborder	(Bros.ib3D)'
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB2")'
									   + '\n		.caption		("My Checkbox 2")'
									   + '\n		.imageborder	(Bros.ibSingle)'
								//	   + '\n		.imageborder	(Bros.ib3D)'			// Testing go back
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB3")'
									   + '\n		.caption		("My Checkbox 3")'
									   + '\n		.imageborder	(Bros.ibNone)'
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB4")'
									   + '\n		.caption		("My Checkbox 4")'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB5")'
									   + '\n		.caption		("My Checkbox 5")'
									   + '\n		.imageborder	(Bros.ibSingle)'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("checkbox")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyCB6")'
									   + '\n		.caption		("My Checkbox 6")'
									   + '\n		.imageborder	(Bros.ibNone)'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyCB_OnClick)'
									   + '\n	//'
									   + '\n	.parent				()'
									   + '\n;'
									   + '\nfunction MyCB_OnClick(Elem, e)'
									   + '\n	{'
									   + '\n	deb(Bros.element(Elem).name() + " is " + (Bros.value() ? "CHECKED" : "UNCHECKED"));'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"radiobutton", ""
									,	'<b>radiobutton</b> is an element to set (.value() = 1) or clear (.value() = 0) but only one by grouped.'
									   +'<p>radiobuttons grouped are the radiobuttons in the same parent container (panel or window).'
									,	   Help_Uncomment
									   + '\nvar Width				= 250;'
									   + '\nBros'
									   + '\n.createelement			("panel")'
									   + '\n	.html				("")'
									   + '\n	.left				(10, 10, Width + 20, 80)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB1")'
									   + '\n		.caption		("My RadioButton 1")'
									   + '\n		.imageborder	(Bros.ib3D)'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB2")'
									   + '\n		.caption		("My RadioButton 2")'
									   + '\n		.imageborder	(Bros.ibSingle)'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB3")'
									   + '\n		.caption		("My RadioButton 3")'
									   + '\n		.imageborder	(Bros.ibNone)'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.parent				()'
									   + '\n.createelement			("panel")'
									   + '\n	.html				("")'
									   + '\n	.width				(Width + 20, 80)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB4")'
									   + '\n		.caption		("My RadioButton 4")'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB5")'
									   + '\n		.caption		("My RadioButton 5")'
									   + '\n		.imageborder	(Bros.ibSingle)'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.createelement		("radiobutton")'
									   + '\n		.width			(Width)'
									   + '\n		.name			("MyRB6")'
									   + '\n		.caption		("My RadioButton 6")'
									   + '\n		.imageborder	(Bros.ibNone)'
									   + '\n		.halign			("right")'
									   + '\n		.imagealignment	("right")'
									   + '\n		.onclick		(MyRB_OnClick)'
									   + '\n	//'
									   + '\n	.parent				()'
									   + '\n;'
									   + '\nfunction MyRB_OnClick(Elem, e)'
									   + '\n	{'
									   + '\n	deb(Bros.element(Elem).name() + " is " + (Bros.value() ? "CHECKED" : "UNCHECKED"));'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"application", ""
									,	'<b>application</b> is implemented but is not used here (only on My Computer, Add Program).'
									,	   Help_StartExample
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"panel", ""
									,	'<b>panel</b> is the container of elements such as button, edit, etc.'
									   +'<p>You can have panels inside panels.'
									   +'<p>Due to the fact of panel is a element container you need call parent() method when you finish creating sub elements.'
									,	   Help_StartExample
									   + '\n.createelement("panel")'
									   + '\n	.html("")'
									   + '\n	.left(10, 10, 350, 200)'
									   + '\n	.createelement("panel")'
									   + '\n		.html("")'
									   + '\n//		.borderstyle([])'
									   + '\n		.align("top")'
									   + '\n		.createelement("button")'
									   + '\n			.width(200).movable(true)'
									   + '\n			.caption("Button inside 2nd Panel (move-me)")'
									   + '\n		.parent()	// Rerurns to 1st Panel'
									   + '\n	.createelement("button")'
									   + '\n		.width(200).movable(true)'
									   + '\n		.caption("Button inside 1st Panel (move-me)")'
									   + '\n	.parent()	// End of 1st Panel'
									   + '\n.createelement("button")'
									   + '\n	.width(200).movable(true)'
									   + '\n	.caption("Button otside Panels (move-me)")'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"group", ""
									,	'<b>group</b> is a panel with a caption in the top.'
									   +'<p>Due to the fact of group is a element container you need call parent() method when you finish creating sub elements.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("group")'
									   + '\n		.caption			("My firts Group")'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.movable			(true)'
									   + '\n//		.resizable			(true)'
									   + '\n		.createelement		("radiobutton")'
									   + '\n		.createelement		("radiobutton")'
									   + '\n		.createelement		("checkbox")'
									   + '\n		.createelement		("checkbox")'
									   + '\n		.parent				()	// Rerurns to 1st panel'
									   + '\n	.parent					()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"selector", ""
									,	'<b>selector</b> is an element that allow you to select one of determined options.'
									,	   Help_StartExample_Panel
									   + '\n	.color					("A0A0A0")		// To better see where selector is'
									   + '\n	.createelement			("selector")'
									   + '\n		.name				("MySelector")'
									   + '\n		.left				(10, 50, 180, 180)'
									   + '\n		.resizable			(true)'
									   + '\n		.movable			(true)'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.color				("FFFF00")		// To see where selector is'
									   + '\n//		.selectormode		("tab")			// Default'
									   + '\n//		.selectormode		("button")'
									   + '\n//		.autosize			(false)'
									   + '\n//'
									   + '\n//		.alignment			("left")'
									   + '\n//		.halign				("left")'
									   + '\n//'
									   + '\n//		.alignment			("top")'
									   + '\n//		.alignment			("right")'
									   + '\n//		.alignment			("bottom")'
									   + '\n//		.item				()'
									   + '\n//			.imagewidth		(32, 32)'
									   + '\n//			.imagealignment	("bottom")'
									   + '\n//			.valign			("top")'
									   + '\n//			.color			("FFFFFF")'
									   + '\n//			.borderstyle	(Bros.bsBlack1)'
									   + '\n//			.borderstyle	(Bros.bsBlack2)'
									   + '\n//			.down			()'
									   + '\n//				.color		(Bros.clPanel)'
									   + '\n//				.borderstyle(Bros.bsButtonUp)'
									   + '\n//				.parent		()'
									   + '\n//			.parent			()'
									   + '\n		.additem			("Option 0")'
									   + '\n		.additem			("Option 1", "' + Bros.FS.A_BrosPublic_Img_I32 + 'Icon_Bros.gif")'
									   + '\n		.additem			("Option 2")'
								//	   + '\n		.deleteitem			(1)'
								//	   + '\n		.deleteitem			(0)'
								//	   + '\n		.deleteitem			(0)'
									   + '\n		.onchange			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("You select the Option " + Bros.element(Elem).selected());'
									   + '\n			})'
									   + '\n	.createelement			("select")'
									   + '\n		.left				(10, 10)'
									   + '\n		.text				("tab")'
									   + '\n		.additem			("tab")'
									   + '\n		.additem			("button")'
									   + '\n		.onchange			(function (Elem)'
									   + '\n			{'
									   + '\n			var Value		= Bros.value();'
									   + '\n			Bros.element	("MySelector").selectormode(Value);'
									   + '\n			SetAutoSize		();'
// IMPROVE HERE
									   + '\n			Bros.element	("MySelector").selectormode(Value);'
									   + '\n			})'
									   + '\n	.createelement			("select")'
									   + '\n		.left				(150, 10)'
									   + '\n		.text				("top")'
									   + '\n		.additem			("left")'
									   + '\n		.additem			("top")'
									   + '\n		.additem			("right")'
									   + '\n		.additem			("bottom")'
									   + '\n		.onchange			(function (Elem)'
									   + '\n			{'
									   + '\n			var Value		= Bros.value();'
									   + '\n			Bros.element	("MySelector").alignment(Value);'
									   + '\n			SetAutoSize		();'
// IMPROVE HERE
									   + '\n			Bros.element	("MySelector").alignment(Value);'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.left				(275, 10)'
									   + '\n		.caption			("Test")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			//	Bros.element("MySelector").deleteitem(1);'
									   + '\n			Bros.element	("MySelector").selected(1);'
									   + '\n			deb				("Selected Option is " + Bros.element("MySelector").selected());'
									   + '\n			})'
									   + '\n	.parent					()'
									   + '\n;'
									   + '\nfunction SetAutoSize()'
									   + '\n	{'
									   + '\n	var SM					= Bros.element("MySelector").selectormode();'
									   + '\n	var AL					= Bros.element("MySelector").alignment	 ();'
									   + '\n	var AutoSize			= (SM == "tab") && ((AL == "top") || (AL == "bottom"));'
									   + '\n	//	deb					(SM, AL, AutoSize);'
									   + '\n	Bros.autosize			(AutoSize);'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"checkboxes", ""
									,	'<b>checkboxes</b> is an number of checkboxes grouped in a group.'
									,	 Help_Uncomment
									   + '\nvar Count					= 4;	// Try 8 (for example)'
									   + '\nBros'
									   + Help_CreatePanel
									   + '\n	.createelement			("checkboxes")'
									   + '\n		.name				("MyCheckBoxes")'
									   + '\n		.width				(150)'
									   + '\n		.caption			("My first CheckBoxes")'
									   + '\n//		.resizable			(true)'
									   + '\n//		.movable			(true)'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.color				("FF0000")'
									   + '\n//		.additem			("Option 0")'
									   + '\n//		.additem			("Option 1")'
									   + '\n//		.additem			("Option 2")'
									   + '\n		.onchange			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("Something changed !");'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.left				(200, 10)'
									   + '\n		.caption			("Show All")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			//	Bros.element("MyCheckBoxes").deleteitem(1);'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.left				(200, 40)'
									   + '\n		.caption			("Set 1, Clear 2")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyCheckBoxes").selected(1, 1).selected(2, 0);'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.parent					()'
									   + '\n;'
									   + '\nBros.element				("MyCheckBoxes");'
									   + '\nfor (var i = 0; i < Count; i++)'
									   + '\n	{'
									   + '\n	Bros.additem			("My Option " + i);'
									   + '\n	}'
									   + '\nfunction ShowAll()'
									   + '\n	{'
									   + '\n	for (var i = 0; i < Count; i++)'
									   + '\n		{'
									   + '\n		var Selected		= Bros.element("MyCheckBoxes").selected(i);'
									   + '\n		deb					("Option " + i + " is " + (Selected == 1 ? "SELECTED" : " NOT selected"));'
									   + '\n		}'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"radiobuttons", ""
									,	'<b>radiobuttons</b> is an number of radiobuttons grouped in a group.'
									,	 Help_Uncomment
									   + '\nvar Count					= 4;	// Try 8 (for example)'
									   + '\nBros'
									   + Help_CreatePanel
									   + '\n	.createelement			("radiobuttons")'
									   + '\n		.name				("MyRadioButtons")'
									   + '\n		.width				(150)'
									   + '\n		.caption			("My first Radio Buttons")'
									   + '\n//		.resizable			(true)'
									   + '\n//		.movable			(true)'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.color				("FF0000")'
									   + '\n//		.additem			("Radio Option 0")'
									   + '\n//		.additem			("Radio Option 1")'
									   + '\n//		.additem			("Radio Option 2")'
									   + '\n		.onchange			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("Something changed !");'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.left				(200, 10)'
									   + '\n		.caption			("Show All")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			//	Bros.element("MyRadioButtons").deleteitem(1);'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.left				(200, 40)'
									   + '\n		.caption			("Select 1")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyRadioButtons").selected(1);'
									   + '\n			ShowAll			();'
									   + '\n			})'
									   + '\n	.parent					()'
									   + '\n;'
									   + '\nBros.element				("MyRadioButtons");'
									   + '\nfor (var i = 0; i < Count; i++)'
									   + '\n	{'
									   + '\n	Bros.additem			("My Radio Option " + i);'
									   + '\n	}'
									   + '\nfunction ShowAll()'
									   + '\n	{'
									   + '\n	var Selected			= Bros.element("MyRadioButtons").selected();'
									   + '\n	deb						("My selected option is " + Selected);'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"mainmenu", ""
									,	'<b>mainmenu</b> is the main menu of your windows and can popup submenus.'
									,	   Help_StartExample
									   + '\n.createelement			("window")'
									   + '\n	.caption			("Main Menu Test")'
									   + '\n	.left				(10, 10, 350, 250)'
									   + '\n	.createelement		("mainmenu")'
									   + '\n		.additem		("Main 1", "",													"", "Menu_1")'
									   + '\n		.additem		("Main 2", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif",	"",	"Menu_2")'
// Improve additem because it's rebuilding all and taking much time
//									   + '\n		.additem		("OP 3")'
//									   + '\n		.additem		("OP 4", "")'
//									   + '\n		.additem		("OP 5", "", "")'
//									   + '\n		.additem		("OP 6", "", "", 12)'
//									   + '\n		.additem		("OP 6", "", "", 12)'
//									   + '\n		.additem		("OP 6", "", "", 12)'
//									   + '\n		.additem		("OP 6", "", "", 12)'
//									   + '\n		.additem		("OP 6", "", "", 12)'
									   + '\n	.createelement		("panel")'
									   + '\n		.html			("")'
									   + '\n		.align			("client")'
									   + '\n		.borderstyle	(Bros.bsNone)'
									   + '\n		.color			("C0C0C0")	// Only to see mainmenu color'
//+ '\n		.createelement	("element")'
//+ '\n			.onover		()'
//+ '\n				.color	("FF0000")'
//+ '\n				.borderstyle	(Bros.bsEdit)'
//									   + '\n		.createelement	("button")'
//									   + '\n			.caption	("Test")'
//									   + '\n			.left		(150, 100)'
//+ '\n			.ispushpull	(true)'
//+ '\n			.align		("left")'
//+ '\n			.movable		(true)'
//+ '\n			.down		()'
//+ '\n				.color	("FFFF00")'
//+ '\n			.onover		()'
//+ '\n				.color	("FF0000")'
//+ '\n				.borderstyle	(Bros.bsEdit)'
//									   + '\n			.onclick	(function (Elem, e)'
//									   + '\n				{'
//									   + '\n				Bros.element("Menu_1").popup(Elem);	// popup(Elem) indicates to Bros popup the menu close to the button.'
//									   + '\n				})'
									   + '\n		.parent			()'
									   + '\n	.createelement		("menu")'
									   + '\n		.name			("Menu_1")'
									   + '\n		.additem		("Option 11", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif", "Ctrl+A", "Menu_11") // "Menu_12" indicates to launch other menu'
									   + '\n		.additem		("Option 12", "", "", function (Elem, e)'
									   + '\n			{'
									   + '\n			deb			("You click on 2nd option of Menu_1.");'
									   + '\n			})'
									   + '\n	.createelement		("menu")'
									   + '\n		.name			("Menu_11")'
									   + '\n		.additem		("Option 111", "", "", function (Elem, e)'
									   + '\n			{'
									   + '\n			deb			("You click on 1st option of Menu_11.");'
									   + '\n			})'
									   + '\n	.createelement		("menu")'
									   + '\n		.name			("Menu_2")'
									   + '\n		.additem		("Option 21", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif", "Ctrl+A", function (Elem, e)'
									   + '\n			{'
									   + '\n			deb			("You click on 1st option of Menu_2.");'
									   + '\n			})'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"selectorpanels", ""
									,	'<b>selectorpanels</b> is an element that have one selector and multiple panels, controled by selector, where you can put your elements.'
									,	   Help_StartExample_Panel

								// Finding who is hanging selector panels
								//
								//	   + '\n	.createelement			("selector")'
								//	   + '\n		.additem			("O")'					//  1 0.044
								//	   + '\n		.additem			("O")'					//  2 0.060
								//	   + '\n		.additem			("O")'					//  3 0.090
								//	   + '\n		.additem			("O")'					//  4 0.130
								//	   + '\n		.additem			("O")'					//  5 0.186
								//	   + '\n		.additem			("O")'					//  6 0.235
								//	   + '\n		.additem			("O")'					//  7 0.297
								//	   + '\n		.additem			("O")'					//  8 0.364
								//	   + '\n		.additem			("O")'					//  9 0.461
								//	   + '\n		.additem			("O")'					// 10 0.550
								//	   + '\n		.additem			("O")'
								//	   + '\n		.additem			("O")'
								//	   + '\n		.additem			("O")'
								//	   + '\n		.additem			("O")'
								//	   + '\n		.additem			("O")'
								//	   + '\n		.additem			("O")'
								//	   + '\n	.parent					()'
								//
								//	   + '\n	.createelement			("selectorpanels")'
								//	   + '\n		.additem			("O").parent()'			//  1 0.068
								//	   + '\n		.additem			("O").parent()'			//  2 0.130
								//	   + '\n		.additem			("O").parent()'			//  3 0.223
								//	   + '\n		.additem			("O").parent()'			//  4 0.342
								//	   + '\n		.additem			("O").parent()'			//  5 0.483
								//	   + '\n		.additem			("O").parent()'			//  6 0.661
								//	   + '\n		.additem			("O").parent()'			//  7 0.829
								//	   + '\n		.additem			("O").parent()'			//  8 1.073
								//	   + '\n		.additem			("O").parent()'			//  9 1.304
								//	   + '\n		.additem			("O").parent()'			// 10 1.544
								//	   + '\n	.parent					()'

									   + '\n	.createelement			("selectorpanels")'
									   + '\n		.width				(300)'
									   + '\n		.resizable			(true)'
									   + '\n		.movable			(true)'
								//	   + '\n//		.alignment			("left")'
									   + '\n//		.alignment			("top")'
								//	   + '\n//		.alignment			("right")'
									   + '\n//		.alignment			("bottom")'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.borderstyle		(Bros.bsPanel)'
									   + '\n//		.borderstyle		(Bros.bsEdit)'
									   + '\n//		.borderstyle		(Bros.bsButtonUp)'
									   + '\n//		.borderstyle		(Bros.bsNone)'
									   + '\n		.addparentitem		("Option 0")'
									   + '\n			.createelement	("label")'
									   + '\n				.caption	("Label created after .additem(...)")'
									   + '\n			.parentitem		()'
									   + '\n		.additem			("Option 1", "' + Bros.FS.A_BrosPublic_Img_I32 + 'Icon_Bros.gif")'
									   + '\n		.additem			("Option 2")'
									   + '\n		.item				(0)				// Selects the panel zero (NEED .parent() after)'
									   + '\n			.createelement	("label")'
									   + '\n				.caption	("Label created after .item(0)")'
									   + '\n			.parentitem		()'
									   + '\n		.item				(2)'
									   + '\n			.createelement	("button")'
									   + '\n				.caption	("BPanel 2")'
									   + '\n			.parentitem		()'
									   + '\n		.item				(1)'
									   + '\n			.createelement	("button")'
									   + '\n				.caption	("BPanel 1")'
									   + '\n			.parentitem		()'
//									   + '\n			.parent			()'
									   + '\n		.selected			(2)				// OLNY Selects the panel 2 (need no .parent() after)'
									   + '\n//		.caption			("My Option 2")'
									   + '\n//		.deleteitem			(1)'
							//		   + '\n		.deleteitem			(0)'
							//		   + '\n		.deleteitem			(0)'
									   + '\n		.deb				("The selected the Panel is " + Bros.selected())'
									   + '\n		.onchange			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("You select the Panel " + Bros.selected());'
									   + '\n			})'
									   + '\n	.parent					()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"calendar", ""
									,	'<b>calendar</b> is an element that you can use in several applications like simple calendar, to do list, birthdays, etc.'
									+	'<p><b>calendar</b> is a powerful element that have great possibilities due to the fact that all the aspect can be changed by developer.'
									+	'<p>To see all the possbilities, with Text Editor, open the file:'
									+	'<p>ReadOnly_Bros:/js/BrosApps/BrosApp_Calendar.js'
									,	   Help_StartExample_Panel
									+'\n	Bros.createelement			("calendar")'
									+'\n		.align					("client")'
							//		+'\n		.resizable				(true)'
									+'\n		.refresh				()		// Calendar only will be builder after the refresh method'
									+'\n		;'
									]);

		HelpPages.push				(["Element",	"editarea", ""
									,	'In <b>editarea</b> you can write your informations.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("What is in ?")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("What is in = " + Bros.element("MyEditArea").value());'
									   + '\n			})'
									   + '\n	.createelement			("label")'
									   + '\n		.caption			("Type something here:")'
									   + '\n	.createelement			("editarea")'
									   + '\n	//	.mode				("texteditor")'
									   + '\n	//	.mode				("codeeditor")'
									   + '\n	//	.font				({size:30})'
									   + '\n		.name				("MyEditArea")'
									   + '\n		.width				(330, 150)'
									   + '\n		.resizable			(! false)'
									   + '\n		.value				("?")'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.resizable			(true)'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"edit", ""
									,	'In <b>edit</b> is the same as editarea but accepts only one line.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("What is in ?")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			deb				("What is in = " + Bros.element("MyEdit").text());'
									   + '\n			})'
									   + '\n	.createelement			("label")'
									   + '\n		.caption			("Type something here:")'
									   + '\n	.createelement			("edit")'
									   + '\n		.name				("MyEdit")'
									   + '\n//		.mode				("password")'
									   + '\n		.text				("?")'
									   + '\n		.font				({bold:true})'
									   + '\n//		.borderstyle		(Bros.bsBlack1)'
									   + '\n//		.resizable			(true)'
									   + '\n//		.width				(200)'
									   + '\n//		.height				(100)'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"editbutton", ""
									,	'<b>editbutton</b> is an edit with an inside button for general purpose.'
									,	   Help_StartExample
									   + '\n.createelement			("panel")'
									   + '\n	.left				(10, 10, 220, 220)'		// H 150
									   + '\n	.html				("")'
									   + '\n	.createelement		("editarea")'
									   + '\n		.name			("MyEditArea")'
									   + '\n		.width			(200, 100)'
									   + '\n	.createelement		("editbutton")'
									   + '\n		.name			("MyEditButton")'
									   + '\n		.width			(200)'
									   + '\n		.value			("Type something here")'
									   + '\n//		.resizable		(true)'
									   + '\n//		.movable		(true)'
									   + '\n//		.imagesrc		("' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif")'
// ADEQUATE HERE
									   + '\n//		.imagewidth		(10, 10)			// Accepts: Width, Height'
									   + '\n//		.imagewidth		(48)				// Auto adjust image height'
									   + '\n//		.imagewidth		(64, 32)			// Accepts: Width, Height'
									   + '\n//		.imagewidth		([80])				// Accepts array: [Width]'
									   + '\n//		.imagewidth		([96, 48])			// Accepts array: [Width, Height]'
									   + '\n//		.imageheight	(78)				// Does NOT accept array'
									   + '\n		.onclickon		("down")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			var X = Bros.element("MyEditButton").value();'
									   + '\n			Bros.element("MyEditArea").value(Bros.element("MyEditArea").value() + X + "\\n");'
// BUG HERE
//+ '\n			Bros.element("MyEditArea").value(Bros.element("MyEditArea").value() + Bros.element("MyEditButton").value() + "\\n");'
									   + '\n			})'
									   + '\n.parent					()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"select", ""
									,	'<b>select</b> allows you to to choose one of many options.'
									   +'<p>Notice that <b>text</b> property allow you to set what to show and <b>value</b> property gets the last selected option.'
									   +'<p>Although <b>select</b> is a <b>editbutton</b> descendant, do not set <b>onclick</b> because if you do, <b>select</b> will not work properly.'
									,	   Help_StartExample
									   + '\n.createelement			("panel")'
									   + '\n	.left				(10, 10, 350, 250)'
									   + '\n	.html				("")'
									   + '\n	.createelement		("editarea")'
									   + '\n		.name			("MyEditArea")'
									   + '\n		.width			(330, 70)'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("Inspect my Select")'
									   + '\n		.autosize		(true)'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			InspectMySelect();'
									   + '\n			})'
									   + '\n	.createelement		("select")'
									   + '\n		.name			("MySelect")'
									   + '\n		.text			("(select an option)")'
									   + '\n		.width			(200)'
									   + '\n		.additem		("My select option 1", "", "Value 1")	// Value: string'
									   + '\n//		.resizable		(true)'
									   + '\n		.additem		("My select option 2", "", 12 * 12)		// Value: number (can be anything like boolean, objects, etc.)'
									   + '\n		.additem		("My select option 3")					// Value: is the caption [My select option 3]'
									   + '\n		.additem		("-")'
									   + '\n		.additem		("My select option 4", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif")'
									   + '\n		.additem		("My select option 5", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif",	"Alt+A")		// Instead of shortcut will be the value'
									   + '\n		.additem		("My select option 6", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif",	"",	 "Menu_2")	// OOPS ! String on 4th argument will launch a sub-menu'
									   + '\n		.additem		("My select option 7", "", "Value6", function (Elem)'
									   + '\n			{'
									   + '\n			deb(123);	// Will not fire because select only apply submenus (if 4th argument is string)'
									   + '\n			})'
									   + '\n//		.deleteitem		(6)'
									   + '\n		.onchange		(function (Elem, e)'
									   + '\n			{'
									   + '\n			InspectMySelect();'
									   + '\n			})'
									   + '\n.parent					()'
									   + '\n.createelement			("menu")'
									   + '\n	.name				("Menu_2")'
									   + '\n	.additem			("Option 51", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif", "Ctrl+A", function (Elem, e)'
									   + '\n		{'
									   + '\n		// Will not fire because select only apply submenus (if 4th argument is string)'
									   + '\n		deb				("You click on 1st option of Menu_2.");'
									   + '\n		})'
									   + '\n	.additem			("More options...", "",	"",	"Menu_3")'
									   + '\n.createelement			("menu")'
									   + '\n	.name				("Menu_3")'
									   + '\n	.additem			("Additional option 1", "", "MyValueAdditionalOption1")'
									   + '\n	.additem			("Additional option 2", "' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif")'
									   + '\n	.additem			("Additional option 3")'
									   + '\n;'
									   + '\nfunction InspectMySelect()'
									   + '\n	{'
									   + '\n	var ToShow			= "";'
									   + '\n	ToShow			   +=    "text          = " + Bros.element("MySelect").text();'
									   + '\n	ToShow			   += "\\nvalue         = " + Bros.value		();		// Not need to call element again'
									   + '\n	ToShow			   += "\\ntypeof(value) = " + typeof(Bros.value());'
									   + '\n	ToShow			   += "\\nselected      = " + Bros.selected	();'
								//	   + '\n	Bros.element		("MyEditArea").value(ToShow + "\\n" + Bros.element("MyEditArea").value());'
									   + '\n	Bros.element		("MyEditArea").value(ToShow);'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"splitter", ""
									,	'<b>splitter</b> allows you to drag and resize close (and aligned) elements.'
									   +'<p>Set align property (as "left", "top", "right" or "bottom") <b>before</b> setting other properties (like width, height, borderstyle, etc.)'
									   +' because Bros sets width/height and borderstyle automatically after you set .align(...).'
									,	   Help_StartExample_Panel
									   + '\n	.borderstyle			(Bros.bsNone)'
									   + '\n	.createelement			("panel")'
									   + '\n		.color				("FF0000")'
									   + '\n		.align				("top")'
									   + '\n		.borderstyle		(Bros.bsNone)'
									   + '\n		.parent				()'
									   + '\n	.createelement			("splitter")'
									   + '\n		.align				("top")'
									   + '\n//		.borderstyle		(Bros.bsNone)'
									   + '\n//		.height				(20)'
									   + '\n//		.minsize			(0)'
									   + '\n	.createelement			("panel")'
									   + '\n		.color				("0000FF")'
									   + '\n		.align				("left")'
									   + '\n		.borderstyle		(Bros.bsNone)'
									   + '\n		.parent				()'
									   + '\n	.createelement			("splitter")'
									   + '\n		.align				("left")'
									   + '\n//		.borderstyle		(Bros.bsNone)'
									   + '\n//		.width				(20)'
									   + '\n//		.minsize			(0)'
									   + '\n	.createelement			("panel")'
									   + '\n		.color				("000000")'
									   + '\n		.align				("left")'
									   + '\n		.borderstyle		(Bros.bsNone)'
									   + '\n		.parent				()'
									   + '\n	.createelement			("splitter")'
									   + '\n		.align				("left")'
									   + '\n//		.borderstyle		(Bros.bsNone)'
									   + '\n//		.width				(20)'
									   + '\n//		.minsize			(0)'
									   + '\n	.createelement			("panel")'
									   + '\n		.color				("FFFF00")'
									   + '\n		.align				("client")'
									   + '\n		.borderstyle		(Bros.bsNone)'
									   + '\n		.parent				()'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"tree", ""
									,	'<b>tree</b> allows you to display data in a tree way.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("tree")'
									   + '\n		.width				(200, 200)'
									   + '\n		.resizable			(true)'
+ '\n		.scrollbars			("both")'
									   + '\n	//	.color				("808080")'
									   + '\n	//	.borderstyle		(Bros.bsNone)'
									   + '\n		.addparentitem		("Root Item 1")'
									   + '\n			.additem		("Item 11")'
									   + '\n			.additem		("Item 12")'
									   + '\n			.additem		("Item 13")'
									   + '\n			.parentitem		()'
								//	   + '\n		.additem			("Root Item 2")'
								//	   + '\n		.additem			("Root Item 3", "' + Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + 'Img_Tre_3_BookClosed.png")'
									   + '\n		.additem			("Root Item 2", "' + Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + 'Img_Tre_3_BookClosed.png", "' + Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + 'Img_Tre_4_BookOpened.png")'
									   + '\n		.addparentitem		("Root Item 3")'
									   + '\n			.additem		("Item 31")'
									   + '\n			.addparentitem	("Item 32")'
									   + '\n				.additem	("Item 321")'
									   + '\n				.additem	("Item 322")'
									   + '\n				.additem	("Item 323")'
									   + '\n				.additem	("Item 324")'
									   + '\n				.additem	("Item 325")'
									   + '\n				.parentitem	()'
									   + '\n			.additem		("Item 53")'
									   + '\n			.parentitem		()'
									   + '\n		.onclick(function(Elem, e, Node)'
									   + '\n			{'
									   + '\n			deb("OnClick", Node.caption);'
									   + '\n	//		Bros.expand		(Node);			// Expand selected Node'
									   + '\n	//		Bros.collapse	(Node);			// Collapses selected Node'
									   + '\n	//		Bros.expandall	(Node);			// Expand all Nodes from selected Node'
									   + '\n	//		Bros.collapseall(Node);			// Collapses all Nodes from selected Node'
									   + '\n	//		Bros.expandall	();				// Expand all Nodes'
									   + '\n	//		Bros.collapseall();				// Collapses all Nodes'
									   + '\n	//		Bros.deleteitem	(Node);'
									   + '\n	//		Bros.deletechildren(Node);'
									   + '\n			})'
//									   + '\n		.editable			(true)'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"table", ""
									,	'<b>spreadsheet</b> allows you to display data inside a grid.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("button")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element	("MySpreadSheet");'
									   + '\n			deb				("rowcount = " + Bros.rowcount());'
									   + '\n			Bros.rowcount	(2);			// WITHOUT fixedrows'
								//	   + '\n			Bros.rowcount	(3);'
									   + '\n			deb				("rowcount = " + Bros.rowcount());'
									   + '\n			deb				("colcount = " + Bros.colcount());'
									   + '\n			Bros.colcount	(3);			// WITHOUT fixedcols'
									   + '\n			deb				("colcount = " + Bros.colcount());'
									   + '\n			})'
									   + '\n	.createelement			("table")'
									   + '\n		.name				("MySpreadSheet")'
									   + '\n		.height				(170)'
									   + '\n		.resizable			(true)'
									   + '\n	//	.color				("808080")'
									   + '\n	//	.borderstyle		(Bros.bsNone)'
									   + '\n	//	.fixedrows			(0)				// 0 or 1 (default)'
									   + '\n	//	.fixedcols			(0)				// 0 or 1 (default)'
									   + '\n		.value				(0, 0, "Peter")'
									   + '\n		.value				(0, 1, 100)'
									   + '\n		.value				(0, 2, Bros.value(0, 1) * 2)'
									   + '\n		.value				(1, 0, "John")'
									   + '\n		.value				(1, 3, "Value<br>in<br>1,3<br>cell D2")'
									   + '\n		.value				(1, 1, 150)'
									   + '\n		.value				(2, 1, Bros.value(0, 1) + Bros.value(1, 1))'
									   + '\n		// Headers'
									   + '\n		.value				(-1, 0, "Name")'
									   + '\n		.value				(-1, 1, "Weight")'
									   + '\n		.value				(2, -1, "Totals")'
									   + '\n		// Formats'
									   + '\n		.editable			(true)		// Master editable flag'
									   + '\n		.format				("table", {font:{bold:true}, halign:"right", valign:"bottom", editable:false})	// All cells not editable'
									   + '\n		.format				("row", 2, {color:"FF0000"})'
									   + '\n		.format				("col", 0, {halign:"left"})'
									   + '\n		.format				("col", 1, {font:{bold:false}, color:"8080FF", editable:true})							// Column 1 becames editable !'
									   + '\n		.format				("cell", 1, 3, {halign:"center", font:{color:"FFFF00"}, color:"0080FF", editable:true})	// Cell 1,2 becames editable as well !'
									   + '\n	//	.format				("table", {font:{family:"Verdana", size:15, color:"FF0000", bold:true, italic:true, underline:true}})'
									   + '\n		.onselect			(function (Elem, e, FromTo)'
									   + '\n			{'
									   + '\n			deb				("R1 = " + FromTo[0][0], "C1 = " + FromTo[0][1], "R2 = " + FromTo[1][0], "C1 = " + FromTo[1][1]);'
									   + '\n			deb				("LastCellValue = " + Bros.value(FromTo[1][0], FromTo[1][1]));'
									   + '\n			})'
									   + '\n.parent						()'
									   + '\n;'
								//	   + '\n	for (var i = 1; i <= 100; i++)'
								//	   + '\n		{'
								//	   + '\n		Bros.value			(i + 10, 0, "John");'
								//	   + '\n		Bros.value			(0, i + 10, "Andre");'
								//	   + '\n		}'
									]);

		HelpPages.push				(["Element",	"slider", ""
									,	'<b>slider</b> allows you control things.'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("slider")'
									   + '\n		.left				(10, 10)'
									   + '\n	//	.color				(Bros.clBlue)'
									   + '\n	//	.orientation		("vertical")'
									   + '\n		.movable			(true)'
									   + '\n		.resizable			(true)'
									   + '\n		.onchange			(function (Elem, e, Progress)'
									   + '\n			{'
									   + '\n			//	deb			("Progress = "	+ Progress);'
									   + '\n			//	deb			("value = "		+ Bros.value());	// Same as Progress'
									   + '\n			Bros.element	("MyGauge").value(Progress);'
									   + '\n			})'
									   + '\n	.createelement			("gauge")	// Try "slider" here to see similar behavior'
									   + '\n		.name				("MyGauge")'
									   + '\n		.left				(170, 10)'
									   + '\n	//	.color				(Bros.clBlue)'
									   + '\n	//	.orientation		("vertical")'
									   + '\n		.movable			(true)'
									   + '\n		.resizable			(true)'
									]);

		HelpPages.push				(["Element",	"gauge", ""
									,	'<b>gauge</b> allows you to see a progress bar of some process.'
									,	   Help_StartExample_Panel
							// XPTALIGNCLIENT
							//		   + '\n	.createelement			("panel")'
							//		   + '\n		.left				(10, 10)'
									   + '\n	.createelement			("slider")'
							// XPTALIGNCLIENT
							//		   + '\n		.align				("client")'
							// XPTALIGNCLIENT - Comment here
									   + '\n		.left				(10, 10)'
									   + '\n	//	.color				(Bros.clBlue)'
									   + '\n	//	.orientation		("vertical")'
									   + '\n		.movable			(true)'
									   + '\n		.resizable			(true)'
									   + '\n		.onchange			(function (Elem, e, Progress)'
									   + '\n			{'
									   + '\n			//	deb			("Progress = "	+ Progress);'
									   + '\n			//	deb			("value = "		+ Bros.value());	// Same as Progress'
									   + '\n			Bros.element	("MyGauge").value(Progress);'
									   + '\n			})'
							// XPTALIGNCLIENT
							//		   + '\n	.parent					()'
							//		   + '\n	.createelement			("panel")'
							//		   + '\n		.left				(170, 10)'
									   + '\n	.createelement			("gauge")	// Try "slider" here to see similar behavior'
							// XPTALIGNCLIENT
							//		   + '\n		.align				("client")'
									   + '\n		.name				("MyGauge")'
							// XPTALIGNCLIENT - Comment here
									   + '\n		.left				(170, 10)'
									   + '\n	//	.color				(Bros.clBlue)'
									   + '\n	//	.orientation		("vertical")'
									   + '\n		.movable			(true)'
									   + '\n		.resizable			(true)'
									]);

		HelpPages.push				(["Element",	"menu", ""
									,	'<b>menu</b> can be build to be popuped somewhere.'
									,	   Help_StartExample
									   + '\n.createelement("menu")'
									   + '\n	.name("My1stMenu")'
// NOT APPLYING Shortcut
									   + '\n	.additem("Option 11", "' + Bros.FS.A_BrosPublic_Img_I32 + 'Icon_Bros.gif", "Ctrl+A", "My2ndMenu") // "My2ndMenu" indicates to launch other menu'
									   + '\n	.additem("Option 12", "", "", function (Elem, e)'
									   + '\n		{'
									   + '\n		deb		("You click on 2nd option of first menu.");'
									   + '\n		})'
									   + '\n.createelement("menu")'
									   + '\n	.name("My2ndMenu")'
									   + '\n	.additem("Option 21", "", "", function (Elem, e)'
									   + '\n		{'
									   + '\n		deb		("You click on 1st option of second menu.");'
									   + '\n		})'
									   + '\n.createelement("button")'
									   + '\n	.caption("Popup me")'
									   + '\n	.left(10, 10)'
									   + '\n	.onclick(function (Elem, e)'
									   + '\n		{'
									   + '\n		Bros.element("My1stMenu").popup(Elem);	// popup(Elem) indicates to Bros popup the menu close to the button.'
									   + '\n		})'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"timer", ""
									,	'Use <b>timer</b> to fire ontimer allowing you to run your methods periodically.'
									   +'<p>Set <b>ontimer</b> <b><u>after</u></b> setting <b>value</b>.'
									,	   Help_StartExample
									   + '\n.createelement			("panel")'
									   + '\n	.left				(10, 10, 350, 115)'
									   + '\n	.html				("")'
									   + '\n	.createelement		("image")'
									   + '\n		.name			("MyImage")'
									   + '\n		.imagesrc		("' + Bros.URL_Path_Img_Bros_Ex + 'ImgEx_Bros.gif")'
									   + '\n	.createelement		("button")'
									   + '\n		.name			("MyButton")'
									   + '\n		.caption		("Enable Timer")'
									   + '\n		.autosize		(! false)'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTimer").enabled(! Bros.element("MyTimer").enabled());'
									   + '\n			var Enabled	= Bros.element("MyTimer").enabled();'
									   + '\n			Bros.element("MyButton").caption(Enabled ? "<b>Disable Timer</b>" : "Enable Timer");'
									   + '\n		 //	Be aware NOT use below statement (instead above) because javascript runs'
									   + '\n		 //	Bros.element("MyButton") BEFORE Bros.element("MyTimer").enabled() ? ...'
									   + '\n		 //	So, caption will be applied to the Bros current element (that is "MyTimer" and not "MyButton")'
									   + '\n		 //	(and nothing will happen because timer does not show anything)'
									   + '\n		 //	Bros.element("MyButton").caption(Bros.element("MyTimer").enabled() ? "<b>Disable Timer</b>" : "Enable Timer");'
									   + '\n			})'
									   + '\n	.createelement		("timer")'
									   + '\n		.name			("MyTimer")'
									   + '\n//		.value			(1000)		// ontimer each ... miliseconds'
									   + '\n		.value			(10)		// ontimer each ... miliseconds'
									   + '\n		.ontimer		(function (Elem)'
									   + '\n			{'
									   + '\n//			deb		(Bros.CElm.WhoAmI(Elem));'
									   + '\n			var Left	= Bros.element("MyImage").left();'
									   + '\n			var Width	= Bros.width();'
									   + '\n			Left	   += 1;'
									   + '\n			if (Left > (340 - Width))'
									   + '\n				Left	= 10;'
									   + '\n			Bros.left	(Left);'
									   + '\n			})'
									   + '\n.parent					()'
									   + '\n;'
									]);

		HelpPages.push				(["Element",	"tmeter", ""
									,	'Use <b>tmeter</b> is used to measure elapsed times.'
									,	   Help_StartExample
									   + '\n.createelement			("panel")'
									   + '\n	.left				(10, 10, 350, 250)'
									   + '\n	.html				("")'
									   + '\n	.createelement		("tmeter")'
									   + '\n		.name			("MyTMeter")'
									   + '\n	.createelement		("button")'
// BUG HERE (DontAppendHTML in tmeter are caming back left to zero !
									   + '\n		.left			(10, 10)'
									   + '\n		.caption		("start")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").start();'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("stop")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").stop();'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("pause")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").pause();'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("resume")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").resume();'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("lap")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").lap();'
									   + '\n//			Bros.element("MyTMeter").lap("Point 1");'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("deblaps")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").deblaps();'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.caption		("lap/pause/deb")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTMeter").lap("lap/pause/deblaps").pause().deblaps();'
									   + '\n			})'
									   + '\n	.createelement		("label")'
									   + '\n		.name			("MyTMeterValue")'
									   + '\n		.autosize		(false)'
									   + '\n		.left			(100, 8, 100, 20)'
									   + '\n		.caption		("0.000")'
									   + '\n		.halign			("right")'
									   + '\n		.valign			("middle")'
									   + '\n		.color			("FFFFFF")'
									   + '\n		.borderstyle	(Bros.bsEdit)'
									   + '\n	.createelement		("label")'
									   + '\n		.name			("MyLabelTimeout")'
									   + '\n		.caption		("timeout (5 seconds) : no")'
									   + '\n	.createelement		("label")'
									   + '\n		.name			("MyLabelLaps")'
									   + '\n		.caption		("0 laps")'
									   + '\n	.createelement		("button")'
									   + '\n		.name			("MyButton")'
									   + '\n		.caption		("<b>Disable Timer</b>")'
									   + '\n		.autosize		(! false)'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyTimer").enabled(! Bros.element("MyTimer").enabled());'
									   + '\n			var Enabled	= Bros.element("MyTimer").enabled();'
									   + '\n			Bros.element("MyButton").caption(Enabled ? "<b>Disable Timer</b>" : "Enable Timer");'
									   + '\n		 //	Be aware NOT use below statement (instead above) because javascript runs'
									   + '\n		 //	Bros.element("MyButton") BEFORE Bros.element("MyTimer").enabled() ? ...'
									   + '\n		 //	So, caption will be applied to the Bros current element (that is "MyTimer" and not "MyButton")'
									   + '\n		 //	(and nothing will happen because timer does not show anything)'
									   + '\n		 //	Bros.element("MyButton").caption(Bros.element("MyTimer").enabled() ? "<b>Disable Timer</b>" : "Enable Timer");'
									   + '\n			})'
									   + '\n	.createelement		("timer")'
									   + '\n		.name			("MyTimer")'
									   + '\n		.value			(100)		// ontimer each ... miliseconds'
									   + '\n		.enabled		(true)'
									   + '\n		.ontimer		(function (Elem)'
									   + '\n			{'
									   + '\n			var ToShow	= GetElapsedToShow(Bros.element("MyTMeter").elapsed());'
									   + '\n			Bros.element("MyTMeterValue").caption(ToShow);'
									   + '\n			var Timeout	= Bros.element("MyTMeter").timeout(5000);'
									   + '\n			Bros.element("MyLabelTimeout").caption(Timeout ? "timeout (5 seconds) : <b>Yes</b>" : "timeout (5 seconds) : no");'
									   + '\n			ShowLaps	();'
									   + '\n			})'
									   + '\n.parent					()'
									   + '\n;'
									   + '\nfunction GetElapsedToShow(Elapsed)'
									   + '\n	{'
									   + '\n	var ToShow			= "" + Elapsed;'
									   + '\n		 if (ToShow.length == 1) ToShow = "000"	+ ToShow;'
									   + '\n	else if (ToShow.length == 2) ToShow = "00"	+ ToShow;'
									   + '\n	else if (ToShow.length == 3) ToShow = "0"	+ ToShow;'
									   + '\n	ToShow				= ToShow.substr(0, ToShow.length - 3) + "." + ToShow.substr(ToShow.length - 3, 3);'
									   + '\n	return ToShow;'
									   + '\n	}'
									   + '\nfunction ShowLaps()'
									   + '\n	{'
									   + '\n	var Laps			= Bros.element("MyTMeter").laps();'
									   + '\n	var ToShow			= Laps.length + " laps";'
									   + '\n	for (var i = 0; i < Laps.length; i++)'
									   + '\n		{'
									   + '\n		var Lap			= Laps[i];'
									   + '\n		ToShow		   += ", " + GetElapsedToShow(Lap[0]);'
									   + '\n		}'
									   + '\n	Bros.element		("MyLabelLaps").caption(ToShow);'
									   + '\n	}'
									]);

		HelpPages.push				(["Element",	"window", ""
									,	'<b>window</b> is the container of one application elements.'
									,	   Help_Hello_World
									]);

		//###########################################################################
		//###########################################################################
		//##
		//## Methods Type Property
		//##
		//###########################################################################
		//###########################################################################

		HelpPages.push				(["Method",		"align"
									,	'.align() or .align("none" | "left" | "top" | "right" | "bottom" | "client")'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"alignment"
									,	'.alignment() or .alignment("left" | "top" | "right" | "bottom")'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"apparguments"
									,	'.apparguments() or .apparguments(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "application"]
									]);

		HelpPages.push				(["Method",		"autosize"
									,	'.autosize() or .autosize(true | false)'
									,	""
									   +'<p>'
									,	["Element", "label"]
									]);

		HelpPages.push				(["Method",		"borderstyle"
									,	'.borderstyle() or .borderstyle([array of up to 8 arrays])'
									,	"Each array can be empty ([]) meaning no border, or, for example:"
									   +'<p>["FF0000"] - Same as [Bros.clRed] (1 pixel, "solid")'
									   +'<p>["FF0000", 3] - Same as [Bros.clRed, 3] (3 pixels, "solid")'
									   +'<p>["FF0000", 3, "dotted"] - Same as [Bros.clRed, 3] (3 pixels "dotted")'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"caption"
									,	'.caption() or .caption(NewValue)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"colcount"
									,	'.colcount() or .colcount(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"color"
									,	'.color() or .color(ColorValue)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"down"
									,	'.down()'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"editable"
									,	'.editable() or .editable(true | false)'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"enabled"
									,	'.enabled() or .enabled(true | false)'
									,	""
									   +'<p>'
									,	["Element", "timer"]
									]);

		HelpPages.push				(["Method",		"fixedcols"
									,	'.fixedcols() or .fixedcols(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"fixedrows"
									,	'.fixedrows() or .fixedrows(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"font"
									,	'.font() or .font(define props in an object. Ex: {"bold":true})'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"goingdown"
									,	'.goingdown()'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"goingup"
									,	'.goingup()'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"gradient"
									,	'.gradient() or .gradient([FromWhere, StartColor, EndColor])'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"halign"
									,	'.halign() or .halign("left" | "center" | "right")'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"height"
									,	'.height() or .height(ValueHeight)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"imagealignment"
									,	'.imagealignment() or .imagealignment(ImageAlignmetValue)'
									,	""
									   +'<p>'
									,	["Element", "imagelabel"]
									]);

		HelpPages.push				(["Method",		"imageborder"
									,	'.imageborder() or .imageborder(Bros.ibNone | Bros.ibSingle | Bros.ib3D)'
									,	""
									   +'<p>'
									,	["Element", "checkbox"]
									]);

		HelpPages.push				(["Method",		"imageheight"
									,	'.imageheight() or .imageheight(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"imagesrc"
									,	'.imagesrc() or .imagesrc(URL | "file:...")'
									,	""
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"imagewidth"
									,	'.imagewidth() or .imagewidth(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"innerspacement"
									,	'.innerspacement() or .innerspacement(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "imagelabel"]
									]);

		HelpPages.push				(["Method",		"ispushpull"
									,	'.ispushpull() or .ispushpull(true | false)'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"left"
									,	'.left() or .left(ValueLeft, [, ValueTop [, ValueWidth, ValueHeight]]])'
									,	"Accept array."
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"minsize"
									,	'.minsize() or .minsize(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "splitter"]
									]);

		HelpPages.push				(["Method",		"mode"
									,	'.mode() or .mode("texteditor" | "codeeditor" | "password")'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"movable"
									,	'.movable() or .movable(true | false)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"name"
									,	'.name(ElementName)'
									,	"Defines the current element name that will can access via element method."
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"onclickon"
									,	'.onclickon() or .onclickon("up" | "down")'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"opacity"
									,	'.opacity([NewValue])'
									,	"Gets or sets the opacity (from 0 to 1)."
									   +'<p>All chidren elements will be affected.'
									,  Help_Uncomment
									   + '\nvar Angle				= 0;'
									   + '\nBros'
									   + '\n	.createelement		("button")'
									   + '\n		.left			(10, 40)'
									   + '\n		.caption		("Rotate")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Angle	   += 30;'
									   + '\n			Bros.rotate	(Angle);'
									   + '\n			Bros.element("MyPanel").opacity(0.5);'
									   + '\n			})'
									   + '\n	.createelement		("panel")'
									   + '\n		.name			("MyPanel")'
									   + '\n		.left			(10, 70, 100, 100)'
									   + '\n		.movable		(true)'
									   + '\n		.resizable		(true)'
									   + '\n		.createelement	("button")'
									   + '\n		.parent			()'
									   + '\n	.createelement		("button")'
									   + '\n		.left			(200, 40)'
									   + '\n		.caption		("Animate")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element("MyPanel").opacity(0.1).left(200, 100, 40, 40).rotate(90);'
									   + '\n			Bros.element("MyPanel").animate({left:10, width:100, height:100, top:70, opacity:1, rotate:0, duration:500, onend:function(Elem)'
									   + '\n				{'
									   + '\n				deb		("Animate Done")'
									   + '\n				} });'
									   + '\n			})'
									   + '\n	.createelement		("button")'
									   + '\n		.left			(200, 80)'
									   + '\n		.caption		("Window")'
									   + '\n		.onclick		(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element(MyWindow).rotate(0).animate({rotate:360});'
									   + '\n			})'
									   + '\n;'
									]);

		HelpPages.push				(["Method",		"orientation"
									,	'.orientation() or .orientation("horizontal" | "vertical")'
									,	""
									   +'<p>'
									,	["Element", "slider"]
									]);

		HelpPages.push				(["Method",		"outerspacement"
									,	'.outerspacement() or .outerspacement(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "imagelabel"]
									]);

		HelpPages.push				(["Method",		"pixelsoffset"
									,	'.pixelsoffset() or .pixelsoffset([dx, dy])'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"range"
									,	'.range()'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"resizable"
									,	'.resizable() or .resizable(true | false)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"rowcount"
									,	'.rowcount() or .rowcount(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"scriptsrc"
									,	'.scriptsrc() or .scriptsrc(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "application"]
									]);

		HelpPages.push				(["Method",		"scrollbars"
									,	'.scrollbars() or .scrollbars("none" | "horizontal" | "vertical" | "both")'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"selectable"
									,	'.selectable() or .selectable(true | false)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"selectormode"
									,	'.selectormode() or .selectormode("tab" | "button")'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"startmenu"
									,	'.startmenu() or .startmenu(ParentMenuName)'
									,	""
									   +'<p>'
									,	["Element", "application"]
									]);

		HelpPages.push				(["Method",		"text"
									,	'.text() or .text(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"top"
									,	'.top() or .top(ValueTop)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"valign"
									,	'.valign() or .valign("top" | "middle" | "bottom")'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"value"
									,	'.value() or .value(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"visible"
									,	'.visible() or .visible(true | false)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"width"
									,	'.width() or .width(ValueWidth [, ValueHeight])'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"wraptext"
									,	'.wraptext() or .wraptext(true | false)'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		//###########################################################################
		//###########################################################################
		//##
		//## Methods Type Method
		//##
		//###########################################################################
		//###########################################################################

		HelpPages.push				(["Method",		"additem"
									,	'.additem(Caption [, ImageSrc [, ShortCut [, OnClick]]])'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"addparentitem"
									,	'.additem(Caption [, ImageSrc [, ShortCut [, OnClick]]])'
									   +'<br>or .additem(Caption [, ImageSrc [, ImageSrcOpen]]) for tree'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"animate"
									,	'.animate({prop:value [, prop:value] [, prop:value] ...})'
									,	"This method will animate the selected element based on an input object."
									   +'<p>That object must have properties such as left, top, width, height, opacity or rotate with the final desired values.'
									   +'<p>The initial correspondent values will be the current values.'
									   +'<p>Obviously you can use only the properties you want.'
									   +'<p>Optionally you can supply two extra properties:'
									   +'<p><b>duration</b> the total time (in miliseconds) you want the animation runs (default is 2000 ms).'
									   +'<p><b>onend</b> the method which will be called on animation end.'
									,	["Method", "opacity"]
									]);

		HelpPages.push				(["Method",		"append"
									,	'.append(Value)'
									,	"Appends Value to the HTML content of an element."
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"bottom"
									,	'.bottom(NewValue)'
									,	"Positionates element NewValue pixels to the bottom of parent element."
									   +'<p>This setting will be loosed if the element is moved somehow.'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"centralize"
									,	'.centralize()'
									,	"Positionates element in the center of parent element."
									   +'<p>This setting will be loosed if the element is moved somehow.'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"clientheight"
									,	'.clientheight() or .clientheight(ValueClientHeight)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"clientwidth"
									,	'.clientwidth() or .clientwidth(ValueClientWidth [, ValueClientHeight])'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"close"
									,	'.close()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"collapse"
									,	'.collapse(Node)'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"collapseall"
									,	'.collapseall(Node)'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"createelement"
									,	'.createelement(ClassName)'
									,	"Creates a new Bros element under the closest parent element that accepts sub-elements (panel, group, window, etc.)."
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"cssext"
									,	'.cssext("CSSProp", CSSValue)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"cssint"
									,	'.cssint("CSSProp", CSSValue)'
									,	""
									   +'<p>'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"deb"
									,	'.deb([value[, value[, value...]]])'
									,	"Used for debug purposes."
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"deblaps"
									,	'.deblaps()'
									,	""
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"deletechildren"
									,	'.deletechildren() or .deletechildren(Node) for tmeter'
									,	"Deletes children elements of current element."
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"deleteelement"
									,	'.deleteelement()'
									,	"Call this method to delete any element (and it's children) and release browser memory.<p>" +
										"You may not need to use this method because Bros already do this when you close the windows."
									,	   Help_StartExample
									   + '\n.createelement("panel")'
									   + '\n	.name("MyPanel")'
									   + '\n	.parent()'
									   + '\n.createelement("button")'
									   + '\n	.width(200)'
									   + '\n	.caption("Click me to delete above")'
									   + '\n	.onclick(function(Elem, e)'
									   + '\n		{'
									   + '\n		Bros.element("MyPanel").deleteelement();'
									   + '\n		})'
									   + '\n;'
									]);

		HelpPages.push				(["Method",		"deleteitem"
									,	'.deleteitem()'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"deleteitems"
									,	'.deleteitems()'
									,	""
									   +'<p>'
									,	["Element", "select"]
									]);

		HelpPages.push				(["Method",		"deletetree"
									,	'.deletetree()'
									,	"Deletes full tree."
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"elapsed"
									,	'.elapsed()'
									,	""
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"element"
									,	'.element(ElementName)'
									,	""
									   +'<p>'
									,	Help_StartExample
									   + '\n.createelement("element")'
									   + '\n	.html("")'
									   + '\n	.left(10, 10, 180, 180)'
									   + '\n	.html("MY ELEMENT")'
									   + '\n	.append("<br>2nd Line")'
									   + '\n//	.centralize()'
									   + '\n//	.bottom(20)					// Positionates element 20 pixels to the bottom of parent element.'
									   + '\n//	.right(20)					// Positionates element 20 pixels to the right of parent element'
									   + '\n//	.left(200)					// 1 argument'
									   + '\n//	.left(200, 50)				// 2 arguments (or 3)'
									   + '\n//	.left(200, 50, 150, 100)	// 4 arguments (or more)'
									   + '\n//	.left([200])				// 1 array with 1 item'
									   + '\n//	.left([200, 50])			// 1 array with 2 items (or 3)'
									   + '\n//	.left([200, 50, 150, 100])	// 1 array with 4 items (or more)'
// ARRAYS HERE !!!
									   + '\n//	.top(30)					// 1 argument (or more)'
									   + '\n//	.width(220)					// 1 argument'
									   + '\n//	.width(220, 110)			// 2 arguments (or more)'
									   + '\n//	.height(120)				// 1 argument (or more)'
									   + '\n//	.clientwidth(230)			// 1 argument'
									   + '\n//	.clientwidth(230, 130)		// 2 arguments (or more)'
// clientheight not working
									   + '\n//	.clientheight(130)			// 1 argument (or more)'
									   + '\n//	.borderstyle(Bros.bsPanel)'
									   + '\n//	.borderstyle(Bros.bsNone)'
									   + '\n//	.borderstyle([["FF0000", 5], ["0000FF", 10], ["FF0000", 15], ["0000FF", 20], ["0000FF", 25], ["FF0000", 30], ["0000FF", 35], ["FF0000", 40]])'
									   + '\n//	.borderstyle([["FF0000", 10], ["FFFF00"], ["0000FF", 5, "dotted"], ["FF00FF", 30], ["FF00FF", 30], ["0000FF", 30], ["FFFF00", 10], ["0000FF", 10]])'
									   + '\n//	.borderstyle([])'
									   + '\n//	.color(Bros.clBlue)'
									   + '\n//	.color(Bros.clPanel)'
									   + '\n//	.color("FF0000")'
									   + '\n//	.gradient(["left",  "FF0000", "0000FF"])'
									   + '\n//	.gradient(["top",	"FF0000", "0000FF"])'
									   + '\n//	.gradient(["right", "FF0000", "0000FF"])'
									   + '\n//	.gradient(["bottom","FF0000", "0000FF"])'
									   + '\n//	.halign("left")'
									   + '\n//	.halign("center")'
									   + '\n//	.halign("right")'
									   + '\n//	.valign("top")'
									   + '\n//	.valign("middle")'
									   + '\n//	.valign("bottom")'
									   + '\n//	.align("none")		// Leave ONLY one align uncomented'
									   + '\n//	.align("left")'
									   + '\n//	.align("top")'
									   + '\n//	.align("right")'
									   + '\n//	.align("bottom")'
									   + '\n//	.align("client")'
									   + '\n//	.font({"bold":true,"family":"Arial", "size":20})'
//									   + '\n//	.scrollbars()'
//									   + '\n//	.selectable()'
//									   + '\n//	.cssext()'
//									   + '\n//	.cssint()'
									   + '\n//	.movable(true)'
									   + '\n//	.resizable(true)'
									   + '\n//	.visible(false)'
//									   + '\n//	.onclick()'
									   + '\n	.parent()'
									   + '\n;'
									]);

		HelpPages.push				(["Method",		"elementpop"
									,	'.elementpop()'
									,	"This method is used, generally, inside events when you need to access some element."
									   +"<p>Then you call .elementpush(), then .element(YourElement), then do something with it, and, finally, calls .elementpop() to restore previous Bros selected element."
									   +"<p>You need NOT do do this inside Bros events because Bros do it automatically for you."
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"elementpush"
									,	'.elementpush()'
									,	"This method is used, generally, inside events when you need to access some element."
									   +"<p>Then you call .elementpush(), then .element(YourElement), then do something with it, and, finally, calls .elementpop() to restore previous Bros selected element."
									   +"<p>You need NOT do do this inside Bros events because Bros do it automatically for you."
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"expand"
									,	'.expand(Node)'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"expandall"
									,	'.expandall(Node)'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"format"
									,	'.format("table", FORMAT)<br>or .format("row", RowIndex, FORMAT)<br>or .format("col", ColIndex, FORMAT)<br>or .format("cell", RowIndex, ColIndex, FORMAT)'
									,	"FORMAT is an object with Bros properies."
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"getappargs"
									,	'.getappargs()'
									,	"Returns the application arguments saved when provided by ongetappargs on shut-down (power off)."
									   +'<p>'
									,	["Element", "application"]
									]);

		HelpPages.push				(["Method",		"getimageheight"
									,	'.getimageheight()'
									,	"Returns the actual image height when imageheight is -1 (auto size)."
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"getimagewidth"
									,	'.getimagewidth()'
									,	"Returns the actual image width when imagewidth is -1 (auto size)."
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"havescrollbars"
									,	'.havescrollbars("horizontal" | "vertical")'
									,	"Indicates if the element should be showing scrollbar horizontal or vertical by returning true or false."
									   +'<p>In fact scrollbars will appear only if set via .scrollbars(...)'
									   +'<p>So, this method will indicate if the element content overflows its area no matter if the scrollbars are visible or not.'
									,	["Element", "element"]
									]);

		HelpPages.push				(["Method",		"html"
									,	'.html() or .html(Value)'
									,	".html() gets the HTML content of an element (including sub-elements)."
									   +'<p>.html(Value) sets the HTML content of an element (and destroys sub-elements if exists).'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"item"
									,	'.item()'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"lap"
									,	'.lap()'
									,	""
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"laps"
									,	'.laps()'
									,	""
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"maximize"
									,	'.maximize()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"minimize"
									,	'.minimize()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

// XPTPANELELIMINATE
//		HelpPages.push				(["Method",		"panel"
//									,	'.panel(PanelIndex)'
//									,	""
//									   +'<p>'
//									,	["Element", "selectorpanels"]
//									]);

		HelpPages.push				(["Method",		"parent"
									,	'.parent()'
									,	""
									   +'<p>'
									,	["Element", "panel"]
									]);

		HelpPages.push				(["Method",		"parentitem"
									,	'.parentitem()'
									,	""
									   +'<p>'
									,	["Element", "tree"]
									]);

		HelpPages.push				(["Method",		"pause"
									,	'.pause()'
									,	""
									   +'<p>'
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"popup"
									,	'.popup()'
									,	""
									   +'<p>'
									,	["Element", "menu"]
									]);

		HelpPages.push				(["Method",		"print"
									,	'.print()'
									,	"Prints the element whatever it is."
									   +'<p>The only exception is on <b>editarea</b> where the content will be printed instead.'
									   +'<p><b>IMPORTANT:</b> When you call .print() many times you can get a warning message like:'
									   +'<p><i>Prevent this page from creating additional dialogs</i>'
									   +'<p>Be aware to <b>ALLOW</b> the dialog opening because if you don\'t you will need to reboot Bros via F5. If you do not want to print you can press Cancel AFTER print dialog opening.'
									   +'<p>On Firefox,for example, you must press Cancel (if above message appear) to allow dialog opening (!).'
									   +'<p>This is NOT a Bros bug, but is a browser security issue and the message can be different from browser to browser.'
									   +'<p>'
									,	   Help_StartExample_Panel
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("Print Button")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.print		();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("Print Window")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element	(MyWindow).print();'
									   + '\n			})'
									   + '\n	.createelement			("button")'
									   + '\n		.caption			("Print")'
									   + '\n		.onclick			(function (Elem, e)'
									   + '\n			{'
									   + '\n			Bros.element	("MyEditArea").print();'
									   + '\n			})'
									   + '\n	.createelement			("editarea")'
									   + '\n	//	.mode				("codeeditor")'
									   + '\n	//	.mode				("texteditor")'
									   + '\n		.name				("MyEditArea")'
									   + '\n		.width				(330, 100)'
									   + '\n		.resizable			(! false)'
									   + '\n		.value				("This is my editarea content.\\nWhen printed only content will be.\\nAdd more lines here.")'
									   + '\n.parent						()'
									   + '\n;'
									]);

		HelpPages.push				(["Method",		"putontray"
									,	'.putontray()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"refresh"
									,	'.refresh()'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"reload"
									,	'.reload()'
									,	""
									   +'<p>'
									,	["Element", "application"]
									]);

		// removeelement eliminated because it was only used in CMenu.DeletePopupedMenusFromIndex
		//HelpPages.push				(["Method",		"removeelement"
		//							,	'.removeelement()'
		//							,	"DO NOT USE this method because it only exists for Bros internal purposes."
		//							   +'<p>USE .deleteelement() instead.'
		//							,	["Method", "deleteelement"]
		//							]);

		HelpPages.push				(["Method",		"restore"
									,	'.restore()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"resume"
									,	'.resume()'
									,	""
									   +'<p>'
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"right"
									,	'.right(NewValue)'
									,	"Positionates element NewValue pixels to the right of parent element."
									   +'<p>This setting will be loosed if the element is moved somehow.'
									,	["Method", "element"]
									]);

		HelpPages.push				(["Method",		"rotate"
									,	'.rotate(Angle)'
									,	"Angle is in degree."
									   +'<p>'
									,	["Method", "opacity"]
									]);

		HelpPages.push				(["Method",		"selected"
									,	'.selected() or .selected(true | false)'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"setfocus"
									,	'.setfocus()'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"start"
									,	'.start()'
									,	""
									   +'<p>'
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"stop"
									,	'.stop()'
									,	""
									   +'<p>'
									,	["Element", "tmeter"]
									]);

		HelpPages.push				(["Method",		"timeout"
									,	'.timeout()'
									,	""
									   +'<p>'
									,	["Element", "tmeter"]
									]);

		//###########################################################################
		//###########################################################################
		//##
		//## Methods Type Event
		//##
		//###########################################################################
		//###########################################################################

		HelpPages.push				(["Method",		"onbeguin"
									,	'.onbeguin(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"onchange"
									,	'.onchange() or .onchange(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "selector"]
									]);

		HelpPages.push				(["Method",		"onclick"
									,	'.onclick() or .onclick(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "button"]
									]);

		HelpPages.push				(["Method",		"onclose"
									,	'.onclose() or .onclose(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"ondraw"
									,	'.ondraw(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"onend"
									,	'.onend(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"onfocus"
									,	'.onfocus(function (Elem){...})'
									,	""
									   +'<p>'
									,	["Element", "window"]
									]);

		HelpPages.push				(["Method",		"ongetappargs"
									,	'.ongetappargs()'
									,	""
									   +'<p>'
									,	["Element", "application"]
									]);

		HelpPages.push				(["Method",		"onhaveonclick"
									,	'.onhaveonclick(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "calendar"]
									]);

		HelpPages.push				(["Method",		"onkeydown"
									,	'.onhaveonclick(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"onkeypress"
									,	'.onhaveonclick(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"onkeyup"
									,	'.onhaveonclick(function (Elem, Event){...})'
									,	""
									   +'<p>'
									,	["Element", "editarea"]
									]);

		HelpPages.push				(["Method",		"onload"
									,	'.onload(function (Elem, e, Success){...})'
									,	"Fires this event when image is loaded (Success will be trur) (or failed (Success will be false))."
									   +'<p>'
									,	["Element", "image"]
									]);

		HelpPages.push				(["Method",		"onready"
									,	'.onready(function (Elem){...})'
									,	"Fires this event when element is builded."
									   +'<p>This method is used in special cases when you need, for example, store the object element itself instead acessing it by name.'
									,	["Element", "element"]
									]);

		HelpPages.push				(["Method",		"onresize"
									,	'.onresize(function (Elem){...})'
									,	"Fires this event when the element is resized."
									   +'<p>'
									,	["Element", "element"]
									]);

		HelpPages.push				(["Method",		"onselect"
									,	'.onselect() or .onselect(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "table"]
									]);

		HelpPages.push				(["Method",		"ontimer"
									,	'.ontimer() or .ontimer(NewValue)'
									,	""
									   +'<p>'
									,	["Element", "timer"]
									]);

		}

	//===========================================================================
	//===========================================================================
	//==
	//== Aixiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Get Bros Elements
	//---------------------------------------------------------------------------

	function GetBrosElements()
		{
		//	deb						("GetBrosElements");
		var BrosElements			= [];
		BrosElements.MaxLevel		= 0;
		GetBrosElements_Push		(BrosElements, "element", 0);
		return BrosElements;
		}

	//---------------------------------------------------------------------------
	// Get Bros Elements Push
	//---------------------------------------------------------------------------

	function GetBrosElements_Push(BrosElements, ClassName, Level)
		{
		//	deb						("GetBrosElements_Push", ClassName, Level);

		// BrosElements.MaxLevel
		if (BrosElements.MaxLevel	< Level)
			BrosElements.MaxLevel	= Level;

		// Creates
		var BrosElement				= {
			 Index					: BrosElements.length
			,Level					: Level
			,ClassName				: ClassName
			,RegClass				: Bros.RegisteredClasses[ClassName]
			};

		// Pushes
		BrosElements.push			(BrosElement);

		// Search for direct inherited
		var Count					= 1;
		for (var RegClass_Name in Bros.RegisteredClasses)
			{
			var RegClass			= Bros.RegisteredClasses[RegClass_Name];
			//	deb					(Count++, RegClass_Name, RegClass.Inheritance.length, RegClass.Inheritance);
			//	PCS					(RegClass);
			if (RegClass.Inheritance.length == 0)
				continue;
			if (RegClass.Inheritance[RegClass.Inheritance.length - 1] != ClassName)
				continue;
			//	deb					(Count++, RegClass_Name, RegClass.Inheritance.length, RegClass.Inheritance);
			// Reenter
			GetBrosElements_Push	(BrosElements, RegClass_Name, Level + 1);
			}
		}

	//---------------------------------------------------------------------------
	// Get Bros Methods
	//---------------------------------------------------------------------------

	function GetBrosMethods()
		{
		//	deb						("GetBrosMethods");

		// Initialize
		var BrosMethods				= [];

		// Loop
		for (var RegMethod_Name in Bros.RegisteredMethods)
			{
			//	deb					(RegMethod_Name);
			//	var RMethod			= Bros.RegisteredMethods[RegMethod_Name];
			//	PCS					(RMethod);

			// Creates
			var BrosMethod			= {
				 Index				: BrosMethods.length
				,Name				: RegMethod_Name
				,RegMethod			: Bros.RegisteredMethods[RegMethod_Name]
				};

			// Stores
			BrosMethods.push		(BrosMethod);
			}

		// Sort
		Bros.Arr_Sort				(BrosMethods, function (a, b)
			{
			if (a.RegMethod.Type < b.RegMethod.Type)
				return  1;
			if (a.RegMethod.Type > b.RegMethod.Type)
				return -1;
			if (a.RegMethod.Name > b.RegMethod.Name)
				return  1;
			return -1;
			});

		// RebuildIndexes
		Bros.Arr_RebuildIndexes		(BrosMethods);

		// Returns
		return BrosMethods;
		}

	//---------------------------------------------------------------------------
	// Show Result Array
	//---------------------------------------------------------------------------

	function ShowResultArray(Result)
		{
		//	deb						("ShowResultArray", Result.length);
		Bros.RW						("<pre>&nbsp;<p>");
		Bros.RW						(Result.join("<br>"));
		Bros.RW						("<p>&nbsp;</pre>");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Study Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Show Elements Inheritance
	//---------------------------------------------------------------------------

	function ShowElementsInheritance()
		{
		//	deb						("ShowElementsInheritance");
		var BrosElements			= GetBrosElements();
		//	PCS						(BrosElements);
		//	deb						("BrosElements.length = " + BrosElements.length);
		//	PCS						(BrosElements[0], ! false);

		// Build
		var Result					= [];
		for (var i = 0; i < BrosElements.length; i++)
			{
			var BrosElement			= BrosElements[i];
			//	PCS					(BrosElement);
			//	PCS					(BrosElement.RegClass);
			//	deb					(BrosElement.ClassName, BrosElement.RegClass.ValidMethods.length, BrosElement.RegClass.ValidMethods);
			Result.push				((BrosElement.Index + 1) + TabToUse + Bros.Lib.Str.Replicate(TabToUse, BrosElement.Level) + BrosElement.ClassName);
			}

		// Show
		ShowResultArray				(Result);
		}

	//---------------------------------------------------------------------------
	// Show Elements Methods
	//---------------------------------------------------------------------------

	function ShowElementsMethods()
		{
		//	deb						("ShowElementsMethods");

		// GetBrosElements
		var BrosElements			= GetBrosElements();
		//	PCS						(BrosElements);
		//	deb						("BrosElements.length = " + BrosElements.length);

		// GetBrosMethods
		var BrosMethods				= GetBrosMethods();
		//	PCS						(BrosMethods);
		//	deb						("BrosMethods.length = " + BrosMethods.length);

		// Initialize
		var Result					= [];

		// Push Header Elements
		SEM_Push_Header_Elements	(Result, BrosElements);

		// Push Header
		SEM_Push_Header				(Result, BrosElements);

		// Blank Line
		Result.push					("");

		// Build Method Rows
		for (var i = 0; i < BrosMethods.length; i++)
			{
			var BrosMethod			= BrosMethods[i];
			//	PCS					(BrosMethod);
			//	deb					(i, BrosMethod.Index, BrosMethod.RegMethod.Name, BrosMethod.RegMethod.Type);
			SEM_Push_Method			(Result, BrosElements, BrosMethod);
			}

		// Show
		ShowResultArray				(Result);
		}

	//---------------------------------------------------------------------------
	// Show Elements Methods - Push Header Elements
	//---------------------------------------------------------------------------

	function SEM_Push_Header_Elements(Result, BrosElements)
		{
		//	deb						("SEM_Push_Header_Elements");
		for (var i = 0; i <= BrosElements.MaxLevel; i++)
			SEM_Push_Header_Elements_Level(Result, BrosElements, i);
		}

	//---------------------------------------------------------------------------
	// Show Elements Methods - Push Header Elements Level
	//---------------------------------------------------------------------------

	function SEM_Push_Header_Elements_Level(Result, BrosElements, Level)
		{
		//	deb						("SEM_Push_Header_Elements_Level", Level);

		// Build
		var ToPush					= [];
		ToPush.push					("");							//	(BrosMethod.Index + 1);
		//	ToPush.push				("");							//	(BrosMethod.Name);
		//
		ToPush.push					("");							//	(BrosMethod.RegMethod.Name);
		ToPush.push					("");							//	(BrosMethod.RegMethod.ApplyGetSet);
		ToPush.push					("");							//	(BrosMethod.RegMethod.PropName);
		ToPush.push					("");							//	(BrosMethod.RegMethod.Type);
		ToPush.push					("Level " + Level);				//	(BrosMethod.RegMethod.VarType);

		// BrosElements
		for (var i = 0; i < BrosElements.length; i++)
			{
			var BrosElement			= BrosElements[i];
			if (BrosElement.Level == Level)
				ToPush.push			(BrosElement.ClassName);
			else
				ToPush.push			("");
			}

		// Push
		Result.push					(ToPush.join(TabToUse));
		}

	//---------------------------------------------------------------------------
	// Show Elements Methods - Push Header
	//---------------------------------------------------------------------------

	function SEM_Push_Header(Result, BrosElements)
		{
		//	deb						("SEM_Push_Header");

		// Build
		var ToPush					= [];
		ToPush.push					("#");							//	(BrosMethod.Index + 1);
		//	ToPush.push				("Name");						//	(BrosMethod.Name);
		//
		ToPush.push					("Name");						//	(BrosMethod.RegMethod.Name);
		ToPush.push					("ApplyGetSet");				//	(BrosMethod.RegMethod.ApplyGetSet);
		ToPush.push					("PropName");					//	(BrosMethod.RegMethod.PropName);
		ToPush.push					("Type");						//	(BrosMethod.RegMethod.Type);
		ToPush.push					("VarType");					//	(BrosMethod.RegMethod.VarType);

		// BrosElements
		for (var i = 0; i < BrosElements.length; i++)
			{
			var BrosElement			= BrosElements[i];
			ToPush.push				(BrosElement.Index + 1);
			}

		// Push
		Result.push					(ToPush.join(TabToUse));
		}

	//---------------------------------------------------------------------------
	// Show Elements Methods - Push Method
	//---------------------------------------------------------------------------

	function SEM_Push_Method(Result, BrosElements, BrosMethod)
		{
		//	deb						("SEM_Push_Method");
		//	PCS						(BrosMethod);
		//	PCS						(BrosMethod.RegMethod);

		// Build
		var ToPush					= [];
		ToPush.push					(BrosMethod.Index + 1);
		//	ToPush.push				(BrosMethod.Name);
		//
		ToPush.push					(BrosMethod.RegMethod.Name);
		ToPush.push					(BrosMethod.RegMethod.ApplyGetSet ? "! false" : "");
		ToPush.push					(BrosMethod.RegMethod.PropName);
		ToPush.push					(BrosMethod.RegMethod.Type);
		ToPush.push					(BrosMethod.RegMethod.VarType);

		// BrosElements
		for (var i = 0; i < BrosElements.length; i++)
			{
			var BrosElement			= BrosElements[i];
			if (Bros.Arr_Have(BrosElement.RegClass.ValidMethods, BrosMethod.RegMethod.Name))
				ToPush.push			(BrosMethod.RegMethod.Name);
			else
				ToPush.push			("");
			}

		// Push
		Result.push					(ToPush.join(TabToUse));
		}

	//---------------------------------------------------------------------------
	// Analyze HelpPages
	//---------------------------------------------------------------------------

	function AnalyzeHelpPages()
		{
		//	deb						("AnalyzeHelpPages");

		// GetBrosElements
		var BrosElements			= GetBrosElements();
		//	PCS						(BrosElements);
		//	deb						("BrosElements.length = " + BrosElements.length);

		// GetBrosMethods
		var BrosMethods				= GetBrosMethods();
		//	PCS						(BrosMethods);
		//	deb						("BrosMethods.length = " + BrosMethods.length);

		// Loop in HelpPages
		//	deb						("HelpPages.length = " + HelpPages.length);
		var Index_Element			= 0;
		var Index_Method			= 0;
		var Errors_Element			= 0;
		var Errors_Method			= 0;
		var Status;
		for (var i = 0; i < HelpPages.length; i++)
			{
			var HelpPage			= HelpPages[i]
			//	PCS					(HelpPage);						// Arrays
			//	deb					(HelpPage);
			//	deb					(HelpPage[0], HelpPage[1]);
			if (HelpPage[0] == "Element")
				{
				Status				= "OK";
				var Name			= BrosElements[Index_Element] ? BrosElements[Index_Element].ClassName : "UNDEFINED !";
				if (HelpPage[1]    != Name)
					{
					Status			= "ERROR";
					Errors_Element++;
					}
				deb					(Status, "Element",	Index_Element,	HelpPage[1], Name);
				Index_Element++;
				}
			if (HelpPage[0] == "Method")
				{
				Status				= "OK";
				var Name			= BrosMethods[Index_Method] ? BrosMethods[Index_Method].Name : "UNDEFINED !";
				if (HelpPage[1]    != Name)
					{
					Status			= "ERROR";
					Errors_Method++;
					}
				deb					(Status, "Method",	Index_Method,	HelpPage[1], Name);
				Index_Method++;
				}
			}
		// Results
		deb							("------- Result");
		deb							((BrosElements.length == Index_Element	? "OK" : "ERROR"), BrosElements.length, Index_Element, "BrosElements.length, Index_Element");
		deb							((BrosMethods .length == Index_Method	? "OK" : "ERROR"), BrosMethods .length, Index_Method,  "BrosMethods.length,  Index_Method" );
		deb							((Errors_Element      == 0				? "OK" : "ERROR"), "Errors_Element = " + Errors_Element);
		deb							((Errors_Method		  == 0				? "OK" : "ERROR"), "Errors_Method  = " + Errors_Method);
		}

//###########################################################################
//###########################################################################
