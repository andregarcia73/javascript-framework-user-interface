//###########################################################################
//###########################################################################
//##
//## Bros Application - File Manager
//##
//###########################################################################
//###########################################################################

		BrosApp_FileManager_Go		();

//###########################################################################
//###########################################################################
//##
//## File Manager access Methods
//##
//###########################################################################
//###########################################################################

	//---------------------------------------------------------------------------
	// Main Usage
	//---------------------------------------------------------------------------

	function BrosApp_FileManager_Go()
		{
		//	deb						("BrosApp_FileManager_Go");

		// AppParams came ?
		if (Application.AppParams)
			{
			//	PCS					(Application.AppParams);

			// Open ?
			if (Application.AppParams.Mode == "Open")
				{
				BrosApp_FileManager_Open		(Application.AppParams.OnClose);
				return;
				}

			// Save ?
			if (Application.AppParams.Mode == "Save")
				{
				BrosApp_FileManager_SaveAs		(Application.AppParams.OnClose);
				return;
				}

			// Select Folder ?
			if (Application.AppParams.Mode == "SelectFolder")
				{
				BrosApp_FileManager_SelectFolder(Application.AppParams.OnClose);
				return;
				}

			// Can occur if was saved from last sign in
			//	Bros.FatalErrorMNO	("BrosApp_FileManager", "Unknown Mode.", "Mode = " + Application.AppParams.Mode);
			}	// AppParams came !

		// Normal usage
		var MainParams				= {
			 Window_Caption			: Bros.Msg.FMA.Window_Caption
			,Window_Width			: 500
			,Window_Height			: 400
			,OpMode					: ""
			//	,OpMode				: "ExploreBrosFS"
			,Window_IsDialog		:   false
			};
		BrosApp_FileManager			(MainParams);
		}

	//---------------------------------------------------------------------------
	// Open
	//---------------------------------------------------------------------------

	function BrosApp_FileManager_Open(OnClose)
		{
		//	deb						("BrosApp_FileManager_Open");
		var MainParams				= {
			 Window_Caption			: Bros.Msg.FMA.Window_Caption_Open
			,Window_Width			: 500
			,Window_Height			: 400
			,Window_IsDialog		: ! false
			,ButtonOK_Caption		: Bros.Msg.FMA.Window_Caption_Open
			,Hide_MainMenu			: ! false
			,Hide_StatusPanel		: ! false
			};
		BrosApp_FileManager			(MainParams, OnClose);
		}

	//---------------------------------------------------------------------------
	// Save As
	//---------------------------------------------------------------------------

	function BrosApp_FileManager_SaveAs(OnClose)
		{
		//	deb						("BrosApp_FileManager_SaveAs");
		var MainParams				= {
			 Window_Caption			: Bros.Msg.FMA.Window_Caption_SaveAs
			,Window_Width			: 500
			,Window_Height			: 400
			,Window_IsDialog		: ! false
			,ButtonOK_Caption		: Bros.Msg.VRB.Save
			,Hide_MainMenu			: ! false
			,Hide_StatusPanel		: ! false
			};
		BrosApp_FileManager			(MainParams, OnClose);
		}

	//---------------------------------------------------------------------------
	// Select Folder
	//---------------------------------------------------------------------------

	function BrosApp_FileManager_SelectFolder(OnClose)
		{
		//	deb						("BrosApp_FileManager_SelectFolder");
		var MainParams				= {
			 Window_Caption			: Bros.Msg.FMA.Window_Caption_SelDFolder
			,Window_Width			: 500
		//	,Window_Width			: 300
			,Window_Height			: 400
			,Window_IsDialog		: ! false
			,ButtonOK_Caption		: "OK"
			,Hide_MainMenu			: ! false
		//	,Hide_Grid				: ! false
			,Hide_StatusPanel		: ! false
			,OpMode					: ""
			};
		BrosApp_FileManager			(MainParams, OnClose);
		}

//###########################################################################
//###########################################################################
//##
//## File Manager
//##
//###########################################################################
//###########################################################################

function BrosApp_FileManager(MainParams, OnClose)
	{
		//	deb						("BrosApp_FileManager");
		//	PCS						(MainParams);
	//---------------------------------------------------------------------------
	// Globals
	//---------------------------------------------------------------------------

//		var BS_Risk_TB				= [	[]			,	["808080"]	,	[]			,	["FFFFFF"]	,		[]			,	["FFFFFF"]	,	[]			,	["808080"]	];
//		var BS_Risk_B				= [	[]			,	[]			,	[]			,	["FFFFFF"]	,		[]			,	[]			,	[]			,	["808080"]	];

		// Default Images
		var IconClosed_Folder		= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Tre_1_FolderClosed.png";
		var IconOpened_Folder		= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Tre_2_FolderOpened.png";
		//
		var IconClosed_File			= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Tre_3_BookClosed.png";
		var IconOpened_File			= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Tre_4_BookOpened.png";
		//
		var Icon_True				= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Chb_B2_3_Down.gif";
		var Icon_False				= Bros.URL_Path_Img_Bros_OS + Bros.Sysc.ImgSubPath_OS + "Img_Chb_B2_1_Up.gif";

		// Options
		var Show_FilesInTree		=   false;

		// Selected Dir
		var FF						= Bros.FF.GetNewFF();
		FF.WasSelected				=   false;
		var SelectedDir				= "";

		// For internal use
		var LastHandlerTreeOnClick	= {
			 Elem					: null
			,e						: null
			,Node					: null
			};

		// Used in dialogs

		// Click in OK ?
		var ClickedOK				=   false;

		//---------------------------------------------------------------------------
		// Values from PHP
		//	//	$this->IDDM			= 0;						//	INT		(11)	UNSIGNED	NOT NULL
		//	//	$this->ID			= 0;						//	INT		(11)	UNSIGNED	NOT NULL
		//	//	$this->DLTD			= "N";						//	CHAR	(1)					NOT NULL
		//	//	$this->ENBD			= "S";						//	CHAR	(1)					NOT NULL
		//	//	$this->IDPARENT		= 0;						//	INT		(11)	UNSIGNED	NOT NULL
		//	$this->CREATED			= "0000-00-00 00:00:00";	//	DATETIME					NOT NULL
		//	$this->MODIFIED			= "0000-00-00 00:00:00";	//	DATETIME					NOT NULL
		//	$this->ACCESSED			= "0000-00-00 00:00:00";	//	DATETIME					NOT NULL
		//	$this->ISFOLDER			= "S";						//	CHAR	(1)					NOT NULL
		//	$this->ISREADONLY		= "N";						//	CHAR	(1)					NOT NULL
		//	$this->ISHIDDEN			= "N";						//	CHAR	(1)					NOT NULL
		//	$this->ISSYSTEM			= "N";						//	CHAR	(1)					NOT NULL
		//	$this->ISBINARY			= "N";						//	CHAR	(1)					NOT NULL
		//	$this->ISCOMPRESD		= "N";						//	CHAR	(1)					NOT NULL
		//	//	$this->WHOSEE		= "";						//	VARCHAR	(255)				NOT NULL
		//	//	$this->WHOMOD		= "";						//	VARCHAR	(255)				NOT NULL
		//	$this->NAME				= "";						//	VARCHAR	(255)				NOT NULL
		//	$this->EXT				= "";						//	VARCHAR	(255)				NOT NULL
		//	$this->SIZE				= 0;						//	INTEGER	(11)	UNSIGNED	NOT NULL
		//	//	$this->CONTENT		= "";						//	LONGTEXT					NOT NULL
		//---------------------------------------------------------------------------

		var ColumnIndex_Icon		= 0;
		var ColumnIndex_Name		= 1;

		// FileFolder Columns
		var FF_Columns				= [
			 {Visible: ! false,	Name: "ICON",			Caption: "&nbsp;",		Halign: "center"}
			,{Visible: ! false,	Name: "NAME",			Caption: "Name",		Halign: "left"	}
			,{Visible: ! false,	Name: "EXT",			Caption: "Ext",			Halign: "center"}
			,{Visible: ! false,	Name: "SIZE",			Caption: "Size",		Halign: "right"	}
			,{Visible:   false,	Name: "CREATED",		Caption: "Created",		Halign: "center"}
			,{Visible: ! false,	Name: "MODIFIED",		Caption: "Modified",	Halign: "center"}
			,{Visible:   false,	Name: "ACCESSED",		Caption: "Accessed",	Halign: "center"}
			,{Visible:   false,	Name: "ISFOLDER",		Caption: "Isfolder",	Halign: "center"}
			,{Visible:   false,	Name: "ISREADONLY",		Caption: "Isreadonly",	Halign: "center"}
			,{Visible:   false,	Name: "ISHIDDEN",		Caption: "Ishidden",	Halign: "center"}
			,{Visible:   false,	Name: "ISSYSTEM",		Caption: "Issystem",	Halign: "center"}
			,{Visible:   false,	Name: "ISBINARY",		Caption: "Isbinary",	Halign: "center"}
			,{Visible:   false,	Name: "ISCOMPRESD",		Caption: "Iscompresd",	Halign: "center"}
			];

	//---------------------------------------------------------------------------
	// Main Code
	//---------------------------------------------------------------------------

//		// Identify window origin
//		var WindowOrigin			= Bros.GetMainAppWindow(Bros.Cobj);
//		//	deb						(Bros.CElm.WhoAmI(WindowOrigin));
//
//		// Unique name to allow more similar windows to be identified
//		var Window_Name				= "MyWindow_" + Bros.NextElementID++;
//		//	deb						("Window_Name = " + Window_Name);
//
//		Build_Window				();
//		if (! MainParams.Hide_MainMenu)
//			{
//			Build_MainMenu			();
//			Build_SubMenus			();
//			}
//		//
//		Load_FileFolders			("");							// Loads root folders

		// Testing
		//	Bros.FS.TestFileSystem	();
		//	var RootFolder			= Bros.RootFolder.GetNewRootFolder();
		//	deb						("ErrorMsg = " + Bros.RootFolder.Validate(RootFolder));
		//	Menu_MapNewRootFolder	();

		// Identify window origin
		var WindowOrigin			= Bros.GetMainAppWindow(Bros.Cobj);
		//	deb						(Bros.CElm.WhoAmI(WindowOrigin));

		// Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);
		//	PCS						(AppC, ! false);

		// Configure and create
		Config_AppC					();
		Create_Window				();
		//	PCS						(AppC, ! false);

		// Unique name to allow more similar windows to be identified
		var Window_Name				= AppC.Window.Name;
		//	deb						("Window_Name = " + Window_Name);

//		// Process AppArgs
//		var AppArgs					= APPC.getappargs(AppC);
//		//	deb						("AppArgs = " + AppArgs);
//		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
//		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
//		//	AppArgs					= '"B:/Data/AAA.js" "B:/Config.sys" "B:/Config2.sys"';
//		AppArgs_Process				(AppArgs);

		Load_FileFolders			("");							// Loads root folders

	//===========================================================================
	//===========================================================================
	//==
	//== Configuration Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Config AppC
	//---------------------------------------------------------------------------

	function Config_AppC()
		{
		//	deb						("Config_AppC");
		//	PCS						(MainParams);

		// For Testing
		//	AppC.Window.Build		=   false;
		if (MainParams.Hide_MainMenu)
			{
			AppC.MainMenu.Build		=   false;
			AppC.ButtonsPanel.Build	=   false;
			}
		if (MainParams.Hide_StatusPanel)
			AppC.StatusPanel.Build	=   false;

		// Window
		AppC.Window.Caption			= MainParams.Window_Caption;

//		// Method to save params on ShutDown
//		APPC.ongetappargs(AppC, function ()
//			{
//			//	deb					("APPC.ongetappargs");
//			var AppArgs				= "";
//			var IsFirst				= ! false;
//			for (var i = 0; i < EditFiles.length; i++)
//				{
//				var EditFile		= EditFiles[i];
//				//	PCS				(EditFile);
//				// Does not include files that NeedToSaveAs (File New ... wihout saving yet)
//				if (EditFile.NeedToSaveAs)
//					continue;
//				if (! IsFirst)
//					AppArgs		   += " ";
//				IsFirst				=   false;
//				AppArgs			   += "\"" + EditFile.FullFileName + "\"";
//				}
//			return AppArgs;
//			});

		// Define IP (ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_FileManager/";

		// Main Menu
		if (! MainParams.Hide_MainMenu)
			{
			APPC.addmenufolder		(AppC, Bros.Msg.WRD.File);
				APPC.addmenuitem	(AppC, Bros.Msg.VRB.Open,						IP + "Img_0110_M_File_Open.png",			"Ctrl+O",	Menu_File_Open)				.Set("ShowButton", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.PHR.NewFolder,					IP + "Img_0120_M_File_NewFolder.png",		"",			Menu_CreateFolder)			.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.PHR.CopyToFolder,				IP + "Img_0130_M_File_Copy.png",			"",			Menu_Copy)					.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.PHR.MoveToFolder,				IP + "Img_0140_M_File_Move.png",			"",			Menu_Move)					.Set("ShowButton", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.VRB.Rename,						IP + "Img_0150_M_File_Rename.png",			"",			Menu_Rename)				.Set("ShowButton", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.VRB.Delete,						IP + "Img_0160_M_File_Delete.png",			"",			Menu_Delete)				.Set("ShowButton", ! false);
//APPC.addmenuitem	(AppC, Bros.Msg.WRD.Properties,					IP + "Img_0170_M_File_Properties.png",		"",			Menu_File_Open)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
//APPC.addmenuitem	(AppC, Bros.Msg.WRD.Exit,						IP + "Img_0180_M_File_Exit.png",			"",			Menu_File_Open)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.endmenufolder	(AppC);
			APPC.addmenufolder		(AppC, Bros.Msg.WRD.Tools);
				APPC.addmenuitem	(AppC, Bros.Msg.FMA.ExplorePhysically,			IP + "Img_0210_M_Tools_ExplorePhy.png",		"",			Menu_ExploreBrosFS)			.Set("ShowButton",   false);
				APPC.addmenuitem	(AppC, Bros.Msg.FMA.ExploreMapped,				IP + "Img_0220_M_Tools_ExploreMap.png",		"",			Menu_ExploreNormal)			.Set("ShowButton",   false);
				APPC.addmenuitem	(AppC, Bros.Msg.FMA.Menu_MapNewRootFolder,		IP + "Img_0230_M_Tools_MapNewRF.png",		"",			Menu_MapNewRootFolder)		.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.FMA.Menu_EditRootFolder,		IP + "Img_0240_M_Tools_EditRF.png",			"",			Menu_EditRootFolder)		.Set("ShowButton",   false);
				APPC.addmenuitem	(AppC, Bros.Msg.FMA.Menu_DisconnectRootFolder,	IP + "Img_0250_M_Tools_DisconnectRF.png",	"",			Menu_DisconnectRootFolder)	.Set("ShowButton",   false);
//APPC.addmenuitem	(AppC, Bros.Msg.WRD.Options,					IP + "Img_0260_M_Tools_Options.png",		"",			Menu_File_Open)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.endmenufolder	(AppC);
			}

		// StatusPanel.SubPanels
		if (! MainParams.Hide_StatusPanel)
			{
			APPC.addstatuspanel		(AppC, "StatusPanelLeft",		10, "client");
			}

		//	PCS						(AppC, ! false);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Creators Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Window
	//---------------------------------------------------------------------------

	function Create_Window()
		{
		//	deb						("Create_Window");
		if (MainParams.Window_IsDialog)
			Bros.element			(Bros.MainElement);
		APPC.createall				(AppC);
		//	PCS						(AppC, ! false);
		Complement_MainWindow		();
		}

	//---------------------------------------------------------------------------
	// Complement Main Window
	//---------------------------------------------------------------------------

	function Complement_MainWindow()
		{
		//	deb								("Complement_MainWindow");
		//	PCS								(MainParams);

		// Complement Window
		Bros
				.onready					(function (Elem)
					{
					//	deb					("onready");		 // X (Close)	Exp/Norm	Min			ToTray		Help
					if (MainParams.Window_IsDialog)
						{
						Elem.Handler.UpdateButtonsVisibility(Elem, [! false,	  false,	  false,	  false,	  false]);
						Bros.resizable		(false);
						Bros.centralize		();
						}
					})
				.onclose					(function (Elem)
					{
					//	deb					("ClickedOK = "+ ClickedOK, "OnClose = "+ OnClose);

					// Reset FullFileName
					var FullFileName		= "";

					// ClickedOK ?
					if (ClickedOK)
						FullFileName		= GetAddress();

					// Set Focus
					if (WindowOrigin != null)
						Bros.element(WindowOrigin).setfocus();

					// Have Event
					if (! OnClose)
						return;

					// Sends FullFileName
					Bros.RunOnResult		(OnClose, "", FullFileName);
					})
			;

		// Address Panel
		Bros
				.createelement				("panel")
					.height					(25)
					.borderstyle			(MainParams.Hide_MainMenu ? Bros.bsNone : Bros.bsButtonsPanel)
					.align					("top")
					.createelement			("panel")
						.width				(47)
						.borderstyle		(Bros.bsNone)
						.align				("left")
						.createelement		("label")
							.left			(1, 5)
							.caption		(Bros.Msg.WRD.Address)
							.autosize		(! false)
						.parent				()
				//	.createelement			("button")
				//		.align				("right")
				//		.width				(50, 25)
				//		.borderstyle		(Bros.bsNone)
				//		.caption			("=> Go")
				//		.onclick			(function (Elem, e) {
				//			// Put here your event handler script
				//			// alert("onclick");
				//			})
					.createelement			("panel")
						.align				("top")
						.height				(2)
						.borderstyle		(Bros.bsNone)
						.parent				()
				//	.createelement			("select")
					.createelement			("edit")
						.name				("MyAddress")
						.align				("top")
				//		.onchange			(function (Elem) {
				//			// Put here your event handler script
				//			// alert("onchange");
				//			})
				//		.onclick			(function (Elem, e) {
				//			// Put here your event handler script
				//			// alert("onclick");
				//			})
					.parent					()
			;

		// Window_IsDialog ?
		if (MainParams.Window_IsDialog)
			{
			Bros
				.createelement				("panel")
					.height					(35)
					.borderstyle			(Bros.bsNone)
					.align					("bottom")
					.createelement			("button")
						.left				(5, 6, 75, 25)
						.caption			("Cancel")
						.onclick			(function (Elem, e) {
							Bros.element(Window_Name).close();
							})
					.createelement			("button")
						.right				(5, 4, 75, 25)
						.caption			(MainParams.ButtonOK_Caption)
						.onclick			(function (Elem, e) {
							if (! FF_WasSelected())
								return;
							ClickedOK		= ! false;
							Bros.element(Window_Name).close();
							})
					.parent					()
				;
			}

		// Tree
		Bros
				.createelement				("tree")
					.name					("MyTree")
					.align					(MainParams.Hide_Grid ? "client" : "left")
					.width					(Bros.lib.sys.isonmobile() ? 100 : 200)
					.onclick				(function (Elem, e, Node)
						{
						//	deb				("OnClick", Node.caption);
						//	PCS				(Node);
						HandlerTreeOnClick	(Elem, e, Node);
						})
			;

		// Splitter / SpreadSeet
		if (! MainParams.Hide_Grid)
			{
			Bros
				// Splitter
				.createelement				("splitter")
					.align					("left")
					.width					(3)
					.borderstyle			(Bros.bsNone)
			//		.minsize				(25)

				// SpreadSeet
				.createelement				("table")
					.name					("MyGrid")
					.fixedcols				(0)
					.color					("FFFFFF")
					.align					("client")
					.onselect				(function (Elem, e, FromTo)
						{
						//	deb				("OnSelect", FromTo);
						HandlerGridOnSelect	(Elem, e, FromTo);
						})
				;
			}
		Bros
			.parent							()
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Building Methods
	//==
	//===========================================================================
	//===========================================================================

//	//---------------------------------------------------------------------------
//	// Build Window
//	//---------------------------------------------------------------------------
//
//	function Build_Window()
//		{
//		//	deb								("Build_Window");
//
//		// Window_IsDialog ?
//		if (MainParams.Window_IsDialog)
//			Bros.element					(Bros.MainElement);
//
//		// Starts
//		Bros
//			.createelement					("window")
//				.name						(Window_Name)
//				.caption					(MainParams.Window_Caption)
//				.left						(750, 20)
//				.width						(MainParams.Window_Width, MainParams.Window_Height)
//				//	.caption				("Bros File Manager")
//				//	.borderstyle			(Bros.bsWindow)
//				.onready					(function (Elem)
//					{
//					//	deb					("onready");		 // X (Close)	Exp/Norm	Min			ToTray		Help
//					if (MainParams.Window_IsDialog)
//						{
//						Elem.Handler.UpdateButtonsVisibility(Elem, [! false,	  false,	  false,	  false,	  false]);
//						Bros.resizable		(false);
//						Bros.centralize		();
//						}
//					})
//				.onclose					(function (Elem)
//					{
//					//	deb					("ClickedOK = "+ ClickedOK, "OnClose = "+ OnClose);
//
//					// Reset FullFileName
//					var FullFileName		= "";
//
//					// ClickedOK ?
//					if (ClickedOK)
//						FullFileName		= GetAddress();
//
//					// Set Focus
//					if (WindowOrigin != null)
//						Bros.element(WindowOrigin).setfocus();
//
//					// Have Event
//					if (! OnClose)
//						return;
//
//					// Sends FullFileName
//					Bros.RunOnResult		(OnClose, "", FullFileName);
//					})
//			;
//
//		// Main Menu
//		if (! MainParams.Hide_MainMenu)
//			{
//			Bros
//				.createelement				("mainmenu")
//					.name					("MainMenu")
//					.height					(20)
//					.align					("top")
//					//	.color				("FFFF00")
//					.parent					()
//				;
//			}
//
//		// Panel Buttons
//		//Bros
//		//		.createelement				("panel")
//		//			.height					(29)
//		//			.borderstyle			(BS_Risk_TB)
//		//			.align					("top")
//		//			.createelement			("button")
//		//				.left				(0, 0, 25, 25)
//		//				.borderstyle		(Bros.bsButton)
//		//				.caption			("B")
//		//				.onclick			(function (Elem, e) {
//		//					// Put here your event handler script
//		//					// alert("onclick");
//		//					})
//		//			.parent					()
//		//	;
//
//		// Address Panel
//		Bros
//				.createelement				("panel")
//					.height					(25)
//					.borderstyle			(Bros.bsNone)
//					.align					("top")
//					.createelement			("panel")
//						.width				(47)
//						.borderstyle		(Bros.bsNone)
//						.align				("left")
//						.createelement		("label")
//							.left			(1, 5)
//							.caption		("Address")
//							.autosize		(! false)
//						.parent				()
//				//	.createelement			("button")
//				//		.align				("right")
//				//		.width				(50, 25)
//				//		.borderstyle		(Bros.bsNone)
//				//		.caption			("=> Go")
//				//		.onclick			(function (Elem, e) {
//				//			// Put here your event handler script
//				//			// alert("onclick");
//				//			})
//					.createelement			("panel")
//						.align				("top")
//						.height				(2)
//						.borderstyle		(Bros.bsNone)
//						.parent				()
//				//	.createelement			("select")
//					.createelement			("edit")
//						.name				("MyAddress")
//						.align				("top")
//				//		.onchange			(function (Elem) {
//				//			// Put here your event handler script
//				//			// alert("onchange");
//				//			})
//				//		.onclick			(function (Elem, e) {
//				//			// Put here your event handler script
//				//			// alert("onclick");
//				//			})
//					.parent					()
//			;
//
//		// Status Panel
//		if (! MainParams.Hide_StatusPanel)
//			{
//			Bros
//				.createelement				("panel")
//					.height					(19)
//					.borderstyle			(Bros.bsNone)
//					.align					("bottom")
//				//	.createelement			("panel")
//				//		.align				("right")
//				//		.borderstyle		(Bros.bsEdit)
//				//		.halign				("left")
//				//		.valign				("top")
//				//		.selectable			(! false)
//				//		//	.html			("&nbsp;Status Right")
//				//		.parent				()
//					.createelement			("panel")
//						.name				("StatusPanelLeft")
//						.align				("client")
//						.borderstyle		(Bros.bsEdit)
//						.halign				("left")
//						.valign				("top")
//						.selectable			(! false)
//						//	.html			("&nbsp;Status Left")
//						.parent				()
//					.parent					()
//				;
//			}
//
//		// Window_IsDialog ?
//		if (MainParams.Window_IsDialog)
//			{
//			Bros
//				.createelement				("panel")
//					.height					(35)
//					.borderstyle			(Bros.bsNone)
//					.align					("bottom")
//					.createelement			("button")
//						.left				(5, 6, 75, 25)
//						.caption			("Cancel")
//						.onclick			(function (Elem, e) {
//							Bros.element(Window_Name).close();
//							})
//					.createelement			("button")
//						.right				(5, 4, 75, 25)
//						.caption			(MainParams.ButtonOK_Caption)
//						.onclick			(function (Elem, e) {
//							if (! FF_WasSelected())
//								return;
//							ClickedOK		= ! false;
//							Bros.element(Window_Name).close();
//							})
//					.parent					()
//				;
//			}
//
//		// Tree
//		Bros
//				.createelement				("tree")
//					.name					("MyTree")
//					.align					(MainParams.Hide_Grid ? "client" : "left")
//					.width					(200)
//					.onclick				(function (Elem, e, Node)
//						{
//						//	deb				("OnClick", Node.caption);
//						//	PCS				(Node);
//						HandlerTreeOnClick	(Elem, e, Node);
//						})
//			;
//
//		// Splitter / SpreadSeet
//		if (! MainParams.Hide_Grid)
//			{
//			Bros
//				// Splitter
//				.createelement				("splitter")
//					.align					("left")
//					.width					(3)
//					.borderstyle			(Bros.bsNone)
//			//		.minsize				(25)
//
//				// SpreadSeet
//				.createelement				("table")
//					.name					("MyGrid")
//					.fixedcols				(0)
//					.color					("FFFFFF")
//					.align					("client")
//					.onselect				(function (Elem, e, FromTo)
//						{
//						//	deb				("OnSelect", FromTo);
//						HandlerGridOnSelect	(Elem, e, FromTo);
//						})
//				;
//			}
//		Bros
//			.parent							()
//			;
//		}
//
//	//---------------------------------------------------------------------------
//	// Build MainMenu
//	//---------------------------------------------------------------------------
//
//	function Build_MainMenu()
//		{
//		//	deb						("Build_MainMenu");
//		Bros
//			.element				("MainMenu")
//				.additem			("File",									"",		"",			"MainMenu_File")
//				.additem			("Tools",									"",		"",			"MainMenu_Tools")
//			;
//		}
//
//	//---------------------------------------------------------------------------
//	// Build SubMenus
//	//---------------------------------------------------------------------------
//
//	function Build_SubMenus()
//		{
//		//	deb						("Build_SubMenus");
//
//		// MainMenu->File
//		Bros
//			.createelement			("menu")
//				.name				("MainMenu_File")
//				.additem			("Open",									" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Open");
//					Menu_File_Open	();
//					})
//				.additem			("-")
//				.additem			("new Folder",								" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->NewFolder");
//					Menu_CreateFolder();
//					})
//				.additem			("-")
//				.additem			("Rename",									" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Rename");
//					Menu_Rename		();
//					})
//				.additem			("Copy to folder...",						" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Copy");
//					Menu_Copy		();
//					})
//				.additem			("Move to folder...",						" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Move");
//					Menu_Move		();
//					})
//				.additem			("Delete",									" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Delete");
//					Menu_Delete		();
//					})
//				.additem			("-")
//				.additem			("Properties",								" ",	"",			function (Elem, e)
//					{
//					deb				("MainMenu->File->Properties");
//					})
//				.additem			("-")
//				.additem			("Exit",									" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->Exit");
//					Bros.element(Window_Name).close();
//					})
//			;
//
//		// MainMenu->Tools
//		Bros
//			.createelement			("menu")
//				.name				("MainMenu_Tools")
//			;
//		//if (! false)				// Main User ?
//		//	{
//			Bros
//				.additem			("Explore Physically",						" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->Tools->ExploreBrosFS");
//					Menu_ExploreBrosFS();
//					})
//				.additem			("Explore Mapped",							" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->Tools->ExploreNormal");
//					Menu_ExploreNormal();
//					})
//				.additem			("-")
//				;
//		//	}
//		Bros
//				.additem			(Bros.Msg.FMA.Menu_MapNewRootFolder,		" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->NewRootFolder");
//					Menu_MapNewRootFolder();
//					})
//				.additem			(Bros.Msg.FMA.Menu_EditRootFolder,			" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->EditRootFolder");
//					Menu_EditRootFolder();
//					})
//				.additem			(Bros.Msg.FMA.Menu_DisconnectRootFolder,	" ",	"",			function (Elem, e)
//					{
//					//	deb			("MainMenu->File->DisconnectRootFolder");
//					Menu_DisconnectRootFolder();
//					})
//				.additem			("-")
//				.additem			("Options",									" ",	"",			function (Elem, e)
//					{
//					deb				("MainMenu->Tools->Options");
//					})
//			;
//		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// ShowMsg
	//---------------------------------------------------------------------------

	function ShowMsg(PanelName, Msg)
		{
		//	deb						("ShowMsg", PanelName, Msg);
		//	deb						("ShowMsg", "MainParams.Hide_StatusPanel = " + MainParams.Hide_StatusPanel);
		if (MainParams.Hide_StatusPanel)
			return;
		Bros.element				(PanelName).html("&nbsp;" + Bros.Str_ReplaceBRCRLF(Msg));
		}

	//---------------------------------------------------------------------------
	// ShowError
	//---------------------------------------------------------------------------

	function ShowError(ErrorMsg)
		{
		//	deb						("ShowError", ErrorMsg);
		// Builded ?
		if (! AppC.StatusPanel.Build)
			return;

		ShowMsg						("StatusPanelLeft", "<font color='FF0000'>" + ErrorMsg + "</font>");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Processing Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Load Folders from a StartFolder (FullFileName)
	//---------------------------------------------------------------------------

	function Load_FileFolders(FullFileName, Elem, Node)
		{
		//	deb						("Load_FileFolders", FullFileName, MainParams.OpMode);
		//	FullFileName			= "B:/Dados\\Teste";
		//	FullFileName			= "B:/Dados/Teste";
		//	FullFileName			= "B:";

		// ExploreBrosFS ?
		if (MainParams.OpMode == "ExploreBrosFS")
			{
			Load_FileFolders_BrosFS	(FullFileName, Elem, Node);
			return;
			}

		// Mapped
		var InludeFiles				= ! false;
		var InludeFolders			= ! false;
		Bros.FS.GetFileFolders		(FullFileName, InludeFiles, InludeFolders, function (ErrorMsg, FileFolders)
			{
			//	deb					("Load_FileFolders.GetFileFolders");
			//	deb					("Load_FileFolders.GetFileFolders", "ErrorMsg = " + ErrorMsg);
			if (ErrorMsg != "")
				{
				ShowError			(ErrorMsg);
				return;
				}
			ShowError				("");							// To Clear old errors
			//	deb					("Load_FileFolders.GetFileFolders", Bros.VarIsArray(FileFolders), typeof(FileFolders), "FileFolders = " + FileFolders, FileFolders.length);
			//	deb					("FileFolders.length = " + FileFolders.length);
			//	for (var i = 0; i < FileFolders.length; i++)
			//		{
			//		//	deb			(i, typeof(FileFolders[i]), FileFolders[i]);
			//		//	PCS			(FileFolders[i]);
			//		deb				(i, FileFolders[i].ISFOLDER, FileFolders[i].NAME, FileFolders[i].EXT, FileFolders[i].SIZE);
			//		}
			Sort_FileFolders		(FileFolders);
			Update_Tree				(FileFolders);
			Update_Grid				(FileFolders);

			// Expand ?
			if (Elem && Node)
				{
				Bros.element		(Elem).expand(Node);
				}

			// Set FF again because Load_FileFolders is firing HandlerGridOnSelect (don't know why)
			if (FullFileName != "")
				{
				var ISFOLDER		= ! false;
				Set_FF				(ISFOLDER, FullFileName);
				}
			});
		}

	//---------------------------------------------------------------------------
	// Load BrosFS File Folders
	//---------------------------------------------------------------------------

	function Load_FileFolders_BrosFS(FullFileName, Elem, Node)
		{
		//	deb						("Load_FileFolders_BrosFS", FullFileName);
		//	FullFileName			= "W:/cc/ff";
		//	FullFileName			= "B:";

		// Temporary RootFolder
		var RootFolder				= Bros.RootFolder.GetNewRootFolder();
		RootFolder.Name				= "";
		RootFolder.FolderMap		= "";
		RootFolder.Driver			= Bros.FS.Driver_BrosFS;

		// Builds a FF
		var FF						= Bros.FF.GetNewFF();
		FF.FullFileName				= FullFileName;
		var SkipRootFolderError		= ! false;
		if (FullFileName != "")
			{
			if (Bros.DidShowError(Bros.FF.Decode_FullFileName(FF, SkipRootFolderError)))
				return;
			}
		FF.RootFolder				= RootFolder;			// AFTER DECODE
		//	PCS						(FF);
		//	deb						("Bros.FF.Get_FullFileName_BrosFS(FF) = " + Bros.FF.Get_FullFileName_BrosFS(FF));

		// GetFileFolders directly from Driver
		var InludeFiles				= ! false;
		var InludeFolders			= ! false;
		Bros.FS.Driver_BrosFS.GetFileFolders(FF, InludeFiles, InludeFolders, function (ErrorMsg, FileFolders)
			{
			//	deb					("Load_FileFolders_BrosFS.GetFileFolders");
			//	deb					("Load_FileFolders_BrosFS.GetFileFolders", "ErrorMsg = " + ErrorMsg);
			//	if (Bros.DidShowError(ErrorMsg))
			//		return;
			if (ErrorMsg != "")
				{
				ShowError			(ErrorMsg);
				return;
				}
			ShowError				("");							// To Clear old errors
			//	deb					("Load_FileFolders_BrosFS.GetFileFolders", Bros.VarIsArray(FileFolders), typeof(FileFolders), "FileFolders = " + FileFolders, FileFolders.length);
			//	deb					("FileFolders.length = " + FileFolders.length);
			//	for (var i = 0; i < FileFolders.length; i++)
			//		{
			//		var FileFolder	= FileFolders[i];
			//		//	deb			(i, typeof(FileFolder), FileFolder);
			//		//	deb			(i, FileFolder.ISFOLDER, FileFolder.NAME, FileFolder.EXT, FileFolder.SIZE);
			//		//	PCS			(FileFolder);
			//		}
			Sort_FileFolders		(FileFolders);
			Update_Tree				(FileFolders);
			Update_Grid				(FileFolders);

			// Expand ?
			if (Elem && Node)
				{
				Bros.element		(Elem).expand(Node);
				}

			// Set FF again because Load_FileFolders_BrosFS is firing HandlerGridOnSelect (don't know why)
			if (FullFileName != "")
				{
				var ISFOLDER		= ! false;
				Set_FF				(ISFOLDER, FullFileName);
				}
			});
		}

	//---------------------------------------------------------------------------
	// Sort FileFolders
	//---------------------------------------------------------------------------

	function Sort_FileFolders(FileFolders)
		{
		//	deb						("Sort_FileFolders", FileFolders.length);
		Bros.Arr_Sort				(FileFolders, function (a, b)
			{
			//	deb					(a.NAME, b.NAME);
// XPTFSDIRECT
if (a.NAME == null) return -1;
if (b.NAME == null) return -1;
			if ((! a.ISFOLDER) && b.ISFOLDER)
				return  1;
			if (a.ISFOLDER && (! b.ISFOLDER))
				return -1;
			if (a.NAME.toLowerCase() > b.NAME.toLowerCase())
				return  1;
			return -1;
			});
		}

	//---------------------------------------------------------------------------
	// Update Tree
	//---------------------------------------------------------------------------

	function Update_Tree(FileFolders)
		{
		//	deb						("Update_Tree", FileFolders.length);
		Bros.element				("MyTree");
		for (var i = 0; i < FileFolders.length; i++)
			{
			var FileFolder			= FileFolders[i];
			//	deb					(i, FileFolder.ISFOLDER, FileFolder.NAME);
			if (FileFolder.ISFOLDER)
				{
				var ToShow			= FileFolder.NAME;
				//if (MainParams.OpMode == "ExploreBrosFS")
				//	ToShow		   += " (ID = " + FileFolder.ID + ")";
				Bros.additem		(ToShow, IconClosed_Folder, IconOpened_Folder);
			//	Bros.parentitem		();
				}
			else
				{
				if (Show_FilesInTree)
					{
					Bros.additem	(FileFolder.NAME, IconClosed_File,	 IconOpened_File);
				//	Bros.parentitem	();
					}
				}
			}
		}

	//---------------------------------------------------------------------------
	// Update Grid
	//---------------------------------------------------------------------------

	function Update_Grid(FileFolders)
		{
		//	deb						("Update_Grid", FileFolders.length, "MainParams.Hide_Grid = " + MainParams.Hide_Grid);

		if (MainParams.Hide_Grid)
			return;

		Bros.element				("MyGrid");
		Bros.rowcount				(0);

		// Build Headers
		var Col						= -1;
	//	Bros.editable				(! false);
		for (var i = 0; i < FF_Columns.length; i++)
			{
			var Column				= FF_Columns[i];
			//	PCS					(Column);
			if (! Column.Visible)
				continue;
			Col++;
			Bros.value				(-1, Col, Column.Caption);
			//	deb					(Column.Name, Column.Halign);
			//	Bros.format			("col", Col, {halign:Column.Halign});
			Bros.format				("col", Col, {halign:Column.Halign, font:{size:Bros.ApplyZoom(11)}});
	//		Bros.format				("col", Col, {editable:(Column.Name == "NAME")});
			}

		// Update
		for (var i = 0; i < FileFolders.length; i++)
			Update_Grid_FileFolder	(i, FileFolders[i]);
		}

	//---------------------------------------------------------------------------
	// Update Grid FileFolder
	//---------------------------------------------------------------------------

	function Update_Grid_FileFolder(Row, FileFolder)
		{
		//	deb						("Update_Grid_FileFolder", Row, FileFolder, FF_Columns.length);
		//	PCS						(FileFolder);
		var Col						= -1;
		for (var i = 0; i < FF_Columns.length; i++)
			{
			var Column				= FF_Columns[i];
			//	PCS					(Column);
			if (! Column.Visible)
				continue;
			Col++;
			var ToShow				= FileFolder[Column.Name];
			switch (Column.Name)
				{
				case "ICON":
					var ImageSrc	= IconClosed_File;
					if (FileFolder.ISFOLDER)
						ImageSrc	= IconClosed_Folder;
					ToShow			= GetImageIcon(ImageSrc);
					break;
		//		case "NAME":
		//			break;
		//		case "EXT":
		//			break;
				case "SIZE":
					if (FileFolder.ISFOLDER)
						ToShow		= "";
					else
						ToShow		= Bros.Int_ToStr(FileFolder[Column.Name], 0, Bros.User.Pref.ThousandSeparator);
					//if (MainParams.OpMode == "ExploreBrosFS")
					//	ToShow	   += " (ID = " + FileFolder.ID + ")";
					break;
		//		case "CREATED":
				case "MODIFIED":
		//		case "ACCESSED":
					if (FileFolder.ISFOLDER)
						ToShow		= "";
					else
						{
					// XPTUTCDATE_VERIFY
					// XPTUTCDATE
					//	ToShow		= Bros.Lib.Date.ToStr (FileFolder[Column.Name], Bros.User.Pref.DateTimeFormat);
					// XPTUTCDATE
						ToShow		= Bros.Lib.UDate.ToStr(FileFolder[Column.Name], Bros.User.Pref.DateTimeFormat);
						}
					break;
				case "ISFOLDER":
				case "ISREADONLY":
				case "ISHIDDEN":
				case "ISSYSTEM":
				case "ISBINARY":
				case "ISCOMPRESD":
					var ImageSrc	= Icon_False;
					if (FileFolder[Column.Name])
						ImageSrc	= Icon_True;
					//	ToShow		= "<img src='" + ImageSrc + "'>";
					ToShow			= GetImageIcon(ImageSrc);
					break;
				}
			Bros.value				(Row, Col, ToShow);
			}
		}

	//---------------------------------------------------------------------------
	// Get Image Icon
	//---------------------------------------------------------------------------

	function GetImageIcon(ImageSrc)
		{
		//	deb						("GetImageIcon", ImageSrc);
		//	return "<img src='" + ImageSrc + "'>";
		return "<img src='" + ImageSrc + "' width=" + Bros.ApplyZoom(16) + ">";
		}

	//---------------------------------------------------------------------------
	// GetAddress
	//---------------------------------------------------------------------------

	function GetAddress()
		{
		//	deb						("GetAddress");
		return Bros.element("MyAddress").text();
		}

	//---------------------------------------------------------------------------
	// SetAddress
	//---------------------------------------------------------------------------

	function SetAddress()
		{
		//	deb						("SetAddress");
		//	PCS						(MainParams);
		//	PCS						(FF);
		var ToShow					= FF.FullFileName;
		//	deb						("SetAddress", "IsDialog = "+ MainParams.Window_IsDialog, "ISFOLDER = " + FF.ISFOLDER, "Window_Caption = " + MainParams.Window_Caption);
		if (MainParams.Window_IsDialog && FF.ISFOLDER && (MainParams.Window_Caption == Bros.Msg.FMA.Window_Caption_SaveAs))
			ToShow				   += "/YourFileName.txt";
		Bros.element				("MyAddress")
		//	.additem				(ToShow)
			.text					(ToShow);
		}

	//---------------------------------------------------------------------------
	// Set FF
	//---------------------------------------------------------------------------

	function Set_FF(ISFOLDER, FullFileName)
		{
		//	deb						("Set_FF", ISFOLDER, FullFileName);
		FF.ISFOLDER					= ISFOLDER;
		FF.FullFileName				= FullFileName;
		FF.WasSelected				= ! false;
		//	PCS						(FF);
		//	deb						("Set_FF", "ISFOLDER = " + ISFOLDER, "FullFileName = " + FullFileName);

		// Sets Current Address
		SetAddress					();
		}

	//---------------------------------------------------------------------------
	// Handler Tree OnClick
	//---------------------------------------------------------------------------

	function HandlerTreeOnClick(Elem, e, Node)
		{
		//	deb						("HandlerTreeOnClick", Elem, e, Node.Caption);

		// Stores
		LastHandlerTreeOnClick.Elem	= Elem;
		LastHandlerTreeOnClick.e	= e;
		LastHandlerTreeOnClick.Node	= Node;

		// Build FullFileName
		var FullFileName			= "";
		var Item					= Node;
		var FirstLoop				= ! false;
		while (Item != null)
			{
			if (! FirstLoop)
				FullFileName		= "/" + FullFileName;
			FirstLoop				=   false;
			FullFileName			= Item.Caption + FullFileName;
			// Instead below I did above because during the debug I made a fodler with no name. So when expanding if it behave like circular reference. SOLVED !
			//	FullFileName		= Item.Caption + (FullFileName == "" ? "" : "/") + FullFileName;
			Item					= Item.ParentItem;
			}
		//	deb						("FullFileName = " + FullFileName);

		// Set FF
		var ISFOLDER				= ! false;
		Set_FF						(ISFOLDER, FullFileName);

		// Stores in Selected Dir
		SelectedDir					= FullFileName;
		//	deb						("SelectedDir = " + SelectedDir);

		// Delete Children nodes
		Bros.element				(Elem).deletechildren(Node);

		// Load (or Re-Load)
		Load_FileFolders			(FullFileName, Elem, Node);

		// Set FF again because Load_FileFolders is firing HandlerGridOnSelect (don't know why)
		// DON't work here because Load_FileFolders calls GetFileFolders and only on result will be fired
		//	Set_FF					(ISFOLDER, FullFileName);
		}

	//---------------------------------------------------------------------------
	// Handler Grid OnSelect
	//---------------------------------------------------------------------------

	function HandlerGridOnSelect(Elem, e, FromTo)
		{
		//	deb						("HandlerGridOnSelect", Elem, e, FromTo);

		// Get's Name
		var NAME					= Bros.element("MyGrid").value(FromTo[0][0], ColumnIndex_Name);
		//	deb						("HandlerGridOnSelect, NAME = " + NAME);
		var FullFileName			= SelectedDir + (SelectedDir == "" ? "" : "/") + NAME;

		// Get's Icon
		var ImageIcon				= Bros.element("MyGrid").value(FromTo[0][0], ColumnIndex_Icon);
		//	deb						("HandlerGridOnSelect", ImageIcon == GetImageIcon(IconClosed_Folder), "ImageIcon = " + ImageIcon);

		// Set FF
		var ISFOLDER				= ImageIcon == GetImageIcon(IconClosed_Folder);
		Set_FF						(ISFOLDER, FullFileName);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== User Interfaced Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Rename by User
	//---------------------------------------------------------------------------

	function User_CreateFolder(FF, OnResult)
		{
		//	deb						("Bros.FF.User_CreateFolder");
		//	PCS						(FF);
		//	return;

		// Decode FullFileName
		//	FF.FullFileName		   += "?";
		if (Bros.RunOnResultError	(OnResult, Bros.FF.Decode_FullFileName(FF)))
			return;
		//	PCS						(FF);

		// Ask User
		var Params					= Bros.ShowDialog_GetBasicParams();
		Params.Window_Caption		= Bros.Msg.FMA.CreateFolder;
		Params.Window_ImageSrc		= Bros.URL_Path_Img_Bros_Sys + "Img_Dlg_4_Confirmation" + "_Old.png";
		Params.Label_Caption		= Bros.Msg.FMA.CreateFolder_Under + "<p><b>" + FF.FullFileName + "</b>";
		Params.Edit_Text			= "New Folder";
		Params.Buttons				= [Bros.Msg.WRD.No, Bros.Msg.WRD.Yes];
		Bros.ShowDialog				(Params, function (Result)
			{
			//	PCS					(Result);
			if (Result.ButtonIndex != 1)
				return;
			// Need NOT to test if Result.Edit_Text is blank because Bros.FS.Rename will decode and will Decode_FullFileName and will raises an error (Ex. B:/Data/ is invalid)
			Bros.FS.CreateFolder	(FF.FullFileName + "/" + Result.Edit_Text, OnResult);
			});

		};

	//---------------------------------------------------------------------------
	// Rename by User
	//---------------------------------------------------------------------------

	function User_Rename(FF, OnResult)
		{
		//	deb						("Bros.FF.User_Rename");
		//	PCS						(FF);

		// Specifies some Root
		if (Bros.FF.SpecifiesSomeRoot(FF))
			{
			Bros.RunOnResult		(OnResult, Bros.FF.GetMsgInvalidFullFileName(FF, Bros.Msg.FSY.CannotRenameRoots));
			return;
			}

		// Decode FullFileName
		//	if (Bros.DidShowError(Bros.FF.Decode_FullFileName(FF), OnResult))
		//		return;
		var ErrorMsg				= Bros.FF.Decode_FullFileName(FF);
		if (Bros.RunOnResultError	(OnResult, ErrorMsg))
			return;

		// Ask User
		var Params					= Bros.ShowDialog_GetBasicParams();
		Params.Window_Caption		= Bros.Msg.FMA.Rename + " " + (FF.ISFOLDER ? Bros.Msg.FMA.Folder : Bros.Msg.FMA.File);
		//	Params.Window_ImageSrc	= Bros.URL_Path_Img_Bros_Sys + "Img_Dlg_2_Warning" + "_Old.png";
		Params.Window_ImageSrc		= Bros.URL_Path_Img_Bros_Sys + "Img_Dlg_4_Confirmation" + "_Old.png";
		Params.Label_Caption		= Bros.Msg.FMA.From + ":<p>" + FF.FullFileName + "<p>" + Bros.Msg.FMA.To + ":";
		Params.Edit_Text			= FF.NAME;
		Params.Buttons				= [Bros.Msg.WRD.No, Bros.Msg.WRD.Yes];
		Bros.ShowDialog				(Params, function (Result)
			{
			//	PCS					(Result);
			if (Result.ButtonIndex != 1)
				return;
			// Need NOT to test if Result.Edit_Text is blank because Bros.FS.Rename will decode and will Decode_FullFileName and will raises an error (Ex. B:/Data/ is invalid)
			Bros.FS.Rename			(FF.FullFileName, Result.Edit_Text, OnResult);
			});

		};

	//---------------------------------------------------------------------------
	// Delete by User
	//---------------------------------------------------------------------------

	function User_Delete(FF, OnResult)
		{
		//	deb						("Bros.FF.User_Delete");
		//	PCS						(FF);
		//	return;

		// Specifies some Root
		if (Bros.FF.SpecifiesSomeRoot(FF))
			{
			Bros.RunOnResult		(OnResult, Bros.FF.GetMsgInvalidFullFileName(FF, Bros.Msg.FSY.CannotDeleteRoots));
			return;
			}

		// Decode FullFileName
		//	FF.FullFileName		   += "?";
		if (Bros.RunOnResultError	(OnResult, Bros.FF.Decode_FullFileName(FF)))
			return;
		//	PCS						(FF);

		// Ask User
		var Params					= Bros.ShowDialog_GetBasicParams();
		Params.Window_Caption		= Bros.Msg.FMA.Delete + " " + (FF.ISFOLDER ? Bros.Msg.FMA.Folder : Bros.Msg.FMA.File);
		Params.Window_ImageSrc		= Bros.URL_Path_Img_Bros_Sys + "Img_Dlg_4_Confirmation" + "_Old.png";
		Params.Label_Caption		= "<b>" + FF.FullFileName + "</b>";
		Params.Buttons				= [Bros.Msg.WRD.No, Bros.Msg.WRD.Yes];
		Bros.ShowDialog				(Params, function (Result)
			{
			//	PCS					(Result);
			if (Result.ButtonIndex != 1)
				return;
			// Need NOT to test if Result.Edit_Text
			Bros.FS.Delete			(FF.FullFileName, OnResult);
			});

		};

	//---------------------------------------------------------------------------
	// Copy by User
	//---------------------------------------------------------------------------

	function User_Copy(FF, OnResult)
		{
		//	deb						("Bros.FF.User_Copy");
		//	PCS						(FF);
		//	return;

		// Specifies some Root
		if (Bros.FF.SpecifiesSomeRoot(FF))
			{
			Bros.RunOnResult		(OnResult, Bros.FF.GetMsgInvalidFullFileName(FF, Bros.Msg.FSY.CannotCopyFolders));
			return;
			}

		// Decode FullFileName
		//	FF.FullFileName		   += "?";
		if (Bros.RunOnResultError	(OnResult, Bros.FF.Decode_FullFileName(FF)))
			return;
		//	PCS						(FF);

		// Select Destination Folder
		BrosApp_FileManager_SelectFolder(function (ErrorMsg, FullFileName)
			{
			//	deb					("BrosApp_FileManager_SelectFolder", ErrorMsg, FullFileName);
			// Cancel or [X] ?
			if (FullFileName == "")
				return;
			//	deb					("Copying", FF.FullFileName, FullFileName);
			Bros.FS.Copy			(FF.FullFileName, FullFileName, OnResult);
			});
		};

	//---------------------------------------------------------------------------
	// Move by User
	//---------------------------------------------------------------------------

	function User_Move(FF, OnResult)
		{
		//	deb						("Bros.FF.User_Move");
		//	PCS						(FF);
		//	return;

		// Specifies some Root
		if (Bros.FF.SpecifiesSomeRoot(FF))
			{
			Bros.RunOnResult		(OnResult, Bros.FF.GetMsgInvalidFullFileName(FF, Bros.Msg.FMA.CannotMoveRoots));
			return;
			}

		// Decode FullFileName
		//	FF.FullFileName		   += "?";
		if (Bros.RunOnResultError	(OnResult, Bros.FF.Decode_FullFileName(FF)))
			return;
		//	PCS						(FF);

		// Select Destination Folder
		BrosApp_FileManager_SelectFolder(function (ErrorMsg, FullFileName)
			{
			//	deb					("BrosApp_FileManager_SelectFolder", ErrorMsg, FullFileName);
			// Cancel or [X] ?
			if (FullFileName == "")
				return;
			//	deb					("Moving", FF.FullFileName, FullFileName);
			Bros.FS.Move			(FF.FullFileName, FullFileName, OnResult);
			});
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Menu Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// FF_WasSelected ?
	//---------------------------------------------------------------------------

	function FF_WasSelected()
		{
		//	deb						("FF_WasSelected");
		if (FF.WasSelected)
			return ! false;
		Bros.ShowError				(Bros.Msg.FMA.SelectFileFolder);
		return   false;
		}

	//---------------------------------------------------------------------------
	// FF_ISFOLDER ?
	//---------------------------------------------------------------------------

	function FF_ISFOLDER()
		{
		//	deb						("FF_ISFOLDER");
		if (FF.ISFOLDER)
			return ! false;
		Bros.ShowError				(Bros.Msg.FMA.SelectFolder);
		return   false;
		}

	//---------------------------------------------------------------------------
	// FF_IsRootFolder ?
	//---------------------------------------------------------------------------

	function FF_IsRootFolder()
		{
		//	deb						("FF_IsRootFolder");
		//	PCS						(FF);
		// Not working
		//if (FF.IsRootFolder)
		//	return ! false;
		// Workarround
		if (FF.FullFileName.substr(FF.FullFileName.length - 1, 1) == ":")
			return ! false;
		Bros.ShowError				(Bros.Msg.FMA.SelectRootFolder);
		return   false;
		}

	//---------------------------------------------------------------------------
	// FF_ISFILE ?
	//---------------------------------------------------------------------------

	function FF_ISFILE()
		{
		//	deb						("FF_ISFILE");
		if (! FF.ISFOLDER)
			return ! false;
		Bros.ShowError				(Bros.Msg.FMA.SelectFile);
		return   false;
		}

	//---------------------------------------------------------------------------
	// Process OnResult ErrorMsg
	//---------------------------------------------------------------------------

	function ProcessOnResultErrorMsg(ErrorMsg)
		{
		//	deb						("ProcessOnResultErrorMsg", ErrorMsg);
		if (Bros.DidShowError(ErrorMsg))
			return ! false;

		// Re-expands (works only if rename File)
		if (LastHandlerTreeOnClick.Elem != null)
			HandlerTreeOnClick		(LastHandlerTreeOnClick.Elem, LastHandlerTreeOnClick.e, LastHandlerTreeOnClick.Node);

		// OK !
		return   false;
		}

	//---------------------------------------------------------------------------
	// Menu_CreateFolder
	//---------------------------------------------------------------------------

	function Menu_CreateFolder()
		{
		//	deb						("Menu_CreateFolder");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// FF_ISFOLDER ?
		if (! FF_ISFOLDER())
			return;

		// User CreateFolder
		User_CreateFolder			(FF, function (ErrorMsg)
			{
			ProcessOnResultErrorMsg	(ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Rename
	//---------------------------------------------------------------------------

	function Menu_Rename()
		{
		//	deb						("Menu_Rename");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// User Rename
		User_Rename					(FF, function (ErrorMsg)
			{
			ProcessOnResultErrorMsg	(ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Delete
	//---------------------------------------------------------------------------

	function Menu_Delete()
		{
		//	deb						("Menu_Delete");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// User Delete
		User_Delete					(FF, function (ErrorMsg)
			{
			ProcessOnResultErrorMsg	(ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Copy
	//---------------------------------------------------------------------------

	function Menu_Copy()
		{
		//	deb						("Menu_Copy");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// User Copy
		User_Copy					(FF, function (ErrorMsg)
			{
			ProcessOnResultErrorMsg	(ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_Move
	//---------------------------------------------------------------------------

	function Menu_Move()
		{
		//	deb						("Menu_Move");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// User Move
		User_Move					(FF, function (ErrorMsg)
			{
			ProcessOnResultErrorMsg	(ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_File_Open
	//---------------------------------------------------------------------------

	function Menu_File_Open()
		{
		//	deb						("Menu_File_Open");
		//	PCS						(FF);

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// FF_ISFILE ?
		if (! FF_ISFILE())
			return;

		// Runs Application Editor
		var AppNames				= Bros.FS.GetAppNamesToOpen(FF.FullFileName);
		//	deb						("AppNames = " + AppNames.length);
		if (AppNames.length == 0)
			{
			Bros.lib.dlg.showconfirm(Bros.Msg.FMA.NoAppAssociationOpenTextEd + "<p><b>" + FF.FullFileName + "</b>", function(MyAnswerIsYes)
				{
				if (! MyAnswerIsYes)
					return;
				Bros.RunApplication	(Bros.BrosAppName_AppTEditor,	"\"" + FF.FullFileName + "\"");
				});
			return;
			}

		// Temporarily opening only with the first name (in the future enable to user select)
		Bros.RunApplication			(AppNames[0],					"\"" + FF.FullFileName + "\"");
		//	Bros.RunApplication		(Bros.BrosAppName_AppTEditor,	"\"" + FF.FullFileName + "\"");
		//	Bros.RunApplication		(Bros.BrosAppName_AppImgView,	"\"" + FF.FullFileName + "\"");
		}

	//---------------------------------------------------------------------------
	// Menu ExploreBrosFS
	//---------------------------------------------------------------------------

	function Menu_ExploreBrosFS()
		{
		//	deb						("Menu_ExploreBrosFS");

		// New Mode
		MainParams.OpMode			= "ExploreBrosFS";

		// Window Caption
		Bros.element(Window_Name).caption(MainParams.Window_Caption + " " + Bros.Msg.FMA.Window_Caption_Physically);

		// Rebuild Tree
		RebuildTree					();
		}

	//---------------------------------------------------------------------------
	// Menu ExploreNormal
	//---------------------------------------------------------------------------

	function Menu_ExploreNormal()
		{
		//	deb						("Menu_ExploreNormal");

		// New Mode
		MainParams.OpMode			= "";

		// Window Caption
		Bros.element(Window_Name).caption(MainParams.Window_Caption);

		// Rebuild Tree
		RebuildTree					();
		}

	//---------------------------------------------------------------------------
	// Rebuild Tree
	//---------------------------------------------------------------------------

	function RebuildTree()
		{
		//	deb						("RebuildTree");

		// Delete Tree
		Bros.element("MyTree").deletetree();

		// Loads root folders
		Load_FileFolders			("");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Saves User Configurations
	//---------------------------------------------------------------------------

	function SaveUserConfig()
		{
		//	deb						("SaveUserConfig");

		// Rebuild Tree
		RebuildTree					();

		// Save User Configurations
		Bros.User.Config.Save(function (ErrorMsg)
			{
			// Silent result
			//if (Bros.DidShowError(ErrorMsg))
			//	return;
			//Bros.ShowMsg			("User Config Saved !");
			});
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Root Folders Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu Map New Root Folder
	//---------------------------------------------------------------------------

	function Menu_MapNewRootFolder()
		{
		//	deb						("Menu_MapNewRootFolder");
		var Params					= {
			 Window_Caption			: Bros.Msg.FMA.Menu_MapNewRootFolder
			,RootFolder				: null
			};
		// Build Window to New/Edit Root Folder
		RootFolder_BuildWindow		(Params, function (ErrorMsg, RF)
			{
			// ErrorMsg ?
			if (Bros.DidShowError(ErrorMsg))
				return;

			// Cancel the operation ?
			//	deb					("RF = " + RF);
			if (RF == null)
				return;

			// OK !
			//	PCS					(RF);
			Bros.FS.RootFolders.push(RF);

			// Saves User Configurations
			SaveUserConfig			();
			});
		}

	//---------------------------------------------------------------------------
	// Menu Edit Root Folder
	//---------------------------------------------------------------------------

	function Menu_EditRootFolder()
		{
		//	deb						("Menu_EditRootFolder");

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// FF_IsRootFolder ?
		if (! FF_IsRootFolder())
			return;

		// Gets RootFolder to Edit
		var RootFolder				= Bros.FS.GetRootFolder(FF.FullFileName);
		//	PCS						(RootFolder);
		if (RootFolder == null)
			Bros.FatalErrorMNO		("Menu_EditRootFolder", "(RootFolder == null)", "FF.FullFileName = " + FF.FullFileName);

		// Setup
		var Params					= {
			 Window_Caption			: Bros.Msg.FMA.Menu_EditRootFolder
			,RootFolder				: RootFolder
			};
		// Build Window to New/Edit Root Folder
		RootFolder_BuildWindow		(Params, function (ErrorMsg, RF)
			{
			// ErrorMsg ?
			if (Bros.DidShowError(ErrorMsg))
				return;

			// Cancel the operation ?
			//	deb					("RF = " + RF);
			if (RF == null)
				return;

			// OK ! Copy properties
			//	PCS					(RF);
			Bros.RootFolder.CopyProps(RF, RootFolder);
			//	Bros.Obj_CopyProps	(RF, RootFolder);

			// Saves User Configurations
			SaveUserConfig			();
			});

		}

	//---------------------------------------------------------------------------
	// Menu Disconnect Root Folder
	//---------------------------------------------------------------------------

	function Menu_DisconnectRootFolder()
		{
		//	deb						("Menu_DisconnectRootFolder");

		// FF_WasSelected ?
		if (! FF_WasSelected())
			return;

		// FF_IsRootFolder ?
		if (! FF_IsRootFolder())
			return;

		// Ask Confirmation
		//	PCS						(FF);
		Bros.ShowConfirmation(Bros.Msg.FMA.Menu_DisconnectRootFolder + "<p><b>" + FF.FullFileName + "</b>", function (Confirm)
			{
			//	deb					("ShowConfirmation OnClose, Confirm = " + Confirm);
			if (! Confirm)
				return;
			//	PCS					(FF);

			// Gets RootFolder to Disconnect
			var RootFolder			= Bros.FS.GetRootFolder(FF.FullFileName);
			//	PCS					(RootFolder);
			if (RootFolder == null)
				Bros.FatalErrorMNO	("Menu_DisconnectRootFolder", "(RootFolder == null)", "FF.FullFileName = " + FF.FullFileName);

			// Deletes
			Bros.Arr_Delete			(Bros.FS.RootFolders, RootFolder);

			// Saves User Configurations
			SaveUserConfig			();
			});

		}

	//---------------------------------------------------------------------------
	// Build Window to New/Edit Root Folder
	//---------------------------------------------------------------------------

	function RootFolder_BuildWindow(Params, OnClose)
		{
		//	deb						("RootFolder_BuildWindow");

		// Identify window origin
		var RF_WindowOrigin			= Bros.GetMainAppWindow(Bros.Cobj);
		//	deb						(Bros.CElm.WhoAmI(RF_WindowOrigin));

		// Unique name to allow more similar windows to be identified
		var RF_Window_Name			= "MyWindow_" + Bros.NextElementID++;
		//	deb						("RF_Window_Name = " + RF_Window_Name);

		// Click in OK ?
		var ClickedOK				=   false;

		// MainElement
		Bros.element				(Bros.MainElement);

		Bros
			.createelement			("window")
				.width				(450, 230)
				.name				(RF_Window_Name)
				.caption			(Params.Window_Caption)
				.onready			(function (Elem)
					{
					//	deb			("onready");		 // X (Close)	Exp/Norm	Min			ToTray		Help
					Elem.Handler.UpdateButtonsVisibility(Elem, [! false,	  false,	  false,	  false,	  false]);
					Bros.resizable	(false);
					Bros.centralize	();
					})
				.onclose			(function (Elem) {
				//	deb				("ClickedOK = " + ClickedOK);
				//	PCS				(Params);

					// Setup
					var RootFolder	= null;

					// ClickedOK ?
					if (ClickedOK)
						RootFolder	= Params.O_RF;

					// Set Focus
					if (RF_WindowOrigin != null)
						Bros.element(RF_WindowOrigin).setfocus();

					// Returns
					Bros.RunOnResult(OnClose, "", RootFolder);
					})
				.createelement		("panel")
					.height			(88)
					.align			("top")
					.borderstyle	(Bros.bsNone)
					.createelement	("label")
						.left		(8, 10)
						.caption	(Bros.Msg.FMA.WinRF_Folder_Caption)
						.autosize	(! false)
					.createelement	("select")
						.name		("My_RootFolder_FolderCaption")
						.text		(Params.RootFolder == null ? "" : Params.RootFolder.FolderCaption)
						.left		(88, 8, 344, 21)
						.onchange	(function (Elem) {
							//	deb		("onchange");
							})
// BUG HERE ! When defining onclick select does not work !
//						.onclick		(function (Elem, e) {
//							// Put here your event handler script
//							// alert("onclick");
//							})
						;

		// Folder Caption Options
		Bros			.additem	("Examples: (default = B:)")
						.additem	("B:")
						.additem	("My Drive B:")
						.additem	("C:")
						.additem	("X:")
						.additem	("Dropbox:")
						.additem	("My Dropbox:")
						.additem	("My Dropbox Folder:")
						;

		Bros		.createelement	("label")
						.left		(8, 34)
						.caption	(Bros.Msg.FMA.WinRF_Phisical_Folder)
						.autosize	(true)
					.createelement	("select")
						.name		("My_RootFolder_FolderMap")
						.text		(Params.RootFolder == null ? "" : Params.RootFolder.FolderMap)
						.left		(88, 32, 344, 21)
						.onchange	(function (Elem) {
							// Put here your event handler script
							// alert("onchange");
							})
						;

		// Folder Map Options
// Put examples on drivers and loop them here
		Bros			.additem	("Examples (physical directory addresses):")
						.additem	("(for Bros File System) (default = B:)")
						.additem	("B:")
						.additem	("B:/Data")
						.additem	("C:")
						.additem	("X:/Data/Test")
						.additem	("(for Dropbox) (blank is root folder)")
						.additem	("")
						.additem	("Data")
						.additem	("Data/Test")
						;
// BUG ABOVE
//	I am: select        ,  103, My_Folder_Caption
//	TypeError: Pos is undefined

		Bros		.createelement	("label")
						.left		(8, 58)
						.caption	(Bros.Msg.FMA.WinRF_Driver)
						.autosize	(true)
					.createelement	("select")
						.name		("My_RootFolder_Driver_Caption")
						.text		(Params.RootFolder == null ? "" : Params.RootFolder.Driver.Caption)
						.left		(88, 56, 344, 21)
						.onchange	(function (Elem) {
							// Put here your event handler script
							//	deb		("onchange", Bros.text());
							// Update Root Folder Window Driver
							RootFolder_BuildWindow_Driver(Params);
							})
						;

		// Drivers Options
		//	deb						("Bros.FS.Drivers.length = " + Bros.FS.Drivers.length);
		for (var i = 0; i < Bros.FS.Drivers.length; i++)
			{
			var Driver				= Bros.FS.Drivers[i];
			//	PCS					(Driver);
			if (! Driver.CanBeMappedByUser)
				continue;
			Bros.additem			(Driver.Caption);
			}

		// Continue...
		Bros		.parent			()
				.createelement		("panel")
					.height			(38)
					.borderstyle	(Bros.bsNone)
					.align			("bottom")
					.createelement	("button")
						.left		(8, 8, 72, 24)
						.caption	(Bros.Msg.VRB.Cancel)
						.onclick	(function (Elem, e) {
							Bros.element(RF_Window_Name).close();
							})
					.createelement	("button")
						.left		(360, 8, 72, 24)
						.caption	(Bros.Msg.WRD.OK)
						.onclick	(function (Elem, e) {
							Params.ErrorMsg	= "";
							Params.O_RF		= null;
							RootFolder_Set	(Params);
							//	PCS			(Params);
							if (Bros.DidShowError(Params.ErrorMsg))
								return;
							ClickedOK	= ! false;
							Bros.element(RF_Window_Name).close();
							})
					.parent			()
				.createelement		("panel")
					.left			(0, 88, 442, 72)
					.name			("MyPanelDriver")
					.borderstyle	(Bros.bsNone)
					//	.color		(Bros.clYellow)
					.align			("client")
					.parent			()
				.parent				()
			;

		// Update Root Folder Window Driver ?
		if (Params.RootFolder != null)
			RootFolder_BuildWindow_Driver(Params);
		}

	//---------------------------------------------------------------------------
	// Update Root Folder Window Driver
	//---------------------------------------------------------------------------

	function RootFolder_BuildWindow_Driver(Params)
		{
		//	deb						("RootFolder_BuildWindow_Driver", Bros.element("My_RootFolder_Driver_Caption").text());
		var DriverCaption			= Bros.element("My_RootFolder_Driver_Caption").text();
		Bros.element("MyPanelDriver").deletechildren();
		switch (DriverCaption)
			{
			case Bros.Msg.FSY.DriverCaption_URL:
				break;
			case Bros.Msg.FSY.DriverCaption_BrosFS:
				break;
			case Bros.Msg.FSY.DriverCaption_Dropbox:
				Bros.createelement	("label")
						.left		(8, 8, 70, 16)
						.caption	(Bros.Msg.FMA.WinRF_AccessToken)
						.autosize	(true)
						.borderstyle(Bros.bsNone)
						.color		(Bros.clNone)
						.halign		("left")
						.valign		("top")
					.createelement	("edit")
						.name		("My_RootFolder_AccessToken")
						.text		(Params.RootFolder == null ? "" : Params.RootFolder.AccessToken)
						.left		(88, 8, 344, 21)
					.createelement	("label")
					//	.left		(88, 37, 344, 30)
						.left		(8, 32, 424, 45)
						.halign		("center")
						.autosize	(  false)
						.caption	(Bros.Msg.FSY.DriverCaption_Dropbox_Msg)
						//	.color	(Bros.clRed)
						.valign		("top")
				break;
			default:
				Bros.FatalErrorMNO	("RootFolder_BuildWindow_Driver", "Unknown Driver [" + DriverCaption + "].");
			}
		}

	//---------------------------------------------------------------------------
	// Set RootFolder
	//---------------------------------------------------------------------------

	function RootFolder_Set(Params)
		{
		//	deb						("RootFolder_Set");
		//	PCS						(Params);

		// Get's new RootFolder
		var RF						= Bros.RootFolder.GetNewRootFolder();

		// Get's the values
		RF.FolderCaption			= Bros.element("My_RootFolder_FolderCaption")	.text();
		RF.FolderMap				= Bros.element("My_RootFolder_FolderMap")		.text();
		RF.Driver					= null;
		var Driver_Caption			= Bros.element("My_RootFolder_Driver_Caption")	.text();
		RF.AccessToken				= "";
		switch (Driver_Caption)
			{
			case Bros.Msg.FSY.DriverCaption_URL:
				RF.Driver			= Bros.FS.Driver_URL;
				break;
			case Bros.Msg.FSY.DriverCaption_BrosFS:
				RF.Driver			= Bros.FS.Driver_BrosFS;
				break;
			case Bros.Msg.FSY.DriverCaption_Dropbox:
				RF.Driver			= Bros.FS.Driver_Dropbox;
				RF.AccessToken		= Bros.element("My_RootFolder_AccessToken")		.text();
				break;
			// Will return an error if user fills the field by hand with an error value
			//default:
			//	Bros.FatalErrorMNO	("RootFolder_Set", "Unknown Driver [" + Driver_Caption + "].");
			}
		//	deb						("RF.FolderCaption = "	+ RF.FolderCaption);
		//	deb						("RF.FolderMap = "		+ RF.FolderMap);
		//	deb						("Driver_Caption = "	+ Driver_Caption);
		//	deb						("RF.AccessToken = "	+ RF.AccessToken);
		//	//
		//	PCS						(RF);

		// Starts
		var ErrorMsg				= "";

		// Validate
		ErrorMsg				   += Bros.RootFolder.Validate(RF);

		// If no errors, verify if already exists
		if (ErrorMsg == "")
			{
			// OK ! Already exists ?
			//	PCS					(Params);
			//	PCS					(RF);
			var RF_2				= Bros.FS.GetRootFolder(RF.FolderCaption);
			//	PCS					(RF_2);
			var AlreadyExists		=   false;
			if (RF_2 != null)
				{
				if (Params.RootFolder == null)
					AlreadyExists	= ! false;						// New Root Folder
				else
					if (RF_2 != Params.RootFolder)
						AlreadyExists= ! false;						// Edit Root Folder
				}
			//	deb					("AlreadyExists = " + AlreadyExists);
			if (AlreadyExists)
				ErrorMsg		   += Bros.Msg.FSY.RootFolderAlreadyExists + "<p><b>" + RF.FolderCaption + "</b>";
			}

		// Sets
		Params.ErrorMsg				= ErrorMsg;

		// If no error, set RF
		if (Params.ErrorMsg == "")
			Params.O_RF				= RF;
		}

	};	// function BrosApp_FileManager(Params)

//###########################################################################
//###########################################################################
