//###########################################################################
//###########################################################################
//##
//## Bros Application - System Monitor
//##
//###########################################################################
//###########################################################################

		// Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);
		//	PCS						(AppC, ! false);

		//What to Build
		AppC.MainMenu.Build			=   false;
		AppC.ButtonsPanel.Build		= ! false;
		AppC.StatusPanel.Build		=   false;

		// Window
		//	PCS						(Application);
		AppC.Window.Caption			= Application.Caption;

		// Main Menu
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.Tools);
			APPC.addmenuitem		(AppC, Bros.Msg.PHR.ClearMsgs,		"",	"",	Menu_Tools_ClearMsgs)	.Set("ShowButton", ! false);
			if (Bros.IsInDebug)
				{
				APPC.addmenuitem	(AppC, Bros.Msg.PHR.PrintScreen,	"",	"",	Menu_Tools_PrintScreen)	.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, "Show Status",				"",	"",	Menu_Tools_ShowStatus)	.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, "Show BOM",					"",	"",	Menu_Tools_ShowBOM)		.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitem	(AppC, "Toggle Debs",				"",	"",	Menu_Tools_ToggleDebs)	.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				// XPTBUGSETDATE+1
				APPC.addmenuitem	(AppC, "Tests",						"",	"",	Menu_Tools_Tests)		.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
				APPC.addmenuitemreload(AppC).Set("ShowMenuSpaceBefore", ! false);
				}
			APPC.endmenufolder		(AppC);

		// Go !
		APPC.createall				(AppC);

		// Complement Window
		Bros.element				(AppC.Window.Name);
		//	PCS						(Bros.element());
		Bros.BuildMsgsContainer		(Bros.element());

		//	Bros.Lib.UDate.Test		();

	//---------------------------------------------------------------------------
	// Main Menu Methods
	//---------------------------------------------------------------------------

	function Menu_Tools_ClearMsgs()
		{
		//	deb						("Menu_Clear_Msgs");
		Bros.ClearMsgsContainer		();
		}

	function Menu_Tools_PrintScreen()
		{
		//	deb						("Menu_Tools_PrintScreen");
		var re						= / id=/g;					// To cut id of all elements
		var Screen					= ("" + Bros.element(Bros.MainElement).html()).replace(re, " od=");
		Bros.RW						(Screen);
		}

	function Menu_Tools_ShowStatus()
		{
		//	deb						("Menu_Tools_ShowStatus");
		var Size					= Bros.element(Bros.MainElement).html().length;
		deb							("Bros size = " + Size);
		deb							("Stored Fonts = " + Bros.CFnt.StoredFonts.length);
		deb							("Bros.ElementsStack.length = " + Bros.ElementsStack.length);
		deb							("Bros.Cobj = " + Bros.CElm.WhoAmI(Bros.Cobj));
		PCS							(Bros);
		//	Bros.User.Config.Save();
		//	Bros.User.Config.Save(function (ErrorMsg){deb("Bros.User.Config.Save, ErrorMsg = " + ErrorMsg);});
		}

	function Menu_Tools_ShowBOM()
		{
		//	deb						("Menu_Tools_ShowBOM");
		Bros.ShowBOM				();
		}

	function Menu_Tools_ToggleDebs()
		{
		//	deb						("Menu_Tools_ToggleDeb");
		Bros.ShowDebs				= ! Bros.ShowDebs;
		}

	function Menu_Tools_Tests()
		{
		deb							("Menu_Tools_Tests");
		//	Bros.Reboot				();
		//	Bros.RebootUser			();
		//	Bros.User.Config.Save	();
		//	Bros.User.Config.Save	(function (ErrorMsg){deb("Bros.User.Config.Save, ErrorMsg = " + ErrorMsg);});
		//	Test_ObjFullCopy		();

		// XPTBUGSETDATE+1
		//	// AddDays Test
		//	var Base				= 1;
		//	// http://stackoverflow.com/questions/4110039/javascript-dates-what-is-the-best-way-to-deal-with-daylight-savings-time
		//	var MyDate				= Date.UTC(2015, 9, 18, 0, 0, 0, 0);
		//	MyDate					= new Date(MyDate);
		//	deb						(Base + "_A", MyDate, [MyDate.getUTCFullYear(), MyDate.getUTCMonth()+1, MyDate.getUTCDate()].join("/"));

		// XPTBUGSETDATE+1
		//	// AddDays Test
		//	var Base				= 1;
		//	var MyDate				= new Date(2015, 9, 17, 0, 0, 0, 0);
		//	deb						(Base + "_A", Bros.Lib.Date.ToStr(MyDate, Bros.Lib.Date.DebugFormat));
		//	MyDate.setDate			(MyDate.getDate() + 1);
		//	deb						(Base + "_B", Bros.Lib.Date.ToStr(MyDate, Bros.Lib.Date.DebugFormat));
		//	//
		//	Base++;
		//	var MyDate				= new Date(2015, 9, 17, 0, 0, 0, 0);
		//	deb						(Base + "_A", Bros.Lib.Date.ToStr(MyDate, Bros.Lib.Date.DebugFormat));
		//	Bros.Lib.Date.AddDays	(MyDate, 1);
		//	deb						(Base + "_B", Bros.Lib.Date.ToStr(MyDate, Bros.Lib.Date.DebugFormat));

		}

	//function Test_ObjFullCopy(XXX)
	//	{
	//	deb							("Test_ObjFullCopy");
	//
	//	// Creates
	//	var Obj_A					= {
	//		 MyUndef				: XXX
	//		,MyBool					: false
	//		,MyNum					: 12.34
	//		,MyStr					: "CocoXixi"
	//
	//		,MyFunc					: function ()
	//			{
	//			return "A"
	//			}
	//		,MyNull					: null
	//		,MyDate					: new Date(2015, 9, 14)
	//		,MyArr					: [1, 2, {Val:3}, 4]
	//
	//		,MyObj					: {
	//			 MyUndef			: XXX
	//			,MyBool				: false
	//			,MyNum				: 12.34
	//			,MyStr				: "CocoXixi"
	//			,MyFunc				: function ()
	//				{
	//				return "A"
	//				}
	//			,MyNull				: null
	//			,MyDate				: new Date(2015, 9, 14)
	//			,MyArr				: [1, 2, {Val:3}, 4]
	//			}
	//		}
	//
	//	// Get Copy
	//	var Obj_B					= Bros.Lib.Obj.GetFullCopy(Obj_A);
	//	//	var Obj_B				= Bros.Lib.Var.GetFullCopy(Obj_A);	// Also works ! (beautiful !!!)
	//
	//	// Modify
	//	Obj_B.MyBool				= ! false;
	//	Obj_B.MyNum					= 43.21;
	//	Obj_B.MyStr					= "XixiCoco";
	//	Obj_B.MyDate.setFullYear	(2020);
	//	Obj_B.MyArr[1]				= 33;
	//	Obj_B.MyArr[2].Val			= 73;
	//	//
	//	Obj_B.MyObj.MyBool			= ! false;
	//	Obj_B.MyObj.MyNum			= 143.21;
	//	Obj_B.MyObj.MyStr			= "1XixiCoco";
	//	Obj_B.MyObj.MyDate.setFullYear(2030);
	//	Obj_B.MyObj.MyArr[1]		= 133;
	//	Obj_B.MyObj.MyArr[2].Val	= 173;
	//
	//	// Show
	//	PCS							(Obj_A,	! false, ! false);
	//	PCS							(Obj_B, ! false, ! false);
	//	}

//###########################################################################
//###########################################################################
