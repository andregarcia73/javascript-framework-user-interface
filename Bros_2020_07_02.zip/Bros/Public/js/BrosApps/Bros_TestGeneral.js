//###########################################################################
//###########################################################################
//##
//## Bros Application - Test General
//##
//###########################################################################
//###########################################################################

		// Clear Msgs
		Bros.ClearMsgsContainer		();

		// This is an application example
		// 
		// To install this application:
		// 
		//		1) Save this file into some file
		//		2) Go to [My Computer] and add this Program
		//		3) Under the installed menu, runs it
		// 
		// So, you will can going modifying here and pressing Reload to see the results

		// Creates the Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// What to Build ?
		AppC.MainMenu.Build			=   false;
		AppC.ButtonsPanel.Build		= ! false;
		AppC.StatusPanel.Build		=   false;

		// Window Caption
		APPC.windowcaption			(AppC, "Test General");

		// Define IP (IP = ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_TextEditor/";
		var I2						= "../../1_Especif/Images/Squares/";
		var I3						= "../../1_Especif/Images/General/";

		// Main Menu
		APPC.addmenufolder			(AppC, "Main");
			APPC.addmenuitemreload	(AppC);
//			APPC.addmenuitemreload	(AppC);
//			APPC.addmenuitemreload	(AppC);
			APPC.addmenuitem		(AppC, "Clear Msgs",	"",								"",			Menu_Main_ClearMsgs).Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
//			APPC.addmenuitem		(AppC, "Test_01",		IP + "Img_0030_File_Open.png",	"Ctrl+1",	Menu_Main_Test_01)	.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
//			APPC.addmenuitem		(AppC, "Test_02",		I2 + "Square_016.png",			"Ctrl+2",	Menu_Main_Test_02)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_03",		I2 + "Square_016.png",			"Ctrl+3",	Menu_Main_Test_03)	.Set("ShowButton", ! false);
////			APPC.addmenuitem		(AppC, "Test_04",		I2 + "Square_016.png",			"Ctrl+4",	Menu_Main_Test_04)	.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Test_04",		I3 + "Img_File_Open_024.png",	"Ctrl+4",	Menu_Main_Test_04)	.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Test_05",		I2 + "Square_020.png",			"Ctrl+5",	Menu_Main_Test_05)	.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Test_06",		I2 + "Square_020.png",			"Ctrl+6",	Menu_Main_Test_06)	.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Test_07",		I2 + "Square_020.png",			"Ctrl+7",	Menu_Main_Test_07)	.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, "Test_08",		I2 + "Square_024.png",			"Ctrl+8",	Menu_Main_Test_08)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_09",		I2 + "Square_024.png",			"Ctrl+9",	Menu_Main_Test_09)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_10",		I2 + "Square_024.png",			"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_020.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_020.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_020.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_024.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_024.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
//			APPC.addmenuitem		(AppC, "Test_11",		I3 + "Img_File_Open_024.png",	"Ctrl+0",	Menu_Main_Test_10)	.Set("ShowButton", ! false);
			APPC.endmenufolder		(AppC);

		// Define Here your Status Panel
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Now, everything will be created automatically for you
		APPC.createall				(AppC);

		// Create Here your application elements
		var MyWindow;
		Bros
			.element				(APPC.windowname(AppC))
				.onready			(function (Elem)
					{
					MyWindow		= Elem;
					})
			//	.left				(10, 10, 800, 500)
			//
			.createelement			("panel")
				.name				("MyPanel")
				.align				("left")
				.halign				("left")
				.width				(100)
				.valign				("top")
				.borderstyle		(Bros.bsEdit)
				.color				(Bros.clWhite)
				.parent				()
			;
		Bros
			.createelement			("splitter")
				.align				("left")
				.borderstyle		(Bros.bsNone)
			.createelement			("panel")
				.align				("client")
				.borderstyle		(Bros.bsNone)
//				.width				(400)
			;
		Bros.BuildMsgsContainer		(Bros.element());
		Bros
				.parent				()
			;

		// Auto...
//	Menu_Main_Test_01		();
//	Menu_Main_Test_02		();
//	Menu_Main_Test_03		();
//	Menu_Main_Test_04		();
//	Sound_Test				();

	//---------------------------------------------------------------------------
	// Auxiliary Methods
	//---------------------------------------------------------------------------

	function UpdateMyPanel(Msg)
		{
		//	deb						("UpdateMyPanel", Msg);
		Bros
			.element				("MyPanel")
			.html					(Msg)
			;
		}

	function PushTDImage(Result, ImageName)
		{
		Result.push					("<td><img src='../../1_Especif/Images/Squares/" + ImageName + "'></td>");
		}

	function PushTDImageZoom(Result, ImageName, Width)
		{
		Result.push					("<td><img src='../../1_Especif/Images/General/" + ImageName + "' width=" + Width + "></td>");
		}

	//---------------------------------------------------------------------------
	// Menu Methods
	//---------------------------------------------------------------------------

	function Menu_Main_ClearMsgs()
		{
		//	deb						("Menu_Main_ClearMsgs");
		Bros.ClearMsgsContainer		();
		}

	function Menu_Main_Test_01()
		{
		//	deb						("Menu_Main_Test_01");
		// Builds images
		var Result					= [];
		//
		Result.push					("<table border=1 cellpadding=3>");
		Result.push					("<tr>");
		PushTDImage					(Result, "Square_016.png");
		PushTDImage					(Result, "Square_020.png");
		PushTDImage					(Result, "Square_024.png");
		PushTDImage					(Result, "Square_032.png");
		PushTDImage					(Result, "Square_040.png");
		PushTDImage					(Result, "Square_048.png");
		PushTDImage					(Result, "Square_064.png");
		PushTDImage					(Result, "Square_080.png");
		PushTDImage					(Result, "Square_128.png");
		Result.push					("</tr>");
		//
		Result.push					("<tr>");
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  16);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  20);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  24);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  32);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  40);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  48);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  64);
		PushTDImageZoom				(Result, "Img_File_Open_016.png",  80);
		PushTDImageZoom				(Result, "Img_File_Open_016.png", 128);
		Result.push					("</tr>");
		//
		Result.push					("<tr>");
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  16);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  20);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  24);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  32);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  40);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  48);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  64);
		PushTDImageZoom				(Result, "Img_File_Open_024.png",  80);
		PushTDImageZoom				(Result, "Img_File_Open_024.png", 128);
		Result.push					("</tr>");

// XPTBUGTABLE
Result.push					("<tabl>");
		//
		UpdateMyPanel				(Result.join(""));
		}

	function Menu_Main_Test_02()
		{
		//	deb						("Menu_Main_Test_02");
		//	http://stackoverflow.com/questions/3437786/get-the-size-of-the-screen-current-web-page-and-browser-window
		deb							("$(window)  .h()",	$(window)	.height()	);		// returns height of browser viewport
		deb							("$(document).h()",	$(document)	.height()	);		// returns height of HTML document
		deb							("$(window)  .w()",	$(window)	.width ()	);		// returns width of browser viewport
		deb							("$(document).w()",	$(document)	.width ()	);		// returns width of HTML document
		deb							("screen.height",	screen.height			);
		deb							("screen.width",	screen.width			);
		}

	function Menu_Main_Test_03()
		{
		//	deb						("Menu_Main_Test_03");
		var Result					= [];
		//
		Result.push					("<table border=1 cellpadding=0>");
		Result.push					("<tr>");
		Result.push					("<td id='MyTD' style='background-color:FF0000;height:1cm;width:1in;'>");
//		Result.push					("&nbsp;");
		Result.push					("</td>");
		Result.push					("</tr>");


// XPTBUGTABLE
Result.push					("<tabl>");
		//
		UpdateMyPanel				(Result.join(""));

		// 96 dpi !
		deb							($("#MyTD").width());
		}

	function Menu_Main_Test_04()
		{
		//	deb						("Menu_Main_Test_04");
		Sound_Test					();
		}

	function Menu_Main_Test_05()
		{
deb						("Menu_Main_Test_05");
		var Bobj;
		Bros
			.element				("MyPanel")
			.createelement			("panel")
				.name				("MyTestPanel")
				.movable			(! false)
				.resizable			(! false)
				.top				(10)
				.html				("AAA")
				.onready			(function (Elem)
					{
					Bobj			= Elem;
					})
			;
		//	PCS						(Bobj);
		var Selector				= "#" + Bros.CElm.Get_ID(Bobj,		Bros.Elm_ID_Element);
		var Selector				= "#" + Bros.CElm.Get_ID(MyWindow,	Bros.Elm_ID_Element);
		$(Selector)
			.css					({
		//		transform: 'rotate(' + 45 + 'deg)'
		//		opacity: 0.6
				})
//			.fadeTo					(1000, 0.1)
			;
//AnimateRotate(Selector, 0, 45);
AnimateRotate(Selector, 0, 360);
		}


// SPETACULAR !!!
	//	http://stackoverflow.com/questions/15191058/css-rotation-cross-browser-with-jquery-animate
	function AnimateRotate(Selector, From, angle)
		{
		//	deb						("AnimateRotate");
		// caching the object for performance reasons
		//    var $elem = $('#MyDiv2');
		var $elem = $(Selector);
		var Count					= 1;

		// we use a pseudo object for the animation
		// (starts from `0` to `angle`), you can name it as you want
		$({deg: From}).animate({deg: angle}, {
		//	$({a:1}).animate({a:1}, {
			 duration				: 2000
		//	,duration				: 400
			,step					: function(now, tween)
				{
				//	deb				(Count++, tween.pos);
				//	deb				(Count++, tween.pos, now);
				//	deb				(Bros.Lib.Str.Replicate("-", tween.pos * 100));
				//	return;
				//	if (Count == 2)
				//		{
				//		PCS			(tween);
				//		//	#	Name		Type		Value
				//		//	1	elem		object		function Object() { [native code] }...
				//		//	2	prop		string		deg
				//		//	3	easing		string		swing
				//		//	4	options		object		function Object() { [native code] }...
				//		//	5	now			number		0
				//		//	6	start		number		0
				//		//	7	end			number		20
				//		//	8	unit		string		px
				//		//	9	pos			number		0
				//		//	10	constructor	function	Zb(a,b,c,d,e)
				//		//	11	init		function	(a,b,c,d,e,f)
				//		//	12	cur			function	()
				//		//	13	run			function	(a)
				//		//	http://cdmckay.org/blog/2010/03/01/the-jquery-animate-step-callback-function/
				//		//		Attribute 			Type 		Description
				//		//		elem 				DOM Element The element being animated.
				//		//		end 				Number 		The value the animation will end at.
				//		//		now 				Number 		The value the animation is currently at.
				//		//		options 			Object 		Some animations options.
				//		//		options.curAnim 	Object 		Information about the current animation. For example, if you passed { opacity: 0, top: "+=16" } as the first parameter of animate, then they will be attributes of this object.
				//		//		options.duration 	Number 		The duration that you passed to animate.
				//		//		pos 				Number 		Sweeps from 0.0 to 1.0 during the animation. Sort of like a �t� value for interpolations.
				//		//		prop 				String 		The CSS property being varied (e.g. �opacity� or �top�).
				//		//		start 				Number 		The starting value of the CSS property being animated.
				//		//		startTime 			Number 		The timestamp indicating what time the animation started.
				//		//		state 				Number 		Which step of the animation we�re on. For example, if you made an animation that was moving 100px to the right over 100ms, and jQuery moves elements every 10ms, then there would be 10 states.
				//		//		unit 				String 		The unit of the CSS value being animated (e.g. �px� or �em�), if applicable.
				//		}
				//		//		Count	tween.pos
				//		//		1		0
				//		//		2		0,00012089778150797814
				//		//		3		0,0010365669572364733
				//		//		4		0,002219017698460002
				//		//		5		0,003748224626588137
				//		//		6		0,005674127631043024
				//		//		7		0,008135685525232028
				//		//		8		0,011035330084639083
				//		//		9		0,014746763265728768
				//		//		10		0,01920113349456143
				//		//		11		0,02471502979181006
				//		//		12		0,031176750351382176
				//		//		13		0,03866363006494261
				//		//		14		0,04758647376699027
				//		//		15		0,05848524117219944
				//		//		16		0,07164124056747517
				//		//		17		0,08734467065350016
				//		//		18		0,10540435709570578
				//		//		19		0,12807743509648745
				//		//		20		0,15091729050326363
				//		//		21		0,17527597583490823
				//		//		22		0,19916218710257383
				//		//		23		0,22221488349019886
				//		//		24		0,24076259698902236
				//		//		25		0,2563749371373338
				//		//		26		0,2723052355744401
				//		//		27		0,2920976698470714
				//		//		28		0,3144781448814745
				//		//		29		0,34325235253445086
				//		//		30		0,37565505641757263
				//		//		31		0,41016962570340365
				//		//		32		0,4443522573562317
				//		//		33		0,4740934660544689
				//		//		34		0,49607304955564446
				//		//		35		0,5125650477216687
				//		//		36		0,5306113729951311
				//		//		37		0,5540864330680247
				//		//		38		0,579768301199243
				//		//		39		0,6083050032193285
				//		//		40		0,6425096312349882
				//		//		41		0,6737951684855185
				//		//		42		0,70360745929122
				//		//		43		0,7283937171671498
				//		//		44		0,7477293342162038
				//		//		45		0,7619186217983924
				//		//		46		0,777785116509801
				//		//		47		0,7957955573024051
				//		//		48		0,8156763977246888
				//		//		49		0,839400372766471
				//		//		50		0,8623265650935233
				//		//		51		0,8852566213878945
				//		//		52		0,9054297904161867
				//		//		53		0,9246702001316582
				//		//		54		0,9392835762321976
				//		//		55		0,9514052878491468
				//		//		56		0,9619397662556434
				//		//		57		0,9704403844771128
				//		//		58		0,9774322723733215
				//		//		59		0,9830981656408574
				//		//		60		0,9879583809693737
				//		//		61		0,991864314474768
				//		//		62		0,994900554638763
				//		//		63		0,9970660496935775
				//		//		64		0,9986379965430785
				//		//		65		0,9995503835506225
				//		//		66		0,9999697746410507
				//		//		67		1
				//
				// in the step-callback (that is fired each step of the animation),
				// you can use the `now` paramter which contains the current
				// animation-position (`0` up to `angle`)
				//	$elem.css		({
				//		transform: 'rotate(' + now + 'deg)'
				//		});
				$elem.css			("transform", 'rotate(' + now + 'deg)');
				//	$elem.css		("left", now);
				}
			// http://api.jquery.com/animate/
			//		The strings 'fast' and 'slow' can be supplied to indicate durations of 200 and 600 milliseconds, respectively.
			//,start					: function (animation)	// Promise animation
			//	{
			//	PCS					(animation);
			//	//	#	Name				Type		Value
			//	//	1	elem				object		function Object() { [native code] }...
			//	//	2	props				object		function Object() { [native code] }...
			//	//	3	opts				object		function Object() { [native code] }...
			//	//	4	originalProperties	object		function Object() { [native code] }...
			//	//	5	originalOptions		object		function Object() { [native code] }...
			//	//	6	startTime			number		1436316503810
			//	//	7	duration			number		2000
			//	//	8	tweens				array		(1 items)	function	Array() { [native code] }...
			//	//	9	createTween			function	(b,c)
			//	//	10	stop				function	(b)
			//	//	11	state				function	()
			//	//	12	always				function	()
			//	//	13	then				function	()
			//	//	14	promise				function	(a)
			//	//	15	pipe				function	()
			//	//	16	done				function	()
			//	//	17	fail				function	()
			//	//	18	progress			function	()
			//	}
			,complete				: function ()
				{
				deb					("complete");
				}

			});
		}

	function Menu_Main_Test_06()
		{
deb						("Menu_Main_Test_06");
		var Selector				= "#" + Bros.CElm.Get_ID(MyWindow,	Bros.Elm_ID_Element);
		$(Selector)
		//	.css					({
		//		transform: 'rotate(' + 0 + 'deg)'
		//		})
			.fadeTo					(1000, 1)
			;
AnimateRotate(Selector, 45, 0);
		}

	function Menu_Main_Test_07()
		{
deb						("Menu_Main_Test_07");
		Bros
			.element				("MyPanel")
			.createelement			("button")
		}

	function Menu_Main_Test_08()
		{
deb						("Menu_Main_Test_08");

		//	window.print();
		//	return;

		// DO NOT WORK
		//	deb(Bros.element(MyWindow).html());
		//	https://www.developphp.com/video/JavaScript/Partial-Print-Document-Tutorial-HTML-div-Content
		//	var restorepage			= document.body.innerHTML;
		//	var printcontent		= Bros.element(MyWindow).html();
		//	document.body.innerHTML = printcontent;
		//	window.print();
		//	document.body.innerHTML = restorepage;

		// http://stackoverflow.com/questions/2255291/print-the-contents-of-a-div
		//	var re					= / id=/g;					// To cut id of all elements
		//	var mywindow			= window.open('', 'my div', 'height=400,width=600');
		//	mywindow.document.write	('<html><head><title>my div</title>');
	    //    /*optional stylesheet*/
		//	//mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
		//	mywindow.document.write	('</head><body >');
		////mywindow.document.write	(data);
		////mywindow.document.write	(Bros.element(MyWindow).html());
		//	mywindow.document.write	(Bros.element(MyWindow).html().replace(re, " od="));
		//	mywindow.document.write	('</body></html>');
		//
		//	mywindow.document.close	(); // necessary for IE >= 10
		//	mywindow.focus			(); // necessary for IE >= 10
		//
		//	mywindow.print			();
		//	mywindow.close			();

		//	Bros.element			(Bros.MainElement).visible(  false);
		//	window.print			();
		//	Bros.element			(Bros.MainElement).visible(! false);

			var re					= / id=/g;					// To cut id of all elements
			$("#Bros_Div_Screen").css("visibility", "hidden")	.css("width", "0")	 .css("height", "0"	  );
			$("#Bros_Div_Print") .css("visibility", "visible")	.css("width", "100%").css("height", "100%").html(Bros.element(MyWindow).html().replace(re, " od="));
			window.print			();
			$("#Bros_Div_Print") .css("visibility", "hidden")	.css("width", "0")	 .css("height", "0"	  ).html("");
			$("#Bros_Div_Screen").css("visibility", "visible")	.css("width", "100%").css("height", "100%");
		}

	function Menu_Main_Test_09()
		{
			deb						("Menu_Main_Test_09");
		}

	function Menu_Main_Test_10()
		{
			deb						("Menu_Main_Test_10");
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Sound Tests
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Sound Test
	//---------------------------------------------------------------------------

	function Sound_Test()
		{
		deb							("Sound_Test (nothing doing now here)");
		//	Bros.Lib.Audio.Test_Do	();
		//	Bros.Lib.Music.Test_Do	();
		}

//###########################################################################
//###########################################################################
