//###########################################################################
//###########################################################################
//##
//## Bros Applications Tables Library
//##
//###########################################################################
//###########################################################################

function BrosAppsTabsLib()
	{
	//---------------------------------------------------------------------------
	// Constants
	//---------------------------------------------------------------------------

		// To be used inside events
		var This					= this;

		// FileNames
		this.Folder					= "B:/MyDataBase/";
		//	this.Folder				= "B:/_AAA/";
		//
		this.FileName_Colors		= this.Folder + "Colors.csv";
		this.FileName_FontFamilies	= this.Folder + "FontFamilies.csv";
		this.FileName_Fonts			= this.Folder + "Fonts.csv";
		this.FileName_Relevances	= this.Folder + "Relevances.csv";
		this.FileName_People		= this.Folder + "People.csv";
		this.FileName_Reminders		= this.Folder + "Reminders.csv";

		// IDREMTYPE's
		this.IDREMTYPE_OneTimeOnly	= 1;							// One Time Only
		//	this.IDREMTYPE_Dayly	= 2;							// Dayly
		this.IDREMTYPE_Weekly		= 3;							// Weekly
		this.IDREMTYPE_Monthly		= 4;							// Monthly

		// IDWEEKS's
		this.IDWEEKS_OnAllMonthWeeks	= 1;						// on all month weeks
		this.IDWEEKS_On1stMonthWeeks	= 2;						// only on 1st month weeks
		this.IDWEEKS_On2ndMonthWeeks	= 3;						// only on 2nd month weeks
		this.IDWEEKS_On3rdMonthWeeks	= 4;						// only on 3rd month weeks
		this.IDWEEKS_On4rtMonthWeeks	= 5;						// only on 4rt month weeks
		this.IDWEEKS_OnLastMonthWeeks	= 6;						// only on last month weeks

	//---------------------------------------------------------------------------
	// Properties
	//---------------------------------------------------------------------------

		this.SetupDone				=   false;
		this.Tables					= {};
		this.DTabs					= [];

	//---------------------------------------------------------------------------
	// Setup Table Structures
	//---------------------------------------------------------------------------

	this.Setup = function Setup()
		{
		//	deb						("BrosAppsTabsLib.Setup");

		// Already done ?
		if (this.SetupDone)
			return;
		this.SetupDone				= ! false;
		//	deb						("BrosAppsTabsLib.Setup DOING !!!");

		var DTab;
		var ImgPath					= Bros.FS.A_BrosPublic_Img_I32;

		//###########################################################################
		//###########################################################################
		//##
		//## Tables Definition Beguin
		//##
		//###########################################################################
		//###########################################################################

		//---------------------------------------------------------------------------
		// Data Table: Colors
		//---------------------------------------------------------------------------

		DTab						= Bros.Lib.DTab.GetNew(this.FileName_Colors, Bros.Msg.WRD.Colors,					ImgPath + "Icon_BrosApp_Colors.png");
		this.Tables.Colors			= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			.AddColumn				(DTab, "SEQ",				"C",  80,  0, "VE", Bros.Msg.WRD.Sequence)
			.AddColumn				(DTab, "DESCR",				"C",  80,  0, "VE", Bros.Msg.WRD.Description)
			.AddColumn				(DTab, "COLOR",				"C",   6,  0, "VE", Bros.Msg.WRD.Color)					.Set(DTab, "LogicalType",	"color")
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
			//
			// Initial Records
			//
			// http://www.w3schools.com/cssref/css_colornames.asp
			//
			.AddInitialRecord		(DTab, {SEQ:"0010", DESCR:Bros.Msg.CLR.Black,		COLOR:"000000"})
			.AddInitialRecord		(DTab, {SEQ:"0020", DESCR:Bros.Msg.CLR.White,		COLOR:"FFFFFF"})
			.AddInitialRecord		(DTab, {SEQ:"0030", DESCR:Bros.Msg.CLR.Transparent,	COLOR:""})
			//
			.AddInitialRecord		(DTab, {SEQ:"0040", DESCR:Bros.Msg.CLR.LightGray,	COLOR:"E0E0E0"})
			.AddInitialRecord		(DTab, {SEQ:"0050", DESCR:Bros.Msg.CLR.Silver,		COLOR:"C0C0C0"})
			.AddInitialRecord		(DTab, {SEQ:"0060", DESCR:Bros.Msg.CLR.Gray,		COLOR:"808080"})
			.AddInitialRecord		(DTab, {SEQ:"0070", DESCR:Bros.Msg.CLR.DarkGray,	COLOR:"606060"})
			//
			.AddInitialRecord		(DTab, {SEQ:"0080", DESCR:Bros.Msg.CLR.Red,			COLOR:"FF0000"})
			.AddInitialRecord		(DTab, {SEQ:"0090", DESCR:Bros.Msg.CLR.GreenLime,	COLOR:"00FF00"})
			.AddInitialRecord		(DTab, {SEQ:"0100", DESCR:Bros.Msg.CLR.Blue,		COLOR:"0000FF"})
			//
			.AddInitialRecord		(DTab, {SEQ:"0110", DESCR:Bros.Msg.CLR.Yellow,		COLOR:"FFFF00"})
			.AddInitialRecord		(DTab, {SEQ:"0120", DESCR:Bros.Msg.CLR.Magenta,		COLOR:"FF00FF"})
			.AddInitialRecord		(DTab, {SEQ:"0130", DESCR:Bros.Msg.CLR.Cyan,		COLOR:"00FFFF"})
			//
			.AddInitialRecord		(DTab, {SEQ:"0140", DESCR:Bros.Msg.CLR.Maroon,		COLOR:"800000"})
			.AddInitialRecord		(DTab, {SEQ:"0150", DESCR:Bros.Msg.CLR.Green,		COLOR:"008000"})
			.AddInitialRecord		(DTab, {SEQ:"0160", DESCR:Bros.Msg.CLR.BlueNavy,	COLOR:"000080"})
			//
			.AddInitialRecord		(DTab, {SEQ:"0170", DESCR:Bros.Msg.CLR.GreenOlive,	COLOR:"808000"})
			.AddInitialRecord		(DTab, {SEQ:"0180", DESCR:Bros.Msg.CLR.Purple,		COLOR:"800080"})
			.AddInitialRecord		(DTab, {SEQ:"0190", DESCR:Bros.Msg.CLR.Teal,		COLOR:"008080"})
			//
			.AddInitialRecord		(DTab, {SEQ:"0200", DESCR:Bros.Msg.CLR.LightYellow,	COLOR:"FFFFC0"})
			.AddInitialRecord		(DTab, {SEQ:"0210", DESCR:Bros.Msg.CLR.Gold,		COLOR:"FFC000"})
			//
			//	.AddInitialRecord	(DTab, {SEQ:"0210", DESCR:Bros.Msg.CLR.Bege,		COLOR:"BBBB77"})
			//	.AddInitialRecord	(DTab, {SEQ:"0220", DESCR:Bros.Msg.CLR.BegeClaro,	COLOR:"E9E9D1"})
			//	.AddInitialRecord	(DTab, {SEQ:"0230", DESCR:Bros.Msg.CLR.Turquesa,	COLOR:"0099CC"})
			//
			// OnDraw
			.Set					(DTab, "OnDraw", function (TDEvent)
				{
				//	deb				("OnDraw", TDEvent.Type);
				//	var B			= C;							// To simulate Error
				switch (TDEvent.Type)
					{
					case "columndata":
						//	deb		("OnDraw", TDEvent.DCol.Name, TDEvent.ToShow);
						if (TDEvent.DCol.Name == "COLOR")
							{
							TDEvent.ComplementStyle = "background-color:" + TDEvent.ToShow + ";"
							if (TDEvent.ToShow == "000000")
								TDEvent.ToShow = "<font color='FFFFFF'>" + TDEvent.ToShow + "</font>";
							break;
							}
						break;
					}
				})
			;

		//---------------------------------------------------------------------------
		// Data Table: FontFamilies
		//---------------------------------------------------------------------------

		DTab						= Bros.Lib.DTab.GetNew(this.FileName_FontFamilies,	Bros.Msg.WRD.FontFamilies,		ImgPath + "Icon_BrosApp_FontFamilies.png");
		this.Tables.FontFamilies	= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			.AddColumn				(DTab, "SEQ",				"C",  80,  0, "VE", Bros.Msg.WRD.Sequence)
			.AddColumn				(DTab, "DESCR",				"C",  80,  0, "VE", Bros.Msg.WRD.Description)
			.AddColumn				(DTab, "FAMILY",			"C",  80,  0, "VE", Bros.Msg.WRD.FontFamily)			.Set(DTab, "RejectBlank",	true)
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
			//
			// Initial Records
			//
			.AddInitialRecord		(DTab, {SEQ:"0010", DESCR:"Arial",					FAMILY:"Arial"})
			.AddInitialRecord		(DTab, {SEQ:"0020", DESCR:"Times New Roman",		FAMILY:"Times New Roman"})
			.AddInitialRecord		(DTab, {SEQ:"0030", DESCR:"Bookman Old Style",		FAMILY:"Bookman Old Style"})
			.AddInitialRecord		(DTab, {SEQ:"0040", DESCR:"MS Sans Serif",			FAMILY:"MS Sans Serif"})
			.AddInitialRecord		(DTab, {SEQ:"0050", DESCR:"Verdana",				FAMILY:"Verdana"})
			.AddInitialRecord		(DTab, {SEQ:"0060", DESCR:"Comics",					FAMILY:"Comics"})
			.AddInitialRecord		(DTab, {SEQ:"0070", DESCR:"Courier New",			FAMILY:"Courier New"})
			.AddInitialRecord		(DTab, {SEQ:"0080", DESCR:"Fixedsys",				FAMILY:"Fixedsys"})
			//
			// OnDraw
			.Set					(DTab, "OnDraw", function (TDEvent)
				{
				switch (TDEvent.Type)
					{
					case "columndata":
						if (TDEvent.DCol.Name == "FAMILY")
							{
							TDEvent.ToShow = "<font style='font-family:" + TDEvent.ToShow + ";'>" + TDEvent.ToShow + "</font>";
							break;
							}
						break;
					}
				})
			;

		//---------------------------------------------------------------------------
		// Data Table: Fonts
		//---------------------------------------------------------------------------

		DTab						= Bros.Lib.DTab.GetNew(this.FileName_Fonts,			Bros.Msg.WRD.Fonts,				ImgPath + "Icon_BrosApp_Fonts.png");
		this.Tables.Fonts			= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			.AddColumn				(DTab, "SEQ",				"C",  80,  0, "VE", Bros.Msg.WRD.Sequence)
			.AddColumn				(DTab, "DESCR",				"C",  80,  0, "VE", Bros.Msg.WRD.Description)
			.AddColumn				(DTab, "IDFAMILY",			"I",  11,  0, "NE", Bros.Msg.WRD.FontFamily)			.Set(DTab, "RelatedTab",	this.Tables.FontFamilies)
			.AddColumn				(DTab, "SIZE",				"I",  11,  0, "NE", Bros.Msg.WRD.Size)					.Set(DTab, "InitialValue",	11)
			.AddColumn				(DTab, "IDCOLOR",			"I",  11,  0, "NE", Bros.Msg.WRD.Color)					.Set(DTab, "RelatedTab",	this.Tables.Colors)
			.AddColumn				(DTab, "BOLD",				"C",   1,  0, "NE", Bros.Msg.WRD.Bold)					.Set(DTab, "LogicalType",	"boolean")	.Set(DTab, "InitialValue", "N")
			.AddColumn				(DTab, "ITALIC",			"C",   1,  0, "NE", Bros.Msg.WRD.Italic)				.Set(DTab, "LogicalType",	"boolean")	.Set(DTab, "InitialValue", "N")
			.AddColumn				(DTab, "UNDERLINE",			"C",   1,  0, "NE", Bros.Msg.WRD.Underline)				.Set(DTab, "LogicalType",	"boolean")	.Set(DTab, "InitialValue", "N")
			.AddColumn				(DTab, "IDBGCOLOR",			"I",  11,  0, "NE", Bros.Msg.WRD.BackgroundColor)		.Set(DTab, "RelatedTab",	this.Tables.Colors)
			.AddColumn				(DTab, "NOWRAP",			"C",   1,  0, "NE", Bros.Msg.WRD.NoWrap)				.Set(DTab, "LogicalType",	"boolean")	.Set(DTab, "InitialValue", "N")
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
			//
			// Initial Records
			//
			.AddInitialRecord		(DTab, {SEQ:"0010", DESCR:Bros.Msg.WRD.Normal,			IDFAMILY:1, SIZE:11, IDCOLOR:1, BOLD:"N", ITALIC:"N", UNDERLINE:"N", IDBGCOLOR:3,  NOWRAP:"N"})	// IDBGCOLOR: Transparent
			.AddInitialRecord		(DTab, {SEQ:"0020", DESCR:Bros.Msg.PHR.NormalBgYellow,	IDFAMILY:1, SIZE:11, IDCOLOR:1, BOLD:"N", ITALIC:"N", UNDERLINE:"N", IDBGCOLOR:11, NOWRAP:"N"})	// IDBGCOLOR: Yellow
			.AddInitialRecord		(DTab, {SEQ:"0030", DESCR:Bros.Msg.PHR.BoldBgRed,		IDFAMILY:1, SIZE:11, IDCOLOR:1, BOLD:"S", ITALIC:"N", UNDERLINE:"N", IDBGCOLOR:8,  NOWRAP:"N"})	// IDBGCOLOR: Red
			//
			// OnDraw
			//
			.Set					(DTab, "OnDraw", function (TDEvent)
				{
				switch (TDEvent.Type)
					{
					case "columndata":
						if (TDEvent.DCol.Name == "DESCR")
							{
							This.OnDrawTD	(TDEvent, TDEvent.Reco);
							break;
							}
						break;
					}
				})
			;

		//---------------------------------------------------------------------------
		// Data Table: Relevances
		//---------------------------------------------------------------------------

		DTab						= Bros.Lib.DTab.GetNew(this.FileName_Relevances,	Bros.Msg.WRD.Relevances,		ImgPath + "Icon_BrosApp_Relevances.png");
		this.Tables.Relevances		= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			.AddColumn				(DTab, "SEQ",				"C",  80,  0, "VE", Bros.Msg.WRD.Sequence)
			.AddColumn				(DTab, "DESCR",				"C",  80,  0, "VE", Bros.Msg.WRD.Description)
			.AddColumn				(DTab, "IDFONT",			"I",  11,  0, "VE", Bros.Msg.WRD.Font)					.Set(DTab, "RelatedTab",	this.Tables.Fonts)
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
// XPTFATALERRORNOTSTOPING_TOOMUCHRECURSION
//.AddColumn				(DTab, "RecOo",				"I",  11,  0, "VE", "RecO").Set(DTab, "RelatedTab",	this.Tables.Relevances)
			//
			// Initial Records
			//
			.AddInitialRecord		(DTab, {SEQ:"0010", DESCR:Bros.Msg.WRD.Normal,			IDFONT:1})
			.AddInitialRecord		(DTab, {SEQ:"0020", DESCR:Bros.Msg.WRD.Important,		IDFONT:2})
			.AddInitialRecord		(DTab, {SEQ:"0030", DESCR:Bros.Msg.WRD.VeryImportant,	IDFONT:3})
			//
			// OnDraw
			.Set					(DTab, "OnDraw", function (TDEvent)
				{
				switch (TDEvent.Type)
					{
					case "columndata":
						if (TDEvent.DCol.Name == "IDFONT")
							{
// XPTFATALERRORNOTSTOPING_TOOMUCHRECURSION
							//	PCS			(TDEvent);
							//	PCS			(TDEvent.Reco);
							//	PCS			(TDEvent.Reco, ! false);
							//	deb			("TDEvent.Reco = " + TDEvent.Reco);
							This.OnDrawTD	(TDEvent, TDEvent.Reco.Reco.IDFONT);
							break;
							}
						break;
					}
				})
			;

		//---------------------------------------------------------------------------
		// Data Table: People
		//---------------------------------------------------------------------------

		DTab						= Bros.Lib.DTab.GetNew(this.FileName_People,		Bros.Msg.WRD.People,			ImgPath + "Icon_BrosApp_People.png");
		this.Tables.People			= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			//	.Set				(DTab, "Column",			"ID")
			//	.Set				(DTab, "VisibleInSheet",	false)
			//	.Set				(DTab, "Column",			"ENBD")
			//	.Set				(DTab, "VisibleInSheet",	true)
			.AddColumn				(DTab, "NAME",				"C",  80,  0, "VE", Bros.Msg.WRD.Name)					.Set(DTab, "RejectBlank", true)	.Set(DTab, "Unique", true)
			//
			.AddColumn				(DTab, "IDRELEVANC",		"I",  11,  0, "NE", Bros.Msg.WRD.Relevance)				.Set(DTab, "RelatedTab",	this.Tables.Relevances)
			//
			.AddColumn				(DTab, "PHONES",			"C", 240,  4, "NE", Bros.Msg.WRD.Phones)				.Set(DTab, "LogicalType", "phone")
			.AddColumn				(DTab, "EMAILS",			"C", 240,  4, "NE", Bros.Msg.WRD.EMails)				.Set(DTab, "LogicalType", "email")
			//
			//	.AddColumn			(DTab, "PHONE1",			"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 1")			.Set(DTab, "LogicalType", "phone")
			//	.AddColumn			(DTab, "PHONE2",			"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 2")			.Set(DTab, "LogicalType", "phone")
			//	.AddColumn			(DTab, "PHONE3",			"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 3")			.Set(DTab, "LogicalType", "phone")
			//	.AddColumn			(DTab, "PHONE4",			"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 4")			.Set(DTab, "LogicalType", "phone")
			//	.AddColumn			(DTab, "PHONE5",			"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 5")			.Set(DTab, "LogicalType", "phone")
			//
			//	.AddColumn			(DTab, "EMAIL1",			"C",  80,  0, "NE", Bros.Msg.WRD.EMail + " 1")			.Set(DTab, "LogicalType", "email")
			//	.AddColumn			(DTab, "EMAIL2",			"C",  80,  0, "NE", Bros.Msg.WRD.EMail + " 2")			.Set(DTab, "LogicalType", "email")
			//
			.AddColumn				(DTab, "BIRTHDAY",			"D",   8,  0, "NE", Bros.Msg.WRD.Birthday)				.Set(DTab, "InitialValue",	Bros.Lib.UDate.GetUndefinedDate())
			//
			.AddColumn				(DTab, "ADDRESS",			"C",  80,  0, "NE", Bros.Msg.WRD.Address)
			.AddColumn				(DTab, "NEIGHBORHD",		"C",  80,  0, "NE", Bros.Msg.WRD.Neighborhood)
			.AddColumn				(DTab, "CITY",				"C",  80,  0, "NE", Bros.Msg.WRD.City)
			.AddColumn				(DTab, "STATE",				"C",  80,  0, "NE", Bros.Msg.WRD.State)
			.AddColumn				(DTab, "COUNTRY",			"C",  80,  0, "NE", Bros.Msg.WRD.Country)
			.AddColumn				(DTab, "ZIPCODE",			"C",  80,  0, "NE", Bros.Msg.WRD.ZipCode)
			//
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
			//
			// Initial Records
			//
			.AddInitialRecord		(DTab, {NAME:Bros.Msg.WRD.You, IDRELEVANC:1})
			//
			// OnDraw
			//
			.Set					(DTab, "OnDraw", this.SetOnDrawTD_IDRELEVANC)
			;

		//---------------------------------------------------------------------------
		// Data Table: Reminders
		//---------------------------------------------------------------------------

		var ShowSameLineOffset		= 190;
		var This					= this;
		DTab						= Bros.Lib.DTab.GetNew(this.FileName_Reminders,		Bros.Msg.WRD.Reminders,			ImgPath + "Icon_BrosApp_Reminders.png");
		this.Tables.Reminders		= DTab;							// NickName
		Bros.Lib.DTab
			.AddControlColumns		(DTab)
			//	.AddColumn			(DTab, "SEQ",				"C",  80,  0, "VE", Bros.Msg.WRD.Sequence)
			.AddColumn				(DTab, "DESCR",				"C",  80,  0, "VE", Bros.Msg.WRD.Description)			.Set(DTab, "Unique",		 false)
			.AddColumn				(DTab, "IDRELEVANC",		"I",  11,  0, "NE", Bros.Msg.WRD.Relevance)				.Set(DTab, "RelatedTab",	this.Tables.Relevances)
			.AddColumn				(DTab, "IDPERSON",			"I",  11,  0, "NE", Bros.Msg.REM.EnvolvedPerson)		.Set(DTab, "RelatedTab",	this.Tables.People)
			.AddColumn				(DTab, "ENVVALUE",			"N",  11,  2, "NE", Bros.Msg.REM.EnvolvedValue)
			//
			.AddColumn				(DTab, "IDREMTYPE",			"I",  11,  0, "VE", Bros.Msg.REM.RemindWillOccur)		.Set(DTab, "InitialValue", 1)
				.AddOption			(DTab, Bros.Msg.REM.OneTimeOnly,	this.IDREMTYPE_OneTimeOnly)
				//	.AddOption		(DTab, Bros.Msg.WRD.Dayly,			this.IDREMTYPE_Dayly)
				.AddOption			(DTab, Bros.Msg.WRD.Weekly,			this.IDREMTYPE_Weekly)
				.AddOption			(DTab, Bros.Msg.WRD.Monthly,		this.IDREMTYPE_Monthly)
				// XPONCHANGE
				.Set				(DTab, "onchange",			function (Event, OnResult)	// OnResult is undefined here
					{
					//	deb			("OnChange !!!!!", "arguments.length = " + arguments.length, "OnResult = " + OnResult);
					//	PCS			(Event);
					//	PCS			(Event.QTab);
					//	PCS			(Event.QTab.DI);
					//	PCS			(Event.DTab);
					//	PCS			(Event.DCol);
					This.UpdateReminders	(Event.QTab, Event.NewValue);		// IDREMTYPE = Event.NewValue
					Bros.Lib.DI.UpdatePos	(Event.QTab.DI);
					})
			//
			.AddColumn				(DTab, "DATEBEGUIN",		"D",   8,  0, "NN", Bros.Msg.REM.DateBeguin)			.Set(DTab, "DateFormat",	Bros.User.Pref.DateFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetToday())			.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "DATEEND",			"D",   8,  0, "NN", Bros.Msg.REM.DateEnd)				.Set(DTab, "DateFormat",	Bros.User.Pref.DateFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "DisableShowHide", true)
			//
			// One time only
			//
			.AddColumn				(DTab, "ONETIMEBEG",		"D",   8,  0, "NN", Bros.Msg.REM.BeguinTime)			.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "ONETIMEEND",		"D",   8,  0, "NN", Bros.Msg.REM.EndTime)				.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "DisableShowHide", true)
			//
			// Weekly
			//
			.AddColumn				(DTab, "IDWEEKS",			"I",  11,  0, "NN", Bros.Msg.REM.OnWeeks)				.Set(DTab, "InitialValue", 1)							.Set(DTab, "DisableShowHide", true)
				.AddOption			(DTab, Bros.Msg.REM.OnAllMonthWeeks,	this.IDWEEKS_OnAllMonthWeeks)
				.AddOption			(DTab, Bros.Msg.REM.On1stMonthWeeks,	this.IDWEEKS_On1stMonthWeeks)
				.AddOption			(DTab, Bros.Msg.REM.On2ndMonthWeeks,	this.IDWEEKS_On2ndMonthWeeks)
				.AddOption			(DTab, Bros.Msg.REM.On3rdMonthWeeks,	this.IDWEEKS_On3rdMonthWeeks)
				.AddOption			(DTab, Bros.Msg.REM.On4rtMonthWeeks,	this.IDWEEKS_On4rtMonthWeeks)
				.AddOption			(DTab, Bros.Msg.REM.OnLastMonthWeeks,	this.IDWEEKS_OnLastMonthWeeks)
			.AddColumn				(DTab, "SUNTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Sun + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "SUNTIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "MONTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Mon + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "MONTIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "TUETIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Tue + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "TUETIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "WEDTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Wed + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "WEDTIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "THUTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Thu + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "THUTIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "FRITIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Fri + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "FRITIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "SATTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.CLD.Big.Sat + ": " + Bros.Msg.REM.BeguinTime)	.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())															.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "SATTIMEEND",		"D",   8,  0, "NN",								  Bros.Msg.REM.EndTime)		.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "ShowSameLineOffset", ShowSameLineOffset)	.Set(DTab, "DisableShowHide", true)
			//
			// Monthly
			//
			.AddColumn				(DTab, "IDMONTHDAY",		"I",  11,  0, "NN", Bros.Msg.REM.OnEveryMonthDay)		.Set(DTab, "InitialValue", 1)	.Set(DTab, "DisableShowHide", true)
			;
			for (var i = 1; i <= 31; i++)
				Bros.Lib.DTab.AddOption(DTab, "" + i, i);
			//
		Bros.Lib.DTab
			.AddColumn				(DTab, "MNTTIMEBEG",		"D",   8,  0, "NN", Bros.Msg.REM.BeguinTime)			.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "DisableShowHide", true)
			.AddColumn				(DTab, "MNTTIMEEND",		"D",   8,  0, "NN", Bros.Msg.REM.EndTime)				.Set(DTab, "DateFormat",	Bros.User.Pref.TimeFormat)	.Set(DTab, "InitialValue", Bros.Lib.UDate.GetUndefinedDate())	.Set(DTab, "DisableShowHide", true)
			//
		Bros.Lib.DTab
			.AddColumn				(DTab, "GENOBS",			"C", 240,  4, "NE", Bros.Msg.WRD.GeneralObservations)
			//	.AddColumn			(DTab, "HISTORIC",			"M", 240,  4, "NE", Bros.Msg.WRD.Historic)
			//
			// OnDraw
			//
			//.Set					(DTab, "OnDraw", function (TDEvent)
			//
			//	.Set				(DTab, "OnDraw", this.SetOnDrawTD_Reminders)
			.Set					(DTab, "OnDraw", function (TDEvent)
				{
				This.SetOnDrawTD_Reminders(TDEvent);
				})
			//
			//.Set					(DTab, "OnDraw", this.SetOnDrawTD_IDRELEVANC)
			//	{
			//	switch (TDEvent.Type)
			//		{
			//		case "columndata":
			//			if (TDEvent.DCol.Name != "ID")
			//				{
			//				This.OnDrawTD	(TDEvent, TDEvent.Reco.Reco.IDRELEVANC.Reco.IDFONT);
			//				break;
			//				}
			//			break;
			//		}
			//	})
			.Set					(DTab, "OnShowDataInput", function (QTab)
				{
				//	deb				("OnShowDataInput");
				//	PCS				(QTab);
				//	PCS				(QTab.Reco);
				This.UpdateReminders(QTab, QTab.Reco.IDREMTYPE);
				})
			;

		//###########################################################################
		//###########################################################################
		//##
		//## Tables Definition End
		//##
		//###########################################################################
		//###########################################################################

			// Build DTabs (in inverse order)
			this.BuildDTabs			();

		};

	//---------------------------------------------------------------------------
	// Build DTabs (in inverse order)
	//---------------------------------------------------------------------------

	this.BuildDTabs = function BuildDTabs()
		{
		//	deb						("BrosAppsTabsLib.BuildDTabs", this.DTabs.length);

		// Already done ?
		if (this.DTabs.length > 0)
			return;
		//	deb						("BrosAppsTabsLib.BuildDTabs (BUILDING)");


		// Build
		var DTab;
		for (var Table_NickName in this.Tables)
			{
			//	deb					(Table_NickName);
			DTab					= this.Tables[Table_NickName];
			DTab.NickName			= Table_NickName;
			Bros.Lib.Arr.InsertIndex(this.DTabs, 0, DTab);
			}
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Event Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Update Reminders Columns Visibilities
	//---------------------------------------------------------------------------

	this.UpdateReminders = function UpdateReminders(QTab, IDREMTYPE)
		{
		//	deb						("BrosAppsTabsLib.UpdateReminders", "IDREMTYPE = " + IDREMTYPE);
		//	PCS						(QTab);
		this.UpdateRemindersCol		(QTab, "DATEBEGUIN",	true);
		//
		this.UpdateRemindersCol		(QTab, "DATEEND",		IDREMTYPE != this.IDREMTYPE_OneTimeOnly);	// (Dayly, Weekly or Monthly)
		//
		this.UpdateRemindersCol		(QTab, "ONETIMEBEG",	IDREMTYPE == this.IDREMTYPE_OneTimeOnly);
		this.UpdateRemindersCol		(QTab, "ONETIMEEND",	IDREMTYPE == this.IDREMTYPE_OneTimeOnly);
		//
		this.UpdateRemindersCol		(QTab, "IDWEEKS",		IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "SUNTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "SUNTIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "MONTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "MONTIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "TUETIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "TUETIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "WEDTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "WEDTIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "THUTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "THUTIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "FRITIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "FRITIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "SATTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Weekly);
		this.UpdateRemindersCol		(QTab, "SATTIMEEND",	IDREMTYPE == this.IDREMTYPE_Weekly);
		//
		this.UpdateRemindersCol		(QTab, "IDMONTHDAY",	IDREMTYPE == this.IDREMTYPE_Monthly);
		this.UpdateRemindersCol		(QTab, "MNTTIMEBEG",	IDREMTYPE == this.IDREMTYPE_Monthly);
		this.UpdateRemindersCol		(QTab, "MNTTIMEEND",	IDREMTYPE == this.IDREMTYPE_Monthly);

		// Update DATEBEGUIN Caption
		var	DTab					= QTab.DTab;
		var	DCol					= Bros.Lib.DTab.GetCol(DTab, "DATEBEGUIN");
		var DI_Item					= DCol.DI_Item;
		DI_Item.Caption				= (IDREMTYPE == this.IDREMTYPE_OneTimeOnly ? Bros.Msg.REM.OnDate : Bros.Msg.REM.DateBeguin);
		//	PCS						(DI_Item);
		//	deb						(DI_Item.Label.Elem);
		if (DI_Item.Label.Elem != null)
			Bros.element			(DI_Item.Label.Elem).caption(DI_Item.Caption);
		};

	//---------------------------------------------------------------------------
	// Update Reminders Column Visibility
	//---------------------------------------------------------------------------

	this.UpdateRemindersCol = function UpdateRemindersCol(QTab, DCol_Name, VisEnabled)
		{
		//	deb						("BrosAppsTabsLib.UpdateReminders", "DCol_Name = " + DCol_Name, "VisEnabled = " + VisEnabled);
		//	PCS						(QTab);
		var	DTab					= QTab.DTab;
		var	DCol					= Bros.Lib.DTab.GetCol(DTab, DCol_Name);
		DCol.DI_Item.Visible		= VisEnabled;
		DCol.DI_Item.Enabled		= VisEnabled;
		};

	//---------------------------------------------------------------------------
	// SetOnDrawTD_IDRELEVANC
	//---------------------------------------------------------------------------

	this.SetOnDrawTD_IDRELEVANC = function SetOnDrawTD_IDRELEVANC(TDEvent)
		{
		switch (TDEvent.Type)
			{
			case "columndata":
				switch (TDEvent.DCol.Name)
					{
				// Original code
				//	case "ID":
				//	case "ENBD":
				//		return;

				// New code
					case "DESCR":
					case "NAME":
					case "IDRELEVANC":
						break;
					default:
						return;
					}
				//	This.OnDrawTD	(TDEvent, TDEvent.Reco.Reco.IDRELEVANC.Reco.IDFONT);
				// TDEvent.Reco.Reco.IDRELEVANC can be null in case of data corruption
				This.OnDrawTD		(TDEvent, (TDEvent.Reco.Reco.IDRELEVANC == null ? TDEvent.Reco.Reco.IDRELEVANC : TDEvent.Reco.Reco.IDRELEVANC.Reco.IDFONT));
				break;
			}
		};

	//---------------------------------------------------------------------------
	// OnDrawTD
	//---------------------------------------------------------------------------

	this.OnDrawTD = function OnDrawTD(TDEvent, RecoFont)
		{
		//	deb						("BrosAppsTabsLib.OnDrawTD", RecoFont);
		//	PCS						(TDEvent);

		// Is Null ? (IDFONT is invalid ?)
		if (RecoFont == null)
			return;
		//	PCS						(RecoFont, ! false);

		var Comp					= "";
		//
		if (RecoFont.Reco.IDFAMILY != null)
			Comp				   += "font-family:"		+ RecoFont.Reco.IDFAMILY.FAMILY	+ ";";
		//
		Comp					   += "font-size:"			+ Bros.ApplyZoom(RecoFont.SIZE)	+ ";";
		//
		if (RecoFont.Reco.IDCOLOR  != null)
			Comp				   += "color:"				+ RecoFont.Reco.IDCOLOR.COLOR	+ ";";
		//
		if (RecoFont.BOLD		   == "S")
			Comp				   += "font-weight:bold;";
		//
		if (RecoFont.ITALIC		   == "S")
			Comp				   += "font-style:italic;";
		//
		if (RecoFont.UNDERLINE	   == "S")
			Comp				   += "text-decoration:underline;";
		//
		if (RecoFont.Reco.IDBGCOLOR!= null)
			Comp				   += "background-color:"	+ RecoFont.Reco.IDBGCOLOR.COLOR	+ ";";

		// Apply
		//	deb						("Comp = " + Comp);
		TDEvent.ComplementStyle		= Comp;
		};

	//---------------------------------------------------------------------------
	// SetOnDrawTD_Reminders
	//---------------------------------------------------------------------------

	this.SetOnDrawTD_Reminders = function SetOnDrawTD_Reminders(TDEvent)
		{
		//	deb						("SetOnDrawTD_Reminders");
		//	PCS						(TDEvent);
		//	PCS						(TDEvent.Reco);

		// SetOnDrawTD_Reminders code
		if ((TDEvent.Type == "columndata") && (TDEvent.DCol.Name == "IDREMTYPE"))
			{
			var Reco				= TDEvent.Reco;
			//	PCS					(Reco);
			var Separator			= (TDEvent.IsShowRecord ? "<br>" : ", ");
			var ToShow				= "";
			//	ToShow			   += Separator + Bros.Msg.WRD.From + ": " + Bros.Lib.UDate.ToStr(Reco.DATEBEGUIN, Bros.User.Pref.DateFormat);
			//	ToShow			   += Separator + (Reco.IDREMTYPE == this.IDREMTYPE_OneTimeOnly ? Bros.Msg.REM.OnDate : Bros.Msg.REM.DateBeguin) + ": " + Bros.Lib.UDate.ToStr(Reco.DATEBEGUIN, Bros.User.Pref.DateFormat);
			ToShow				   += Separator + (Reco.IDREMTYPE == 1							? Bros.Msg.REM.OnDate : Bros.Msg.REM.DateBeguin) + ": " + Bros.Lib.UDate.ToStr(Reco.DATEBEGUIN, Bros.User.Pref.DateFormat);
			switch (Reco.IDREMTYPE)
				{
				case this.IDREMTYPE_OneTimeOnly:					// One time only
					ToShow		   += Separator + GetRemFromTo(Reco.ONETIMEBEG, Reco.ONETIMEEND, "");
					break;

			//	case this.IDREMTYPE_Dayly:							// Dayly
			//		break;

				case this.IDREMTYPE_Weekly:							// Weekly
					if (! Bros.Lib.UDate.IsUndefinedDate(Reco.DATEEND))
						ToShow	   += Separator + Bros.Msg.WRD.To + ": " + Bros.Lib.UDate.ToStr(Reco.DATEEND, Bros.User.Pref.DateFormat);
					//
					switch (Reco.IDWEEKS)
						{
						case this.IDWEEKS_OnAllMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.OnAllMonthWeeks;
							break;
						case this.IDWEEKS_On1stMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.On1stMonthWeeks;
							break;
						case this.IDWEEKS_On2ndMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.On2ndMonthWeeks;
							break;
						case this.IDWEEKS_On3rdMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.On3rdMonthWeeks;
							break;
						case this.IDWEEKS_On4rtMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.On4rtMonthWeeks;
							break;
						case this.IDWEEKS_OnLastMonthWeeks:
							ToShow += Separator + Bros.Msg.REM.OnLastMonthWeeks;
							break;
						default:
							Bros.FatalErrorMNO("SetOnDrawTD_Reminders", "Invalid Reco.IDWEEKS [" + Reco.IDWEEKS + "].");
						}
					//
					ToShow		   += GetRemFromTo(Reco.SUNTIMEBEG, Reco.SUNTIMEEND, Separator + Bros.Msg.CLD.Medium.Sun + ": ");
					ToShow		   += GetRemFromTo(Reco.MONTIMEBEG, Reco.MONTIMEEND, Separator + Bros.Msg.CLD.Medium.Mon + ": ");
					ToShow		   += GetRemFromTo(Reco.TUETIMEBEG, Reco.TUETIMEEND, Separator + Bros.Msg.CLD.Medium.Tue + ": ");
					ToShow		   += GetRemFromTo(Reco.WEDTIMEBEG, Reco.WEDTIMEEND, Separator + Bros.Msg.CLD.Medium.Wed + ": ");
					ToShow		   += GetRemFromTo(Reco.THUTIMEBEG, Reco.THUTIMEEND, Separator + Bros.Msg.CLD.Medium.Thu + ": ");
					ToShow		   += GetRemFromTo(Reco.FRITIMEBEG, Reco.FRITIMEEND, Separator + Bros.Msg.CLD.Medium.Fri + ": ");
					ToShow		   += GetRemFromTo(Reco.SATTIMEBEG, Reco.SATTIMEEND, Separator + Bros.Msg.CLD.Medium.Sat + ": ");
					break;

				case this.IDREMTYPE_Monthly:						// Monthly
					if (! Bros.Lib.UDate.IsUndefinedDate(Reco.DATEEND))
						ToShow	   += Separator + Bros.Msg.WRD.To + ": " + Bros.Lib.UDate.ToStr(Reco.DATEEND, Bros.User.Pref.DateFormat);
					ToShow		   += Separator + GetRemFromTo(Reco.MNTTIMEBEG, Reco.MNTTIMEEND, "");
					break;

				default:
					Bros.FatalErrorMNO("SetOnDrawTD_Reminders", "Invalid Reco.IDREMTYPE [" + Reco.IDREMTYPE + "].");
				}

			//	PCS					(TDEvent);
			TDEvent.ToShow		   += ToShow;
			return;
			}

		// Code from SetOnDrawTD_IDRELEVANC
		switch (TDEvent.Type)
			{
			case "columndata":
				switch (TDEvent.DCol.Name)
					{
				// Original code
				//	case "ID":
				//	case "ENBD":
				//		return;

				// New code
					case "DESCR":
					case "NAME":
					case "IDRELEVANC":
						break;
					default:
						return;
					}
				//	This.OnDrawTD	(TDEvent, TDEvent.Reco.Reco.IDRELEVANC.Reco.IDFONT);
				// TDEvent.Reco.Reco.IDRELEVANC can be null in case of data corruption
				This.OnDrawTD		(TDEvent, (TDEvent.Reco.Reco.IDRELEVANC == null ? TDEvent.Reco.Reco.IDRELEVANC : TDEvent.Reco.Reco.IDRELEVANC.Reco.IDFONT));
				break;
			}

		};

	//---------------------------------------------------------------------------
	// Get Reminder From-To
	//---------------------------------------------------------------------------

	function GetRemFromTo(From, To, Caption)
		{
		//	deb						("GetRemFromTo", From, To);
		var Temp					= Bros.Lib.UDate.ToStr(From, Bros.User.Pref.TimeFormat);
		if (Temp.indexOf("?") >= 0)
			return "";
		var ToShow					= Temp;
		Temp						= Bros.Lib.UDate.ToStr(To,	 Bros.User.Pref.TimeFormat);
		if (Temp.indexOf("?") >= 0)
			return Caption + ToShow;
		return Caption + ToShow + "-" + Temp;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Validate Table NickName
	//---------------------------------------------------------------------------

	this.Validate_Table_NickName = function Validate_Table_NickName(Table_NickName)
		{
		//	deb						("BrosAppsTabsLib.Validate_Table_NickName", Table_NickName);
		//	Table_NickName			+= "AAA";

		// Exists ?
		if (typeof(this.Tables[Table_NickName]) != "undefined")
			return true;

		// Error !
		//	Bros.lib.dlg.showerror	(Bros.Lib.Str.UpdateMsg(Bros.Msg.TSY.Error_InvalidTableNickName, Table_NickName));
		Bros.FatalErrorMNO			("BrosAppsTabsLib.Validate_Table_NickName", Bros.Lib.Str.UpdateMsg(Bros.Msg.TSY.Error_InvalidTableNickName, Table_NickName));
		return false;
		};

	//---------------------------------------------------------------------------
	// Get Table
	//---------------------------------------------------------------------------

	this.GetTable = function GetTable(Table_NickName)
		{
		//	deb						("BrosAppsTabsLib.GetTable", Table_NickName);

		// Setup Table Structures
		this.Setup					();

		// Validate Table_NickName
		if (! this.Validate_Table_NickName(Table_NickName))
			return;

		// Defines Data Table
		var DTab					= this.Tables[Table_NickName];

		// Returns it
		return DTab;
		};

	//---------------------------------------------------------------------------
	// Do Load Table
	//---------------------------------------------------------------------------

	this.DoLoadTable = function DoLoadTable(Table_NickName, Reload, OnResult)
		{
		//	deb						("BrosAppsTabsLib.DoLoadTable", Table_NickName, Reload);

		// Setup Table Structures
		this.Setup					();

		// Validate Table_NickName
		if (! this.Validate_Table_NickName(Table_NickName))
			return;

		// Defines Data Table
		var DTab					= this.Tables[Table_NickName];

		// Gets Search Condition
		var Condition				= Bros.Lib.DTab.GetNewCondition(DTab);
		Condition.Reload			= Reload;						// Cascade Reload
		//	Condition.ToSearch		= "something";					// To Search something

		// Load
		Bros.Lib.DTab.SelectRecords	(DTab, Condition, function (ErrorMsg)
			{
			Bros.lib.sys.runonresult(OnResult, ErrorMsg);
			});
		};

	//---------------------------------------------------------------------------
	// Reload Table
	//---------------------------------------------------------------------------

	this.ReloadTable = function ReloadTable(Table_NickName, OnResult)
		{
		//	deb						("BrosAppsTabsLib.ReloadTable", Table_NickName);
		//	Bros.lib.sys.runonresult(OnResult, "");
		//	return;
		this.DoLoadTable			(Table_NickName, true, OnResult);			// Reload = true
		};

//	//---------------------------------------------------------------------------
//	// Edit Table
//	//---------------------------------------------------------------------------
//
//	this.EditTable = function EditTable(Table_NickName)
//		{
//		//	deb						("BrosAppsTabsLib.EditTable", Table_NickName);
//		//	return;
//		this.Do_EditTable			(Table_NickName, "MyMainHostPanel");
//		};
//
//	//---------------------------------------------------------------------------
//	// Edit Table
//	//---------------------------------------------------------------------------
//
//	this.Do_EditTable = function Do_EditTable(Table_NickName, PanelName)
//		{
//		//	deb						("BrosAppsTabsLib.Do_EditTable", Table_NickName, PanelName);
//		//	return;
//
//		// Setup Table Structures
//		this.Setup					();
//
//		// Validate Table_NickName
//		if (! this.Validate_Table_NickName(Table_NickName))
//			return;
//
//		// Defines Data Table
//		var DTab					= this.Tables[Table_NickName];
//
//		// Creates Data Query
//		var QTab					= Bros.Lib.QTab.GetNew(DTab);
//		Bros.Lib.QTab
//			.Set					(QTab, "HostPanelName",	PanelName)
//			;
//
//		// Starts Showing Selection
//		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
//			{
//			Bros.lib.dlg.didshowerror(ErrorMsg);
//			});
//
//		};

	//---------------------------------------------------------------------------
	// Edit AllTables
	//---------------------------------------------------------------------------

	this.EditAllTables = function EditAllTables(Argument, OnResult)
		{
		//	deb						("BrosAppsTabsLib.EditAllTables", arguments.length, Argument, OnResult);
		//	return;

		// Setup Table Structures
		this.Setup					();

		// OK !
		Bros.RunOnResult			(OnResult, "");
		};

	//===========================================================================
	//===========================================================================
	//==
	//== Link Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Get Link to Show a Record
	//---------------------------------------------------------------------------

	this.GetLink = function GetLink(QTab, Reco_ID, ToShow)
		{
		//	deb						("BrosAppsTabsLib.GetLink", QTab.Index, QTab.DTab.Name, Reco_ID, ToShow);
		//	return ToShow;
		//	deb						("BrosAppsTabsLib.GetLink", this.ObjectDescriptor.Index);
		//	PCS						(this.ObjectDescriptor);

		var TagOnClick				= " onclick='Bros.Lib.Sys.GetObjByIndex(" + this.ObjectDescriptor.Index + ").ProcessLink(" + QTab.Index + ", " + Reco_ID + ");' ";
		// XPTELEMENTNOTFOUND
		// XPTELEMENTNOTFOUNDSTACKSAVE
		//	TagOnClick				= " onclick='alert(1);Bros.Lib.Sys.GetObjByIndex(" + this.ObjectDescriptor.Index + ").ProcessLink(" + QTab.Index + ", " + Reco_ID + ");' ";

		// Build and show
		var Result					= "";
		Result					   += "<div ";
		Result					   += TagOnClick;
		Result					   += "onmouseover=\"this.style.textDecoration='underline';this.style.cursor='pointer';\" ";
		Result					   += "onmouseout=\"this.style.textDecoration='none';\" ";
		Result					   += ">";
		Result					   += ToShow;
		Result					   += "</div>";
		return Result;
		};

	//---------------------------------------------------------------------------
	// Process Link
	//---------------------------------------------------------------------------

	this.ProcessLink = function ProcessLink(QTab_Index, Reco_ID)
		{
		//	deb						("BrosAppsTabsLib.ProcessLink", QTab_Index, Reco_ID);
		//	deb						(Bros.CElm.WhoAmI(Bros.Bobj_ToSearch));
		// XPTELEMENTNOTFOUND
		//	[I am: 82, panel, Panel_DateTime]	-> You are trying to get an element with the name: Panel_People that was not found.
		//	[I am: 92, timer, MainTimer]		-> You are trying to get an element with the name: Panel_People that was not found.
		//	[I am: 172, window, MyWindow_172]	-> OK !
		//	return;

		// Define QTab
		var QTab					= Bros.Lib.QTab.QTabs[QTab_Index];
		//	deb						("QTab.HostPanelName = " + QTab.HostPanelName);

		// Select QTab Panel
		var Effect					= "auto";
		//	Effect					= "none";
		//	Effect					= "top";
		Bros.Lib.Elem.SelectPanel	(QTab.HostPanelName, Effect);

		// Show Record
		//Bros.Lib.QTab.ShowSelection(QTab, function (ErrorMsg)
		//	{
		//	Bros.lib.dlg.didshowerror(ErrorMsg);
		//	});
		Bros.Lib.QTab.ShowRecord	(QTab, Reco_ID, function (ErrorMsg)
			{
			Bros.lib.dlg.didshowerror(ErrorMsg);
			});
		};

	};	// function BrosAppsTabsLib()

//###########################################################################
//###########################################################################
