//###########################################################################
//###########################################################################
//##
//## Bros Application - Calculator
//##
//###########################################################################
//###########################################################################

		//	deb							("BrosApp_Calculator");

		//---------------------------------------------------------------------------
		// Window
		//---------------------------------------------------------------------------

		Bros
			.createelement				("window")
				//	.left				(810, 40, 260, 252)
				.width					(260, 252)
				.resizable				(false)
//.maximize()
				.createelement			("label")
					.autosize			(  false)
					.caption			("&nbsp;Edit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;View&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Help")
					.borderstyle		([])
					.height				(19)
					.align				("top")
					.halign				("left")
					.valign				("middle")
					.parent				()

				.createelement			("panel")
					.caption			("")
					.align				("top")
					.height				(27)
					.borderstyle		([])
					.createelement		("label")
						.autosize		(  false)
						.left			(7, 0, 238, 23)
						.borderstyle	(Bros.bsEdit)
						.name			("Calc_Display")
						.caption		("0&nbsp;")
						.halign			("right")
						.valign			("middle")
						.color			("FFFFFF")
					.parent				()
				.createelement			("panel")
					.caption			("")
					.align				("client")
					.borderstyle		([])
					//
					.createelement		("label")
						.autosize		(  false)
						.left			(11, 10, 27, 26)
						.borderstyle	(Bros.bsEdit)
						.name			("Calc_Memory")
						.halign			("center")
						.valign			("middle")
						.caption		("")
					//
					.createelement		("button")
						.left			(53, 8, 63, 29)
						.caption		("Backspace")
						.font			({color:"FF0000"})
						.onclick		(function(Elem, e){CalcProcess(Bros.caption());})
					//
					.createelement		("button")
						.left			(53 + 1 * 66, 8, 62, 29)
						.caption		("CE")
						.font			({color:"FF0000"})
						.onclick		(function(Elem, e){CalcProcess(Bros.caption());})
					//
					.createelement		("button")
						.left			(52 + 2 * 66, 8, 62, 29)
						.caption		("C")
						.font			({color:"FF0000"})
						.onclick		(function(Elem, e){CalcProcess(Bros.caption());})
					//
					//	.parent			()					// Not yet
			;
		// Lines of buttons
		var LTWH						= [7, 44, 36, 29];
		var Captions					= ["MC",		"7",		"8",		"9",		"/",		"sqrt",
										   "MR",		"4",		"5",		"6",		"*",		"%",
										   "MS",		"1",		"2",		"3",		"-",		"1/x",
										   "M+",		"0",		"+/-",		".",		"+",		"="];
		var Colors						= ["FF0000",	"0000FF",	"0000FF",	"0000FF",	"FF0000",	"0000FF",
										   "FF0000",	"0000FF",	"0000FF",	"0000FF",	"FF0000",	"0000FF",
										   "FF0000",	"0000FF",	"0000FF",	"0000FF",	"FF0000",	"0000FF",
										   "FF0000",	"0000FF",	"0000FF",	"0000FF",	"FF0000",	"FF0000"];
		var Index						= 0;
		for (var Row = 1; Row <= 4; Row++)
			{
			LTWH[0]						= 7;
			for (var Col = 1; Col <= 6; Col++)
				{
				if (Col == 2)
					LTWH[0]			   += 7;
				Bros
					.createelement		("button")
						.left			(LTWH)
						.caption		(Captions[Index])
						.font			({color:Colors[Index++]})
						.onclick		(function(Elem, e){CalcProcess(Bros.caption());})
					;
				LTWH[0]				   += 39;				// Next column
				}
			LTWH[1]					   += 33;				// Next line
			}

		//---------------------------------------------------------------------------
		// Limitations
		//---------------------------------------------------------------------------

		var Max_X							= 99999999999999;				// 99.999.999.999.999 (depending on javascript browser implementation)
		var Min_X							= - Max_X;

		//---------------------------------------------------------------------------
		// Calculations
		//---------------------------------------------------------------------------

		var State							= 0;
		//	State = 0 -> Empty  X
		//	State = 1 -> Typing X
		//	State = 2 -> Typing X decimals
		var Val_M							= 0;
		var Val_Y							= 0;
		var Val_X							= 0;
		var Val_X_Str						= "0";
		var LastOp							= "";

		function CalcProcess(Action)
			{
			var StateBefore					= State;
			switch (Action)
				{
				case "Backspace":
					switch (State)
						{
						default:
							var LastChar	= Val_X_Str.substr(Val_X_Str.length - 1, 1);
							//	deb			(LastChar);
							Val_X_Str		= Val_X_Str.substr(0, Val_X_Str.length - 1);
							if (Val_X_Str == "")
								{
								State		=  0;
								Val_X_Str	= "0";
								break;
								}
							if (LastChar == ".")
								{
								State		=  1;
								break;
								}
						}
					break;
				case "CE":
					switch (State)
						{
						default:
							State			=  0;
							Val_X_Str		= "0";
						}
					break;
				case "C":
					switch (State)
						{
						default:
							State			=  0;
							Val_X_Str		= "0";
							Val_Y			=  0;
							LastOp			= "";
						}
					break;

				case "MC":
					Val_M					= 0;
					break;
				case "MR":
					Val_X					= Val_M;
					Val_X_Str				= "" + Val_X;
					break;
				case "MS":
					Val_M					= Val_X;
					break;
				case "M+":
					Val_M				   += Val_X;
					break;

				case "0":
				case "1":
				case "2":
				case "3":
				case "4":
				case "5":
				case "6":
				case "7":
				case "8":
				case "9":
					switch (State)
						{
						case 0:
							State			= 1;
							Val_X_Str		= Action;
							break;
						case 1:
						case 2:
							Val_X_Str	   += Action;
							break;
						}
					break;

				case "+/-":
					Val_X					= - Val_X;
					Val_X_Str				= "" + Val_X;
					break;
				case ".":
					switch (State)
						{
						case 0:
						case 1:
							State			= 2;
							Val_X_Str	   += Action;
							break;
						case 2:										// Ignores
							break;
						}
					break;

				case "/":
					DoLastOp				(Action);
					break;
				case "*":
					DoLastOp				(Action);
					break;
				case "-":
					DoLastOp				(Action);
					break;
				case "+":
					DoLastOp				(Action);
					break;

				case "sqrt":
					Val_X					= Math.sqrt(Val_X);
					Val_X_Str				= "" + Val_X;
					break;
				case "%":
					Val_X					= Val_X * Val_Y / 100;
					if (LastOp == "*")
						{
						State				= 0;
						Val_X_Str			= "" + Val_X;
						Val_Y				= Val_X;
						LastOp				= "";
						}
					else
						DoLastOp			(Action);
					break;
				case "1/x":
					if (Val_X == 0)
						{
						State				=  0;
						Val_X_Str			= "0";
						LastOp				= "";
						Bros.element("Calc_Display").caption("Cannot divide by zero.");
						return;
						}
					Val_X					= 1 / Val_X;
					Val_X_Str				= "" + Val_X;
					break;
				case "=":
					DoLastOp				(Action);
					break;
				}
			//	deb							("CalcProcess", "Action = " + Action, "StateBefore = " + StateBefore, "State = " + State);

			// Applies
			Val_X							= Number(Val_X_Str);
			if (Val_X						> Max_X)
				{
				Val_X						= Max_X;
				Val_X_Str					= "" + Val_X;					// Replaces
				}
			if (Val_X						< Min_X)
				{
				Val_X						= Min_X;
				Val_X_Str					= "" + Val_X;					// Replaces
				}

			// Update Display
			Bros.element("Calc_Display").caption("" + Val_X_Str + "&nbsp;");
			Bros.element("Calc_Memory")	.caption(Val_M == 0 ? "" : "M");
			}

		function DoLastOp(Action)
			{
			//	deb							("DoLastOp", "LastOp = " + LastOp, "Action = " + Action);

			// Do Last Operation
			switch (State)
				{
				case 1:
				case 2:
					switch (LastOp)
						{
						case "/":
							if (Val_X == 0)
								{
								State		=  0;
								Val_X_Str	= "0";
								LastOp		= "";
								Bros.element("Calc_Display").caption("Cannot divide by zero.");
								return;
								}
							Val_X			= Val_Y / Val_X;
							break;
						case "*":
							Val_X			= Val_Y * Val_X;
							break;
						case "-":
							Val_X			= Val_Y - Val_X;
							break;
						case "+":
							Val_X			= Val_Y + Val_X;
							break;
						}
					Val_X_Str				= "" + Val_X;
					break;
				}

			// Resets
			State							= 0;
			Val_Y							= Val_X;
			LastOp							= Action;
			};

//###########################################################################
//###########################################################################
