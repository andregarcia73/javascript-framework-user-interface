//###########################################################################
//###########################################################################
//##
//## Bros Application - Test Elements
//##
//###########################################################################
//###########################################################################

alert(123);

//	Bros.runmethod					(function (Application)
//		{
		//	deb						("App_TestElements");

		//---------------------------------------------------------------------------
		// Build Window
		//---------------------------------------------------------------------------

		Bros
			.createelement			("window")
				.left				(750, 22, 500, 500)
				.createelement		("panel")
					.align			("top")
					.borderstyle	(Bros.bsNone)
					.height			(45)
					.createelement	("button")
						.left		(10 + 80 * 0, 10)
						.caption	("Test JSON")
						.onclick	(function (Elem, e)
							{
							Test_JSON();
							})
					.createelement	("button")
						.left		(10 + 80 * 1, 10)
						.caption	("Test Image")
						.onclick	(function (Elem, e)
							{
							Test_Img();
							})
					.createelement	("button")
						.left		(10 + 80 * 2, 10)
						.caption	("Test FS")
						.onclick	(function (Elem, e)
							{
							Test_FS	();
							})
					.createelement	("button")
						.left		(10 + 80 * 3, 10)
						.caption	("FS Write")
						.onclick	(function (Elem, e)
							{
Bros.ClearMsgsContainer();
							FS_Write();
							})
					.createelement	("button")
						.left		(10 + 80 * 4, 10)
						.caption	("FS Read")
						.onclick	(function (Elem, e)
							{
Bros.ClearMsgsContainer();
							FS_Read	();
							})
					.parent			()
				.createelement		("edit")
					.name			("MyEdit")
					.align			("top")
					.width			(300)
					.keyup			(function (Elem, e)
						{
						DoSearch	();
						})
				.createelement		("panel")
					.name			("MyPanel")
					.width			(300, 200)
					.borderstyle	(Bros.bsEdit)
					.color			(Bros.clWhite)
					.halign			("left")
					.valign			("top")
					.scrollbars		("both")
					.wraptext		(false)
					.selectable		(! false)
					.align			("client")
					.parent			()
				.createelement		("tmeter")
					.name			("MyTMeter")
			;


		//---------------------------------------------------------------------------
		// Test Strings
		//---------------------------------------------------------------------------

		function Test_String()
			{
			//	deb					("App_TestElements - Test_String");
			var Str					= "A�����\xC3\xA9A";
			// Unterminated string constant below
			//	var Str				= String.fromCharCode(0xE1, 0xE9, 0xed, 0xF3, 0xFA, "�".charCodeAt(0));
			deb						(Str);
			for (var i = 0; i < Str.length; i++)
				{
				deb					(i, Str.charAt(i), Str.charCodeAt(i), Str.charCodeAt(i).toString(16));
				}
			};

		//---------------------------------------------------------------------------
		// Test JSON
		//---------------------------------------------------------------------------

		function Test_JSON()
			{
			//	deb					("App_TestElements - Test_JSON");
			//	Test_String			();
			//	return;

		//	var StrToTest_1			= GetStrToTest();
		//	//	deb					("StrToTest.length = " + StrToTest.length);
		//	//	deb					("StrToTest = " + StrToTest);
		//	var StrToTest_2			= Bros.Str_ToHexStr(StrToTest_1);
		//	//	deb					("StrToTest.length = " + StrToTest.length);
		//	//	deb					("StrToTest = " + StrToTest);

			// Setup
			var BrosRequest			=
					{
					 "Dest"			: "TestJSON"
					,"Method"		: "Test"
					,"iBoolValue"	:   false
					,"iIntValue"	: 73
					,"iNumValue"	: 69.6973
					,"iStringValue"	: "Andre Garcia"
				//	,"iStringValue2": "Andr� Garcia"
					,"iArrValue"	: [1, 2.69, "Andre", new Date(), (new Date()).toString()]
					,"iObjValue"	: {"Name":"Andre", "Age": 56}
					,"iArrObjValue"	: [{"Name2":"Andre", "Age": 56}, {"Name":"Cy", "Age": 40}]
					,"iDateValue"	: new Date(1958, 9, 14, 12, 34, 56, 789)
				//	,"iStrToTest_1"	: StrToTest_1
				//	,"iStrToTest_2"	: StrToTest_2
				//	,"iStrToTest_2"	: "7b2244657374223a22546573744a534f4e222c224d6574686f64223a2254657374222c2269426f6f6c56616c7565223a66616c73652c2269496e7456616c7565223a37332c22694e756d56616c7565223a36392e363937332c2269537472696e6756616c7565223a22416e64726520476172636961222c2269537472696e6756616c756532223a22416e647220476172636961222c226941727256616c7565223a5b312c322e36392c22416e647265222c22323031352d30352d30395430333a30333a35352e3533395a222c22536174204d617920303920323031352030303a30333a353520474d542d30333030225d2c22694f626a56616c7565223a7b224e616d65223a22416e647265222c22416765223a35367d2c22694172724f626a56616c7565223a5b7b224e616d6532223a22416e647265222c22416765223a35367d2c7b224e616d65223a224379222c22416765223a34307d5d2c22694461746556616c7565223a22313935382d31302d31345431353a33343a35362e3738395a222c2242726f73486561646572223a2242726f7352657175657374227d"
				//	,"iStrToTest_2"	: "7b2244657374223a22546573744a534f4e222c224d6574686f64223a2254657374222c2269426f6f6c56616c7565223a66616c73652c2269496e7456616c7565223a37332c22694e756d56616c7565223a36392e363937332c2269537472696e6756616c7565223a22416e64726520476172636961222c226941727256616c7565223a5b312c322e36392c22416e647265222c22323031352d30352d30395430333a31343a35302e3036355a222c22536174204d617920303920323031352030303a31343a353020474d542d30333030225d2c22694f626a56616c7565223a7b224e616d65223a22416e647265222c22416765223a35367d2c22694172724f626a56616c7565223a5b7b224e616d6532223a22416e647265222c22416765223a35367d2c7b224e616d65223a224379222c22416765223a34307d5d2c22694461746556616c7565223a22313935382d31302d31345431353a33343a35362e3738395a222c2242726f73486561646572223a2242726f7352657175657374227d"
					};

			// Sends Request
			Bros.element("MyTMeter").start();
			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
				{
				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
				deb					("Test_JSON RESPONSE");
				PCS					(BrosResponse);
				//	PCS				(BrosResponse.rObjValue);
				Bros.SCom.FatalError(BrosResponse);
				});
			Bros.element("MyTMeter").lap("ajax");
			};

		//---------------------------------------------------------------------------
		// GetStringToTest
		//---------------------------------------------------------------------------

		function GetStrToTest()
			{
			//	deb					("App_TestElements - GetStrToTest");
			var Result				= [];
			for (var i = 1; i <= 1; i++)
				{
			//	for (var j = 0; j <= 255; j++)
				for (var j = 0x00; j <= 0x7F; j++)
					{
					Result.push		(String.fromCharCode(j));
					}
				}
			return Result.join("");
			};

		//---------------------------------------------------------------------------
		// Test Img
		//---------------------------------------------------------------------------

		function Test_Img()
			{
			//	deb					("App_TestElements - Test_Img");

			// Setup
			var BrosRequest			=
					{
					 "Dest"			: "ImageLoader"
					,"Method"		: "GET"
					,"FileName"		: "Test.jpg"
					};
			var URL					= Bros.SCom.GetURL(BrosRequest);
			//	deb					("URL = " + URL);

		//	// Sends Request
		//	//	Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
		//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
		//		{
		//		//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
		//		deb					("Test_Img RESPONSE");
		//		PCS					(BrosResponse);
		//		Bros.SCom.FatalError(BrosResponse);
		//		});
		//	Bros.element("MyTMeter").lap("ajax");

			Bros.element("MyPanel").html('<img src="' + URL + '" alt="Image created by a PHP script" >');
			Bros.RW						('<img src="' + URL + '" alt="Image created by a PHP script" >');
			};

		//---------------------------------------------------------------------------
		// DoSearch
		//---------------------------------------------------------------------------

		function DoSearch()
			{
			//	deb					("App_TestElements - DoSearch");

			// Analize
			var ToSearch			= Bros.element("MyEdit").value();
			//	deb					("ToSearch = [" + ToSearch + "]");
			if (ToSearch == "")
				{
				Bros.element("MyPanel").html("");
				return;
				}

			// Setup
			var BrosRequest			=
					{
					 "Dest"			: "MyContacts"
					,"Method"		: "Search"
					,"ToSearch"		: ToSearch
					};

			// Sends Request
			Bros.element("MyTMeter").start();
			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
				{
				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
				//	deb				("RESPONSE");
				//	PCS				(BrosResponse);
				//	deb				(BrosResponse.SelectResult);
				Bros.SCom.FatalError(BrosResponse);
				Bros.element("MyPanel").html(BrosResponse.SelectResult);
				});
			Bros.element("MyTMeter").lap("ajax");
			};

		//---------------------------------------------------------------------------
		// Test FS
		//---------------------------------------------------------------------------

		function Test_FS()
			{
			//	deb					("App_TestElements - Test_FS");

			// Setup
			var BrosRequest			=
					{
					 Dest			: "BrosFS"
					,Method			: "FileRead"
					,FileName		: "Calculator"
					};

			// Sends Request
			Bros.element("MyTMeter").start();
			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
				{
				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
				//	deb				("Test_FS RESPONSE");
				//	PCS				(BrosResponse);
				Bros.SCom.FatalError(BrosResponse);

				Bros.elementpush	();
				Bros.element		(Bros.MainElement);
				var e				= Bros.RunScriptAsApp(BrosResponse.FileContent);
				Bros.elementpop		();
				if (e != null)
					Bros.FatalErrorMNO("Bros.App_TestElements !", "Error:<br>" + Bros.GetErrorDescription(e));

				});
			Bros.element("MyTMeter").lap("ajax");
			}

		//---------------------------------------------------------------------------
		// FS Write
		//---------------------------------------------------------------------------

		function FS_Write()
			{
			//	deb					("App_TestElements - FS_Write");

			// Setup
			var BrosRequest			=
					{
					 Dest			: "BrosFS"
					,Method			: "FileWrite"
					,FullFileName	: "B:/Dados\\Teste /Test 1.jpg.cocoxixi.txt"
//,FullFileName	: "B:\\Dados\\Teste /Test 1aa"
					,FileContent	: "My first wrasdasdite file\r\nLet\"s s'e''e !!!a"
					};

			// Sends Request
			Bros.element("MyTMeter").start();
			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
				{
				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
				deb					("FS_Write RESPONSE");
				PCS					(BrosResponse);
				Bros.SCom.FatalError(BrosResponse);
				});
			Bros.element("MyTMeter").lap("ajax");
			}

		//---------------------------------------------------------------------------
		// FS Read
		//---------------------------------------------------------------------------

		function FS_Read()
			{
			//	deb					("App_TestElements - FS_Read");

			// Setup
			var BrosRequest			=
					{
					 Dest			: "BrosFS"
					,Method			: "FileRead"
					,FullFileName	: "B:\\Dados\\Teste /Test 1.jpg.cocoxixi.Txt"
					};

			// Sends Request
			Bros.element("MyTMeter").start();
			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
				{
				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
				deb					("FS_Read RESPONSE");
				PCS					(BrosResponse);
				Bros.SCom.FatalError(BrosResponse);
				deb					("<pre>" + BrosResponse.FileContent + "</pre>");
				});
			Bros.element("MyTMeter").lap("ajax");
			}

//		//---------------------------------------------------------------------------
//		// FS Read
//		//---------------------------------------------------------------------------
//
//		function FS_Read()
//			{
//deb					("App_TestElements - FS_Read");
//
//			// Setup
//			var BrosRequest			=
//					{
//					 Dest			: "BrosFS"
//					,Method			: "FileRead"
//					,FileName		: "Calculator"
//					};
//
//			// Sends Request
//			Bros.element("MyTMeter").start();
//			//	Bros.SCom.SendGetRequest	(BrosRequest, function (BrosResponse)
//			Bros.SCom.SendRequest	(BrosRequest, function (BrosResponse)
//				{
//				//	Bros.element	("MyTMeter").lap("Success").pause().deblaps();
//				//	deb				("Test_FS RESPONSE");
//				//	PCS				(BrosResponse);
//				Bros.SCom.FatalError(BrosResponse);
//
//				Bros.elementpush	();
//				Bros.element		(Bros.MainElement);
//				var e				= Bros.RunScriptAsApp(BrosResponse.FileContent);
//				Bros.elementpop		();
//				if (e != null)
//					Bros.FatalErrorMNO("Bros.App_TestElements !", "Error:<br>" + Bros.GetErrorDescription(e));
//
//				});
//			Bros.element("MyTMeter").lap("ajax");
//			}

	//	//---------------------------------------------------------------------------
	//	// Show String
	//	//---------------------------------------------------------------------------
	//
	//	function ShowString(Str)
	//		{
	//		//	deb					("App_TestElements - ShowString", Str.length, Str);
	//		for (var i = 0; i < Str.length; i++)
	//			{
	//			var CA				= Str.charAt(i);
	//			var CC				= Str.charCodeAt(i);
	//			deb					(i, CA, CC);
	//			}
	//		};
	//
	//	//---------------------------------------------------------------------------
	//	// Convert String ANSI to UTF-8
	//	//---------------------------------------------------------------------------
	//
	//	function Str_ANSI2UTF8(Str)
	//		{
	//		//	deb					("App_TestElements - Str_ANSI2UTF8", Str.length, Str);
	//
	//		// http://en.wikipedia.org/wiki/UTF-8
	//
	//		// � 0xE9	110xxxxx 	10xxxxxx
	//		//			11000011 	10101001	C3 A9
	//
	//		//---------------------------------------------------------------------------
	//		//  Caracteres obtidos pela exibi��o em um								192	Caractres ANSI
	//		//	 Memo e transportados para c�.											32 Caractres Inv�lidos
	//		//   	0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F			32 Caractres de controle
	//		//
	//		//	0	---	SOH	STX	ETX	EOT	ENQ ACK	BEL	BS	HT	LF	VT	FF	CR	SO	SI			16
	//		//	1	DLE DC1 DC2	DC3	DC4	NAK	SYN	ETB	CAN	EM	SUB	ESC	FS	GS	RS	US			16
	//		//																					Observa��es:
	//		//	0	--	^A	^B	^C	^D	^E	^F	^G	^H	^I	^J	^K	^L	^M
	//	^N	^O				sequ�ncia control+Letra
	//		//	1	^P	^Q	^R	^S	^T	^U	^V	^W	^X	^Y	^Z	^[	^\	^]	^^	^_	
	//		//
	//		//	2		!	"	#	$	%	&	'	(	)	*	+	,	-	.	/	16			considerando-se o espa�o
	//		//	3	0	1	2	3	4	5	6	7	8	9	:	;	<	=	>	?	16
	//		//	4	@	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	16
	//		//	5	P	Q	R	S	T	U	V	W	X	Y	Z	[	\	]	^	_	16
	//		//	6	`	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	16
	//		//	7	p	q	r	s	t	u	v	w	x	y	z	{	|	}	~	---	15	01
	//		//
	//		//	8	�	---	�	�	�	�	�	�	�	�	�	�	�	---	---	---		16		82-8C n�o � exibido no Memo
	//		//	9	---	�	�	�	�	�	�	�	�	�	�	�	�	---	---	�	02	14		93-9F n�o � exibido no Memo
	//		//																						note que � aparece s� aqui mas o AnsiUpperCase() o gera !
	//		//	A	---	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	15	01		A0 aparentemente gera espa�o
	//		//	B	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	16
	//		//
	//		//	C	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	16
	//		//	D	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	16
	//		//	E	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	16
	//		//	F	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	�	16
	//		//
	//		//   	0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F
	//		//---------------------------------------------------------------------------
	//		//		0123456789ABCDEF	0123456789ABCDEF
	//		//
	//		//	2	 !"#$%&'()*+,-./	0123456789:;<=>?
	//		//	4	@ABCDEFGHIJKLMNO	PQRSTUVWXYZ[\]^_	mai�sculas
	//		//	6	`abcdefghijklmno	pqrstuvwxyz{|}~		min�sculas
	//		//	8	� �����������   	 ������������  �
	//		//	A	 ���������������	����������������
	//		//	C	����������������	����������������	mai�sculas
	//		//	E	����������������	����������������	min�sculas
	//		//---------------------------------------------------------------------------
	//		//		0123456789ABCDEF	0123456789ABCDEF	0123456789ABCDEF	0123456789ABCDEF
	//		//
	//		//	2	 !"#$%&'()*+,-./	0123456789:;<=>?	
	//		//	4	@ABCDEFGHIJKLMNO	PQRSTUVWXYZ[\]^_	`abcdefghijklmno	pqrstuvwxyz{|}~ 
	//		//	8	� �����������   	 ������������  �	 ���������������	����������������
	//		//	C	����������������	����������������	����������������	����������������
	//		//---------------------------------------------------------------------------
	//		var Arr					= Str.split("");
	//		var Res					= [];
	//		//	deb					("Arr.length = " + Arr.length, "Str.length = " + Str.length);
	//		for (var i = 0; i < Arr.length; i++)
	//			{
	//			var CA				= Str.charAt(i);
	//			var CC				= Str.charCodeAt(i);
	//			deb					(i, CA, CC);
	//			}
	//		return "Coco";
	//		};
	//
	//	function encode_utf8(s)
	//		{
	//		return unescape(encodeURIComponent(s));
	//		}
	//
	//	function decode_utf8(s)
	//		{
	//		return decodeURIComponent(escape(s));
	//		}
	//
	//	//	http://snipplr.com/view/52975/
	//	function d2h(d)
	//		{
	//		return d.toString(16);
	//		}
	//	function h2d (h)
	//		{
	//		return parseInt(h, 16);
	//		}
	//	function stringToHex (tmp)
	//		{
	//		var str = '',
	//		i = 0,
	//		tmp_len = tmp.length,
	//		c;
    // 
	//		for (; i < tmp_len; i += 1)
	//			{
	//			c = tmp.charCodeAt(i);
	//			str += d2h(c) + ' ';
	//			}
	//		return str;
	//		}
	//	function hexToString (tmp)
	//		{
	//		var arr = tmp.split(' '),
	//		str = '',
	//		i = 0,
	//		arr_len = arr.length,
	//		c;
    // 
	//		for (; i < arr_len; i += 1)
	//			{
	//			c = String.fromCharCode( h2d( arr[i] ) );
	//			str += c;
	//			}
	//		return str;
	//		}

		//---------------------------------------------------------------------------
		// TestPHP
		//---------------------------------------------------------------------------

		//	TestPHP					();
		function TestPHP()
			{
			//	deb					("App_TestElements - TestPHP");
			//	deb(window.location);
			//	PCS(window.location);
			//	PCS(Bros);
			var Dados				=
					{
					 palavra		: "S"
					};
			var URL					= "Bros_Z_Estudos_PHP.php";
			//	Bros.element("MyPanel").html('<img src="' + URL + '" alt="Image created by a PHP script" >');
			//	deb							('<img src="' + URL + '" alt="Image created by a PHP script" >');
			Bros.element("MyTMeter").start();
			$.post(URL, Dados, function (Retorna)
				{
				Bros.element("MyTMeter").lap("Success").pause().deblaps();
				//	Bros.element("MyPanel").html("" + Retorna);
				Bros.RW				("<hr><pre>" + Retorna + "</pre>");
			//	Bros.RW				("<hr><pre>" + Retorna.length + "</pre>");
			//	Bros.RW				("<hr>" + Retorna);
				});
			};

//		});

//###########################################################################
//###########################################################################
