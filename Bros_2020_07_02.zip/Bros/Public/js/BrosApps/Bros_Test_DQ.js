//###########################################################################
//###########################################################################

		// Global Tables
		var DTab_Priorities, QTab_Priorities, DTab_Agenda, DTab_MyContacts, QTabRelevance, QTabAgenda, QTabActivities;

		// Creates the Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// DebugCount
		var DebugCount				= 10;

		// What to Build ?
		AppC.MainMenu.Build			= ! false;
		AppC.ButtonsPanel.Build		= ! false;
		AppC.StatusPanel.Build		=   false;
//AppC.MainMenu.Build			=   false;
//AppC.ButtonsPanel.Build		=   false;

		// Window Caption
		APPC.windowcaption			(AppC, "Bros Test DQ");

		// Define IP (IP = ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_TextEditor/";

		// Define Here your Main Menu
		APPC.addmenufolder			(AppC, "Main");
			APPC.addmenuitemreload	(AppC);//.Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, "Relevance",			IP + "Img_0030_File_Open.png",		"",	Show_Relevances)		.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, "Agenda",			IP + "Img_0030_File_Open.png",		"",	Show_Agenda)			.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore",   false);
			APPC.addmenuitem		(AppC, "Activities",		IP + "Img_0030_File_Open.png",		"",	Show_Activities)		.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore",   false);
			APPC.endmenufolder		(AppC);

		// Define Here your Status Panel
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Now, everything will be created automatically for you
		APPC.createall				(AppC);

		// Create Here your application elements
		Bros
			.createelement			("panel")
				.name				("MyHostPanel")
				.align				("client")
				.borderstyle		(Bros.bsNone)
				.createelement		("panel")
					.name			("MyHostPanelA")
//					.align			("client")
					//	.color		("FF0000")
					.borderstyle	(Bros.bsNone)
//					.borderstyle	(Bros.bsEdit)
					.parent			()
				.createelement		("panel")
					.name			("MyHostPanelB")
//					.align			("client")
					//	.color		("FF0000")
					.borderstyle	(Bros.bsNone)
//					.borderstyle	(Bros.bsEdit)
					.parent			()
				.createelement		("panel")
					.name			("MyHostPanelC")
//					.align			("client")
					//	.color		("FF0000")
					.borderstyle	(Bros.bsNone)
//					.borderstyle	(Bros.bsEdit)
					.parent			()
				.parent				()
			;

	//	// This Method (Event indeed) will be called if this application is opened and you shut down and the returned value will be saved for the next sign-in
	//	APPC.ongetappargs(AppC, function ()
	//		{
	//		return "Something that make sense for this application";
	//		});
	//
	//	// Here you will get the value saved in APPC.ongetappargs above and you can do something with the AppArgs
	//	var AppArgs					= APPC.getappargs(AppC);
	//	//	deb						("AppArgs = " + AppArgs);
	//	if (AppC.StatusPanel.Build)
	//		Bros.element("MyStatusPanelInfo").html("&nbsp;" + AppArgs);

//Menu_Priorities();
//Test_MyContacts();
Test_Relevance();

Show_Relevances();
//Show_Agenda();
//Show_Activities();

	//===========================================================================
	//===========================================================================
	//==
	//== Config Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Config MyContacts
	//---------------------------------------------------------------------------

	function Config_MC()
		{
		//	deb						("Config_MC");
		var DTab;
		//	return;

		// Setup Table
		DTab_MyContacts				= Bros.Lib.DTab.GetNew("B:/A/MyTest_MC.csv", "Test");
		DTab						= DTab_MyContacts;
		Bros.Lib.DTab
		//.Set					(DTab, "Name",							"B:/A/MyTest_MC.csvA")
			.Set					(DTab, "Caption",						"MyCaption")
		//	.Set					(DTab, "FS_CSV_Delimiter",				":")
		//	.Set					(DTab, "FS_CSV_FirstLineIsHeader",		  false)
		//	.Set					(DTab, "FS_CSV_SecondLineIsColTypes",	  false)
		//	.Set					(DTab, "FS_CSV_LineTerminator",			"LT")
			//
			.AddColumn				(DTab, "BMC_NAME",		"C",  80,  0, "NN", Bros.Msg.WRD.Name)
			.AddColumn				(DTab, "BMC_PHONE1",	"C",  80,  0, "NV", Bros.Msg.WRD.Phone + " 1")
			.AddColumn				(DTab, "BMC_PHONE2",	"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 2")
			.AddColumn				(DTab, "BMC_PHONE3",	"C",  80,  0, "VN", Bros.Msg.WRD.Phone + " 3")
			.AddColumn				(DTab, "BMC_PHONE4",	"C",  80,  0, "VV", Bros.Msg.WRD.Phone + " 4")
			.AddColumn				(DTab, "BMC_PHONE5",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 5")
			.AddColumn				(DTab, "BMC_EMAIL1",	"C",  80,  0, "VE", Bros.Msg.WRD.EMail + " 1")
			.AddColumn				(DTab, "BMC_EMAIL2",	"C",  80,  0, "VE", Bros.Msg.WRD.EMail + " 2")
			.AddColumn				(DTab, "BMC_BIRTHDAY",	"D",  80,  0, "VE", Bros.Msg.WRD.Birthday)

.AddColumn				(DTab, "Bmca_PHONE2",	"C",  80,  0, "NE", Bros.Msg.WRD.Phone + " 2")

			;
//PCS						(DTab, ! false, ! false);
//		//	PCS						(DTab, ! false);
		};

	//---------------------------------------------------------------------------
	// Config All
	//---------------------------------------------------------------------------

	function Config_All()
		{
		//	deb						("Config_All");
		var DTab, QTab;

		// DTab_Priorities
		DTab_Priorities				= Bros.Lib.DTab.GetNew("B:/A/MyTest.csv", "Test");
		DTab						= DTab_Priorities;
		Bros.Lib.DTab
		//	.Set					(DTab, "Name",			"B:/A/MyTest.csv")
			.Set					(DTab, "Caption",		"Priorities")
		//	.Set					(DTab, "FS_CSV_Delimiter",				"XXX")
		//	.Set					(DTab, "FS_CSV_FirstLineIsHeader",		  false)
		//	.Set					(DTab, "FS_CSV_SecondLineIsColTypes",	  false)
		//	.Set					(DTab, "FS_CSV_LineTerminator",			"LT")
			//
			.AddColumn				(DTab, "ID",			"I",  80,  0, "NN", "ID")
			.AddColumn				(DTab, "IDDM",			"I",  80,  0, "NN", "IDDM")
			.AddColumn				(DTab, "IDGLOB",		"I",  80,  0, "NN", "IDGLOB")
			.AddColumn				(DTab, "DLTD",			"C",  80,  0, "NN", "DLTD")
			.AddColumn				(DTab, "ENBD",			"C",  80,  0, "NN", "ENBD")
			//
			.AddColumn				(DTab, "MYCHARS",		"C",  80,  0, "VE", "Description")
			.AddColumn				(DTab, "MYINT",			"I",  80,  0, "VE", "My Int")
			.AddColumn				(DTab, "MYNUM",			"N",  80,  0, "VE", "My Number")
			.AddColumn				(DTab, "MYDATE",		"D",  80,  0, "VE", "My Date")
			.AddColumn				(DTab, "MYMEMO",		"M",  80,  0, "VE", "My Memo")

.AddColumn				(DTab, "AB_33B",		"C",  80,  0, "VE", "Description 2")
.AddColumn				(DTab, "MyaDATE",		"D",  80,  0, "VE", "My Date 2")
			;
		//	PCS						(DTab, ! false, ! false);
		//	PCS						(DTab, ! false);

//	PCS						(DTab, ! false, ! false);

		// Setup Query
		QTab_Priorities				= Bros.Lib.QTab.GetNew(DTab);
		QTab						= QTab_Priorities;
		Bros.Lib.QTab
			.Set					(QTab, "HostPanelName",			"MyHostPanelA")
			;
		//	PCS						(QTab);
		//	PCS						(QTab, ! false);

		
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Menu Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu Priorities
	//---------------------------------------------------------------------------

	function Menu_Priorities()
		{
		//	deb						("Menu_Priorities");
		//	return;
		var DTab, QTab;

		// Config All
		Config_All					();
		DTab						= DTab_Priorities;

	//	Config_MC					();
	//	DTab						= DTab_MyContacts;

		//	PCS						(DTab, ! false, ! false);

		//
	//	Bros.Lib.DTab.Exists			(DTab, function (ErrorMsg, TableExists)
	//		{
	//		//	deb					("ErrorMsg = " + ErrorMsg, "TableExists = " + TableExists);
	//		if (Bros.lib.dlg.didshowerror(ErrorMsg))
	//			return;
	//		deb						("TableExists = " + TableExists);
	//		});

	//	Bros.Lib.DTab.LoadAll		(DTab, function (ErrorMsg)
	//		{
	//		//	deb					("LoadAll, ErrorMsg = " + ErrorMsg);
	//		if (Bros.lib.dlg.didshowerror(ErrorMsg))
	//			return;
	//		//	PCS					(DTab);
	//			Bros.Lib.DTab.Show	(DTab);
	//
	//	//	Bros.Lib.DTab.Commit	(DTab, function (ErrorMsg)
	//	//		{
	//	//		if (Bros.lib.dlg.didshowerror(ErrorMsg))
	//	//			return;
	//	//		deb					("Table Commited");
	//	//		});
	//		});


Bros.element("MyHostPanelA").deletechildren();

		QTab						= QTab_Priorities;
//QTab.PanelControl.Align = "top";
//		Bros.Lib.QTab.EditRecord	(QTab);

		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
			{
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
deb					("Bros.Lib.QTab.ShowSelection DONE !");
			});
		}

	//---------------------------------------------------------------------------
	// Test MyContacts
	//---------------------------------------------------------------------------

	function Test_MyContacts()
		{
deb						("Test_MyContacts");
		//	return;

		// Setup Table
		var DTab					= Bros.Lib.DTab.GetNew("B:/A/MyContacts_Test.csv", "Test");
		Bros.Lib.DTab
		//	.Set					(DTab, "Name",							"B:/A/MyTest_MC.csvA")
			.Set					(DTab, "Caption",						"MyCaption")
		//	.Set					(DTab, "FS_CSV_Delimiter",				":")
		//	.Set					(DTab, "FS_CSV_FirstLineIsHeader",		  false)
		//	.Set					(DTab, "FS_CSV_SecondLineIsColTypes",	  false)
		//	.Set					(DTab, "FS_CSV_LineTerminator",			"LT")
			//
			.AddControlColumns		(DTab)
			//
			.AddColumn				(DTab, "BMC_NAME",		"C",  80,  0, "VE", Bros.Msg.WRD.Name)
			.AddColumn				(DTab, "BMC_PHONE1",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 1")
			.AddColumn				(DTab, "BMC_PHONE2",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 2")
			.AddColumn				(DTab, "BMC_PHONE3",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 3")
			.AddColumn				(DTab, "BMC_PHONE4",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 4")
			.AddColumn				(DTab, "BMC_PHONE5",	"C",  80,  0, "VE", Bros.Msg.WRD.Phone + " 5")
			.AddColumn				(DTab, "BMC_EMAIL1",	"C",  80,  0, "VE", Bros.Msg.WRD.EMail + " 1")
			.AddColumn				(DTab, "BMC_EMAIL2",	"C",  80,  0, "VE", Bros.Msg.WRD.EMail + " 2")
			.AddColumn				(DTab, "BMC_BIRTHDAY",	"D",   8,  0, "VE", Bros.Msg.WRD.Birthday)

			.AddColumn				(DTab, "MYCHARS2",		"C",  80,  0, "VE", "My Chars2")

			.AddColumn				(DTab, "MYCHARS",		"C",  80,  0, "VE", "My Chars")
			.AddColumn				(DTab, "MYMEMO",		"M",  80,  0, "VE", "My Memo")
			.AddColumn				(DTab, "MYINT",			"I",  11,  0, "VE", "My Int")
			.AddColumn				(DTab, "MYNUM",			"N",  80,  0, "VE", "My Number")
			.AddColumn				(DTab, "MYDATE",		"D",   8,  0, "VE", "My Datekashdlkashdlksadh")

			;
		//	PCS						(DTab);
		//	PCS						(DTab, ! false);
		//	PCS						(DTab, ! false, ! false);

		// Setup Query
		var QTab					= Bros.Lib.QTab.GetNew(DTab);
		Bros.Lib.QTab
			.Set					(QTab, "HostPanelName",			"MyHostPanelA")
			;

		// Run Query
//		Bros.Lib.QTab.EditRecord	(QTab, 2, function (ErrorMsg)
//		Bros.Lib.QTab.ShowRecord	(QTab, 2, function (ErrorMsg)
		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
			{
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
deb					("Test_MyContacts ShowSelection DONE !");
			});

		}

	//---------------------------------------------------------------------------
	// Show Relevances
	//---------------------------------------------------------------------------

	function Show_Relevances()
		{
		//	deb						("Show_Relevances");
		var Effect					= "auto";
		var Effect					= "bottom";
		var Effect					= "none";
		Bros.Lib.Elem.SelectPanel	("MyHostPanelA", Effect);

		// Run Query
		var QTab					= QTabRelevance;
		if (QTab.DidShow)
			return;
		QTab.DidShow				= ! false;
		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
			{
			//	deb					("Test_Relevance ShowSelection DONE !", ErrorMsg);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			//	deb					("Test_Relevance ShowSelection DONE !");
			});
		};

	//---------------------------------------------------------------------------
	// Show Agenda
	//---------------------------------------------------------------------------

	function Show_Agenda()
		{
		//	deb						("Show_Agenda");
		var Effect					= "auto";
		var Effect					= "top";
		var Effect					= "none";
		Bros.Lib.Elem.SelectPanel	("MyHostPanelB", Effect);

		// Run Query
		var QTab					= QTabAgenda;
		if (QTab.DidShow)
			return;
		QTab.DidShow				= ! false;
		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
			{
			//	deb					("Test_Relevance ShowSelection DONE !", ErrorMsg);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			//	deb					("Test_Relevance ShowSelection DONE !");
			});
		};

	//---------------------------------------------------------------------------
	// Show Activities
	//---------------------------------------------------------------------------

	function Show_Activities()
		{
		//	deb						("Show_Activities");
		var Effect					= "auto";
		var Effect					= "top";
		var Effect					= "none";
		Bros.Lib.Elem.SelectPanel	("MyHostPanelC", Effect);

		// Run Query
		var QTab					= QTabActivities;
		if (QTab.DidShow)
			return;
		QTab.DidShow				= ! false;
		Bros.Lib.QTab.ShowSelection	(QTab, function (ErrorMsg)
			{
			//	deb					("Test_Relevance ShowSelection DONE !", ErrorMsg);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			//	deb					("Test_Relevance ShowSelection DONE !");
			});
		};

	//---------------------------------------------------------------------------
	// Test Relevance
	//---------------------------------------------------------------------------

	function Test_Relevance()
		{
		//	deb						("Test_Relevance");
		//	return;

		//---------------------------------------------------------------------------
		// Relevance
		//---------------------------------------------------------------------------

		// Setup Table
		var DTabRelevance			= Bros.Lib.DTab.GetNew("B:/A/AA_1_Relevance.csv", "Relevances");
		var DTab					= DTabRelevance;
		Bros.Lib.DTab
			//	.Set				(DTab, "Caption",						"MyCaption")
			//	.Set				(DTab, "SkipSaveData",					! false)
			//	.Set				(DTab, "CreateTableIfNotExists",		  false)
			//
			.AddControlColumns		(DTab)
				.Set				(DTab, "Column",		"ID")									.Set(DTab, "RelatedTabShow",	! false)
				.Set				(DTab, "Column",		"ENBD")							//		.Set(DTab, "VisibleInSheet",	! false)
			//
			.AddColumn				(DTab, "SEQ",			"C",  80,  0, "VE", "Sequence")	  		.Set(DTab, "RelatedTabShow",	! false)//	.Set(DTab, "InitialValue", "9999")		//.Set(DTab, "Enabled",	false)
			.AddColumn				(DTab, "DESCR",			"C",  80,  0, "VE", "Description")		.Set(DTab, "RelatedTabShow",	! false)
			.AddColumn				(DTab, "COLOR",			"C",   6,  0, "VE", "Color")			.Set(DTab, "LogicalType",		"color")
			.AddColumn				(DTab, "TEST",			"C",   1,  0, "VE", "Test")				.Set(DTab, "LogicalType",		"boolean")	.Set(DTab, "InitialValue", "S")
			.AddColumn				(DTab, "OBS",			"C", 240,  4, "NE", "Observations")

			.AddColumn				(DTab, "MYCHARS",		"C",  80,  0, "NE", "My Chars")
			.AddColumn				(DTab, "MYMEMO",		"M",  80,  0, "NE", "My Memo")
			.AddColumn				(DTab, "MYINT",			"I",  11,  0, "NE", "My Int")
			.AddColumn				(DTab, "MYNUM",			"N",  80,  0, "NE", "My Number")
			.AddColumn				(DTab, "MYDATEA",		"D",   8,  0, "VE", "My Date A")		.Set(DTab, "InitialValue", new Date(1958, 9, 14, 9, 13, 37, 321))	.Set(DTab, "DateFormat", Bros.User.Pref.DateTimeFormat)
			.AddColumn				(DTab, "MYDATEB",		"D",   8,  0, "VE", "My Date B")
			;

		// Setup Query
		QTabRelevance				= Bros.Lib.QTab.GetNew(DTab);
		var QTab					= QTabRelevance;
		Bros.Lib.QTab
			.Set					(QTab, "HostPanelName",	"MyHostPanelA")
			;

//		//---------------------------------------------------------------------------
//		// Agenda
//		//---------------------------------------------------------------------------
//
//		// Setup Table
//		var DTabAgenda				= Bros.Lib.DTab.GetNew("B:/A/AA_2_Agenda.csv", "Agenda");
//		var DTab					= DTabAgenda;
//		Bros.Lib.DTab
//			//	.Set				(DTab, "Caption",						"MyCaption")
//			//	.Set				(DTab, "SkipSaveData",					! false)
//			//	.Set				(DTab, "CreateTableIfNotExists",		  false)
//			//
//			.AddControlColumns		(DTab)
//			//
//			.AddColumn				(DTab, "DATEEMI",		"D",   8,  0, "VE", "Emission Date")
//			.AddColumn				(DTab, "DATEAGE",		"D",   8,  0, "VE", "Agenda Date")
//			.AddColumn				(DTab, "IDRELEV",		"I",  11,  0, "VE", "Relevance")		.Set(DTab, "RelatedTab",		DTabRelevance)
//			.AddColumn				(DTab, "FINISHED",		"C",   1,  0, "VE", "Finished ?")		.Set(DTab, "LogicalType",		"boolean")	.Set(DTab, "InitialValue", "N")
//			.AddColumn				(DTab, "SUMMARY",		"C",  80,  0, "VE", "Sumary")			.Set(DTab, "RejectBlank",		! false)
//			.AddColumn				(DTab, "HISTORIC",		"M",  80,  0, "NE", "Historic")
//			;
//		// Setup Query
//		QTabAgenda					= Bros.Lib.QTab.GetNew(DTab);
//		var QTab					= QTabAgenda;
//		Bros.Lib.QTab
//			.Set					(QTab, "HostPanelName",	"MyHostPanelB")
//			;
//		//	PCS						(DTab, ! false, ! false);
//
//		//---------------------------------------------------------------------------
//		// Activities
//		//---------------------------------------------------------------------------
//
//		// Setup Table
//		var DTabActivities			= Bros.Lib.DTab.GetNew("B:/A/AA_3_Activities.csv", "Activities");
//		var DTab					= DTabActivities;
//		Bros.Lib.DTab
//			//	.Set				(DTab, "Caption",						"MyCaption")
//			//	.Set				(DTab, "SkipSaveData",					! false)
//			//	.Set				(DTab, "CreateTableIfNotExists",		  false)
//			//
//			.AddControlColumns		(DTab)
//			//
//			.AddColumn				(DTab, "IDAUTO",		"I",  11,  0, "VE", "Auto ID")			.Set(DTab, "RelatedTab",	DTabActivities)	// DTabRelevance	DTabActivities
//			.AddColumn				(DTab, "IDRELEV1",		"I",  11,  0, "VE", "Relevance 1")		.Set(DTab, "RelatedTab",	DTabRelevance)
//			.AddColumn				(DTab, "IDRELEV2",		"I",  11,  0, "VE", "Relevance 2")		.Set(DTab, "RelatedTab",	DTabRelevance)
//			.AddColumn				(DTab, "IDAGENDA",		"I",  11,  0, "VE", "Agenda")			.Set(DTab, "RelatedTab",	DTabAgenda)
//			.AddColumn				(DTab, "SUMMARY",		"C",  80,  0, "VE", "Sumary")			.Set(DTab, "RelatedTabShow", ! false)
//			;
//		// Setup Query
//		QTabActivities				= Bros.Lib.QTab.GetNew(DTab);
//		var QTab					= QTabActivities;
//		Bros.Lib.QTab
//			.Set					(QTab, "HostPanelName",	"MyHostPanelC")
//			;
//		//	PCS						(DTab, ! false, ! false);
		}

//###########################################################################
//###########################################################################
