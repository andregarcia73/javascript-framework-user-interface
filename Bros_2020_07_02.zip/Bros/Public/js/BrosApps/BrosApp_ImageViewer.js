//###########################################################################
//###########################################################################
//##
//## Bros Application - Image Viewer
//##
//###########################################################################
//###########################################################################

		//---------------------------------------------------------------------------
		// Globals
		//---------------------------------------------------------------------------

		var FilesToShow				= [];
		var FilesToShow_Index		= 0;

		var FullFileNameSelected	= "";

		var StrWidthHeight			= "";
		var StrWidthHeight_Error	= " (??? x ???)";

		var OffsetZoom				= 0.95;							// To best apply Zoom (to not show scrollbars)

		//---------------------------------------------------------------------------
		// Application Controller
		//---------------------------------------------------------------------------

		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);

		// Files Under Edition
		var EditFiles				= [];
		var Current_EditFile		= null;
		var NoNameIndex				= 1;

		// Configure and create
		Config_AppC					();
		Create_Window				();

		// For Testing
		//	ProcessFullFileName		("ReadOnly_Bros:/img/Icons/_32/Icon_BrosApp_Calculator.gif");

		// Process AppArgs
		var AppArgs					= APPC.getappargs(AppC);
		//	deb						("AppArgs = " + AppArgs);
		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
		//	AppArgs					= '"B:/Data/AAA.js" "B:/Config.sys" "B:/Config2.sys"';
		AppArgs_Process				(AppArgs);

	//===========================================================================
	//===========================================================================
	//==
	//== Configuration Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Config AppC
	//---------------------------------------------------------------------------

	function Config_AppC()
		{
		//	deb						("Config_AppC");

		// Setup AppArgs
		AppArgs_Setup				();

		// For Testing
		//	AppC.Window.Build		=   false;
		//	AppC.MainMenu.Build		=   false;
		//	AppC.ButtonsPanel.Build	=   false;
		//	AppC.StatusPanel.Build	=   false;

		// Window
		AppC.Window.Caption			= Bros.Msg.IMV.Window_Caption;

		// StatusPanel.SubPanels
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Define IP (ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_ImageViewer/";
		//	var IP					= "ReadOnly_Bros:/img/BrosApps/BrosApp_ImageViewer/";

		// MenuItems
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.File);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Open,		IP + "Img_0010_File_Open.png",				"Ctrl+O",	Menu_File_Open)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore",   false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.First,		IP + "Img_0020_Show_First.png",				"",			Menu_Show_First)			.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Previous,	IP + "Img_0030_Show_Previous.png",			"",			Menu_Show_Previous)			.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Next,		IP + "Img_0040_Show_Next.png",				"",			Menu_Show_Next)				.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Last,		IP + "Img_0050_Show_Last.png",				"",			Menu_Show_Last)				.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Print,		IP + "Img_0060_File_Print.png",				"Ctrl+P",	Menu_File_Print)			.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Exit,		IP + "Img_0070_File_Exit.png",				"Alt+F4",	Menu_File_Exit)				.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);
		if (Bros.IsInDebug)
			{
			APPC.addmenufolder		(AppC, Bros.Msg.WRD.Tools);
				APPC.addmenuitemreload(AppC);//.Set("ShowMenuSpaceBefore", ! false);
				APPC.endmenufolder	(AppC);
			}
		//APPC.addmenufolder		(AppC, Bros.Msg.WRD.Tools);
		//	APPC.addmenuitem		(AppC, Bros.Msg.WRD.Options,	IP + "Img_1010_Tools_Options.png",			"",			Menu_Tools_Options)			//.Set("ShowButton", ! false);
		//	APPC.endmenufolder		(AppC);

		//	PCS						(AppC, ! false);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== AppArgs Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Setup AppArgs
	//---------------------------------------------------------------------------

	function AppArgs_Setup()
		{
		//	deb						("AppArgs_Setup");
		// Method to save params on ShutDown
		APPC.ongetappargs(AppC, function ()
			{
			//	deb					("APPC.ongetappargs");
			return "\"" + FullFileNameSelected + "\"";
			});
		}

	//---------------------------------------------------------------------------
	// Process AppArgs
	//---------------------------------------------------------------------------

	function AppArgs_Process(AppArgs)
		{
		//	deb						("AppArgs_Process", "AppArgs = [" + AppArgs + "]");

		// Setup
		var FullFileName			= AppArgs;
		if (FullFileName == "")
			return;

		// Extracts first and last chars
		FullFileName				= FullFileName.substr(0, FullFileName.length - 1);
		FullFileName				= FullFileName.substr(1, FullFileName.length - 1);
		//	deb						("FullFileName = " + FullFileName);
		if (FullFileName == "")
			return;

		// Process
		ProcessFullFileName			(FullFileName);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Creators Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Window
	//---------------------------------------------------------------------------

	function Create_Window()
		{
		//	deb						("Create_Window");
		APPC.createall				(AppC);
		//	PCS						(AppC, ! false);
		Complement_MainWindow		();
		}

	//---------------------------------------------------------------------------
	// Complement Main Window
	//---------------------------------------------------------------------------

	function Complement_MainWindow()
		{
		//	deb						("Complement_MainWindow");
		Bros
			.createelement			("panel")
				.align				("client")
				.name				("MyPanel")
				.borderstyle		(Bros.bsEdit)
				.color				(Bros.clWhite)
				.createelement		("image")
					.name			("MyImageDummy")
					.align			("client")
					.borderstyle	(Bros.bsNone)
					.scrollbars		("both")
					.visible		(false)
				.createelement		("image")
					.name			("MyImage")
					.align			("client")
					.borderstyle	(Bros.bsNone)
					.scrollbars		("both")
				.parent				()
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Menu/Buttons Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_File_Open
	//---------------------------------------------------------------------------

	function Menu_File_Open()
		{
		//	deb						("Menu_File_Open");
		Bros.lib.dlg.fileopen(function (ErrorMsg, FullFileName)
			{
			//	deb					("Bros.lib.dlg.fileopen", ErrorMsg, FullFileName);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			if (FullFileName == "")
				return;
			ProcessFullFileName		(FullFileName);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_File_Print
	//---------------------------------------------------------------------------

	function Menu_File_Print()
		{
		//	deb						("Menu_File_Print");
		Bros.element				("MyImage").print();
		}

	//---------------------------------------------------------------------------
	// Menu_File_Exit
	//---------------------------------------------------------------------------

	function Menu_File_Exit()
		{
		//	deb						("Menu_File_Exit");
		Bros.element(APPC.windowname(AppC)).close();
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Update Status Panel
	//---------------------------------------------------------------------------

	function UpdateStatusPanel(IsLoading)
		{
		//	deb						("UpdateStatusPanel", FilesToShow_Index);

		// Builded ?
		if (! AppC.StatusPanel.Build)
			return;

		// Define
		var ToShow					= "";
		if (FilesToShow.length > 0)
			{
			ToShow					= "&nbsp;" + (FilesToShow_Index + 1) + "/" + FilesToShow.length + ": " + FilesToShow[FilesToShow_Index];
			if (IsLoading)
				ToShow			   += ", " + Bros.Msg.WRD.Loading + "...";
			}

		// Show
		Bros
			.element				("MyStatusPanelInfo")
				.html				(ToShow + StrWidthHeight)
			;
		}

	//---------------------------------------------------------------------------
	// Reset Viewer
	//---------------------------------------------------------------------------

	function ResetViewer()
		{
		//	deb						("ResetViewer");
		FilesToShow					= [];
		FilesToShow_Index			= 0;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Process Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Process FullFileName
	//---------------------------------------------------------------------------

	function ProcessFullFileName(FullFileName)
		{
		//	deb						("ProcessFullFileName", FullFileName);

		// Store
		FullFileNameSelected		= FullFileName;

		// Reset Viewer
		ResetViewer					();

		// Gets Dir
		var Dir						= Bros.FS.GetDir(FullFileName);
		//	deb						("Dir = " + Dir);

		// Gets Dir Files
		Bros.lib.fs.getfilefolders(Dir, function(ErrorMsg, FFs)	// FFs = Result FileFolderInfo
			{
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			// Stores
			//	deb				("FFs.length = " + FFs.length);
			for (var i = 0; i < FFs.length; i++)
				{
				var FF				= FFs[i];
				//	deb				(i, FF.FullFileName);
				FilesToShow.push(FF.FullFileName);
				}

			// Sort
			Bros.lib.arr.sort		(FilesToShow);

			// For Testing
			//	deb					("FilesToShow.length = " + FilesToShow.length);
			//	for (var i = 0; i < FilesToShow.length; i++)
			//		deb				(i, FilesToShow[i]);

			// Sets the initial Index
			FilesToShow_Index		= Bros.lib.arr.findindex(FilesToShow, FullFileName);
			//	deb					("FilesToShow_Index = " + FilesToShow_Index);
			if (FilesToShow_Index	< 0)
				FilesToShow_Index	= 0;
			FilesToShow_Index--;

			// Show Next
			Menu_Show_Next			();
			});
		};

	//---------------------------------------------------------------------------
	// Menu Show Next
	//---------------------------------------------------------------------------

	function Menu_Show_Next()
		{
		//	deb					("Menu_Show_Next", "FilesToShow.length = " + FilesToShow.length, "FilesToShow_Index = " + FilesToShow_Index);
		if (FilesToShow.length == 0)
			return;
		FilesToShow_Index++;
		if (FilesToShow_Index  >= FilesToShow.length)
			FilesToShow_Index	= 0;
		// Update Image
		Update_Image			();
		}

	//---------------------------------------------------------------------------
	// Menu Show Previous
	//---------------------------------------------------------------------------

	function Menu_Show_Previous()
		{
		//	deb						("ShowPrevious", "FilesToShow.length = " + FilesToShow.length, "FilesToShow_Index = " + FilesToShow_Index);
		if (FilesToShow.length == 0)
			return;
		FilesToShow_Index--;
		if (FilesToShow_Index   < 0)
			FilesToShow_Index	= FilesToShow.length - 1;
		// Update Image
		Update_Image			();
		}

	//---------------------------------------------------------------------------
	// Menu Show First
	//---------------------------------------------------------------------------

	function Menu_Show_First()
		{
		//	deb						("Menu_Show_First");
		FilesToShow_Index			= -1;
		Menu_Show_Next				();
		}

	//---------------------------------------------------------------------------
	// Menu Show Last
	//---------------------------------------------------------------------------

	function Menu_Show_Last()
		{
		//	deb						("Menu_Show_Last");
		FilesToShow_Index			= 0;
		Menu_Show_Previous			();
		}

	//---------------------------------------------------------------------------
	// Update Image
	//---------------------------------------------------------------------------

	function Update_Image()
		{
		//	deb						("Update_Image");
		//	var H					= Bros.element("MyPanel").height() - 30;
		//	deb						(Bros.element("MyImage").imageheight(H));

		// Define and Store
		var FullFileName			= FilesToShow[FilesToShow_Index];
		FullFileNameSelected		= FullFileName;

		// StatusPanel
		StrWidthHeight				= "";
		UpdateStatusPanel			(true);							// IsLoading = true

		// Load into MyImageDummy
		Bros.element("MyImageDummy").imagesrc("file:" + FullFileName).onload(function (Elem, e, Success)
			{
			//	deb					("MyImageDummy onload, Success = " + Success);
			if (! Success)
				{
				Bros.element		("MyImage").imagesrc("").onload(null);	// Clear the image
				StrWidthHeight		= StrWidthHeight_Error;
				UpdateStatusPanel	(false);						// IsLoading = false
				return;
				}

			// Get Values to analyze Zoom
			Bros.element			("MyPanel");
			var PanelWidth			= Bros.width();
			var PanelHeight			= Bros.height();
			//
			Bros.element			("MyImageDummy");
			var ImageWidth			= Bros.imagewidth();
			var ImageHeight			= Bros.imageheight();
			var GetImageWidth		= Bros.getimagewidth();
			var GetImageHeight		= Bros.getimageheight();

			// Define
			var ToApply_ImageWidth	= -1;
			var ToApply_ImageHeight	= -1;
			var StrZoom				= "";
			//	deb					(PanelWidth, PanelHeight, ImageWidth, ImageHeight, GetImageWidth, GetImageHeight);
			if ((GetImageWidth > PanelWidth) || (GetImageHeight > PanelHeight))
				{
				//	deb				(PanelWidth, PanelHeight, ImageWidth, ImageHeight, GetImageWidth, GetImageHeight);

				// Calculates minimum necessary Zoom
				var Zoom_W			= 1;
				if (GetImageWidth	> 0)
					Zoom_W			= PanelWidth  / GetImageWidth;
				var Zoom_H			= 1;
				if (GetImageHeight	> 0)
					Zoom_H			= PanelHeight / GetImageHeight;
				var Zoom			= Zoom_W;
				if (Zoom			> Zoom_H)
					Zoom			= Zoom_H;
				Zoom				= Zoom * OffsetZoom;
				//	deb				(Zoom, Zoom_W, Zoom_H);

				// StrZoom
				StrZoom				= " (Zoom = " + Math.round(Zoom * 100) + "%)";

				// Apply
				ToApply_ImageWidth	= Math.round(Zoom * GetImageWidth);
				ToApply_ImageHeight	= Math.round(Zoom * GetImageHeight);
				}

			// Define StrWidthHeight
			StrWidthHeight			= " (" + GetImageWidth + " x " + GetImageHeight + ")" + StrZoom;

			// Apply to MyImage
			Bros.element			("MyImage");
			Bros.imagesrc			("");										// Avoid the below twice fired event
			Bros.imagewidth			(ToApply_ImageWidth, ToApply_ImageHeight);	// Fires below onload twice
			Bros.imagesrc			("file:" + FullFileName).onload(function (Elem, e, Success)
				{
				//	deb				("MyImage onload, Success = " + Success);
				if (! Success)
					StrWidthHeight	= StrWidthHeight_Error;
				UpdateStatusPanel	(false);						// IsLoading = false
				});

			});
		}

//###########################################################################
//###########################################################################
