//###########################################################################
//###########################################################################
//##
//## Bros Application - My App
//##
//###########################################################################
//###########################################################################

function obMyApp()
	{
	//---------------------------------------------------------------------------
	// BuildWindow
	//---------------------------------------------------------------------------

	this.BuildWindow = function BuildWindow()
		{
		//	deb						("obMyApp.BuildWindow");
		var This					= this;
		var PanelMsgs;
		Bros
			.createelement			("window")
				.onready			(function (Elem)
					{
					This.ElemMyWin	= Elem;
					})
				.left				(5, 5, 680, 550)
				.caption			("New Project")
				.onclose			(function (Elem)
					{
					// Put here your event handler script
					// deb("window.onclose");
					})
				.onfocus			(function (Elem)
					{
					// Put here your event handler script
					// deb("window.onfocus");
					})
				.createelement		("panel")
					.left			(0, 0, 672, 32)
					.borderstyle	(Bros.bsNone)
					.align			("top")
					.createelement	("button")
						.left		(0, 0, 72, 32)
						.caption	("Clear Msgs")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							Bros.ClearMsgsContainer();
							})
					.createelement	("button")
						.left		(72, 0, 72, 32)
						.caption	("Reload")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							This.Reload();
							})
					.createelement	("button")
						.left		(144, 0, 72, 32)
						.caption	("button 3")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							// Put here your event handler script
							deb		("button 3 onclick");
							})
					.createelement	("button")
						.left		(216, 0, 72, 32)
						.caption	("button 4")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							// Put here your event handler script
							deb		("button 4 onclick");
							})
					.createelement	("button")
						.left		(288, 0, 72, 32)
						.caption	("button 5")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							// Put here your event handler script
							deb		("button 5 onclick");
							})
					.createelement	("button")
						.left		(360, 0, 72, 32)
						.caption	("button 6")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							// Put here your event handler script
							deb		("button 6 onclick");
							})
					.createelement	("button")
						.left		(432, 0, 72, 32)
						.caption	("button 7")
						.align		("left")
						.onclick	(function (Elem, e)
							{
							// Put here your event handler script
							deb		("button 7 onclick");
							})
					.parent			()
				.createelement		("selectorpanels")
					.left			(0, 32, 672, 60)
					.borderstyle	(Bros.bsNone)
					.align			("top")
					.addparentitem	("Panel A")
						.parentitem	()
					.addparentitem	("Panel B")
						.parentitem	()
					.onchange		(function (Elem)
						{
						// Put here your event handler script
						// deb("selectorpanels.onchange");
						})
					.parent			()
				.createelement		("splitter")
					.height			(4)
					.align			("top")
					.borderstyle	(Bros.bsNone)
				.createelement		("panel")
					.left			(0, 148, 672, 104)
					.align			("client")
					.borderstyle	(Bros.bsNone)
					.onready		(function (Elem)
						{
						PanelMsgs	= Elem;
						})
					.parent				()
				.parent				()
			;

		// Messages
		Bros.BuildMsgsContainer		(PanelMsgs);
		};

	//---------------------------------------------------------------------------
	// Hello
	//---------------------------------------------------------------------------

	this.Hello = function Hello()
		{
		//	deb						("obMyApp.Hello");
		var ToShow					= [];
		ToShow.push					("");
		ToShow.push					("Hi, I'm Andre Garcia from Sao Paulo - Brazil");
		ToShow.push					("andre.garcia73@gmail.com");
		ToShow.push					("+55 (11) 99128-1479 (mobile/whatsapp)");
		ToShow.push					("");
		ToShow.push					("This is Bros (Browser Operational System)");
		ToShow.push					("http://www.xpnet.com.br");
		ToShow.push					("http://andregarcia73.ddns.net:65009/Bros");
		ToShow.push					("");
		ToShow.push					("You can use it as a javascript UI (User Interface) for free !");
		ToShow.push					("");
		ToShow.push					("Edit the file .../Bros/Public/js/BrosApps/BrosApp_MyApp.js");
		ToShow.push					("and press Reload button above");
		ToShow.push					("");
		ToShow.push					("Edit the file .../Bros/Bros.html");
		ToShow.push					("and Reload this page (F5)");
		ToShow.push					("");
		ToShow.push					("Use the Bros Application Builder to build new Apps or User Interfaces.");
		ToShow.push					("Use the Bros Application Learning Center (Hello World) to learn more about Bros.");
		ToShow.push					("");
		ToShow.push					("Source code of Bros is available in .../Bros/_js/ZB_Bros.js");
		ToShow.push					("");
		ToShow.push					("Ask me for feedbacks or help.");
		ToShow.push					("");
		ToShow.push					("Enjoy !");
		ToShow.push					("");
		deb							(ToShow.join("<br>"));
		};

	//---------------------------------------------------------------------------
	// Reload this Application
	//---------------------------------------------------------------------------

	this.Reload = function Reload()
		{
		//	deb						("obMyApp.Reload");

		// Builds the AppParams
		var Bobj					= this.ElemMyWin;
		var W						= Bobj;			// For elegance
		var AppParams				= {WinPos:[W.Left, W.Top, W.Width, W.Height]};
		//	deb						(AppParams.WinPos);

		// Close the window
		Bros.element(Bobj).close();

		// Run again
		Bros.RunApplication			("BrosApp_MyApp", AppParams);
		};

	};	// function obMyApp()

//###########################################################################
//###########################################################################
//##
//## Main Program
//##
//###########################################################################
//###########################################################################

		var MyApp				= new obMyApp();
		MyApp.BuildWindow		();
		MyApp.Hello				();

//###########################################################################
//###########################################################################
