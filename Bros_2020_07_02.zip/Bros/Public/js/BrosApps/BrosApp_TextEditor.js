//###########################################################################
//###########################################################################
//##
//## Bros Application - Text Editor
//##
//###########################################################################
//###########################################################################

		//	deb						("BrosApp_TextEditor");

		// Application Controller
		var APPC					= Bros.lib.appc;				// For Elegance
		var AppC					= APPC.getnew(Application);
		//	PCS						(AppC, ! false);

		// Files Under Edition
		var EditFiles				= [];
		var Current_EditFile		= null;
		var NoNameIndex				= 1;

		// Configure and create
		Config_AppC					();
		Create_Window				();

		// Process AppArgs
		var AppArgs					= APPC.getappargs(AppC);
		//	deb						("AppArgs = " + AppArgs);
		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
		//	AppArgs					= ' asdasd  "B:/Data/AAA.js" aaa "B:/Config.sys" "Dropbox:/Dados700/Config_2.sys" "B:/Config2.sys"';
		//	AppArgs					= '"B:/Data/AAA.js" "B:/Config.sys" "B:/Config2.sys"';
		AppArgs_Process				(AppArgs);

	//===========================================================================
	//===========================================================================
	//==
	//== Configuration Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Config AppC
	//---------------------------------------------------------------------------

	function Config_AppC()
		{
		//	deb						("Config_AppC");

		// For Testing
		//	AppC.Window.Build		=   false;
		//	AppC.MainMenu.Build		=   false;
		//	AppC.ButtonsPanel.Build	=   false;
		//	AppC.StatusPanel.Build	=   false;

		// Window
		AppC.Window.Caption			= Bros.Msg.TXE.Window_Caption;

		// Method to save params on ShutDown
		APPC.ongetappargs(AppC, function ()
			{
			//	deb					("APPC.ongetappargs");
			var AppArgs				= "";
			var IsFirst				= ! false;
			for (var i = 0; i < EditFiles.length; i++)
				{
				var EditFile		= EditFiles[i];
				//	PCS				(EditFile);
				// Does not include files that NeedToSaveAs (File New ... wihout saving yet)
				if (EditFile.NeedToSaveAs)
					continue;
				if (! IsFirst)
					AppArgs		   += " ";
				IsFirst				=   false;
				AppArgs			   += "\"" + EditFile.FullFileName + "\"";
				}
			return AppArgs;
			});

		// StatusPanel.SubPanels
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelCol",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Col: 99,999");
		//	APPC.addstatuspanel		(AppC, "MyStatusPanelRow",		60)				;//	.Set("HAlign", "center")	.Set("HTML", APPC.GambPanelSpace + "Row: 99,999");
		APPC.addstatuspanel			(AppC, "MyStatusPanelInfo",		10, "client")	;//								.Set("HTML", APPC.GambPanelSpace + "MyStatusPanelInfo");

		// Define IP (ImgPath)
		var IP						= Bros.URL_Path_Img_Bros_Prg + "BrosApp_TextEditor/";

		// MenuItems
		APPC.addmenufolder			(AppC, Bros.Msg.WRD.File);
			APPC.addmenufolder		(AppC, Bros.Msg.WRD.New);
				APPC.addmenuitem	(AppC, Bros.Msg.PHR.NormalText,	IP + "Img_0010_File_New_Text.png",			"",			Menu_File_New_NormalText)	.Set("ShowButton", ! false);
				APPC.addmenuitem	(AppC, Bros.Msg.WRD.Application,IP + "Img_0020_File_New_Application.png",	"",			Menu_File_New_Application)	.Set("ShowButton", ! false);
				APPC.endmenufolder	(AppC);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Open,		IP + "Img_0030_File_Open.png",				"Ctrl+O",	Menu_File_Open)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Close,		IP + "Img_0040_File_Close.png",				"",			Menu_File_Close)			.Set("ShowButton",   false);
			APPC.addmenuitem		(AppC, Bros.Msg.PHR.CloseAll,	IP + "Img_0050_File_CloseAll.png",			"",			Menu_File_CloseAll)			.Set("ShowButton",   false);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Save,		IP + "Img_0060_File_Save.png",				"Ctrl+S",	Menu_File_Save)				.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.PHR.SaveAll,	IP + "Img_0070_File_SaveAll.png",			"",			Menu_File_SaveAll)			.Set("ShowButton", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.PHR.SaveAs,		IP + "Img_0080_File_SaveAs.png",			"",			Menu_File_SaveAs)			.Set("ShowButton",   false);
			APPC.addmenuitem		(AppC, Bros.Msg.VRB.Print,		IP + "Img_0090_File_Print.png",				"Ctrl+P",	Menu_File_Print)			.Set("ShowButton", ! false).Set("ShowMenuSpaceBefore", ! false);
			APPC.addmenuitem		(AppC, Bros.Msg.WRD.Exit,		IP + "Img_0100_File_Exit.png",				"Alt+F4",	Menu_File_Exit)				.Set("ShowButton",   false).Set("ShowMenuSpaceBefore", ! false);
			APPC.endmenufolder		(AppC);
		if (Bros.IsInDebug)
			{
			APPC.addmenufolder		(AppC, Bros.Msg.WRD.Tools);
				APPC.addmenuitemreload(AppC);//.Set("ShowMenuSpaceBefore", ! false);
				APPC.endmenufolder	(AppC);
			}
		//APPC.addmenufolder		(AppC, Bros.Msg.WRD.Tools);
		//	APPC.addmenuitem		(AppC, Bros.Msg.WRD.Options,	IP + "Img_1010_Tools_Options.png",			"",			Menu_Tools_Options)			//.Set("ShowButton", ! false);
		//	APPC.endmenufolder		(AppC);

		//	PCS						(AppC, ! false);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Creators Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Create Window
	//---------------------------------------------------------------------------

	function Create_Window()
		{
		//	deb						("Create_Window");
		APPC.createall				(AppC);
		//	PCS						(AppC, ! false);
		Complement_MainWindow		();
		}

	//---------------------------------------------------------------------------
	// Complement Main Window
	//---------------------------------------------------------------------------

	function Complement_MainWindow()
		{
		//	deb						("Complement_MainWindow");
		Bros
			// Selector Panels
			.createelement			("selectorpanels")
				.name				("MySelectorPanels")
				//	.color			("FF0000")
				.align				("client")
				.alignment			("bottom")
				.borderstyle		(Bros.bsEdit)
				.onready			(function (Elem)
					{
					if (Bros.lib.sys.isonmobile())
						Bros.element(Elem.Selector).height(0);
					})
				.onchange			(function (Elem, e)
					{
					//	deb			("You select the Panel " + Bros.selected());
					// Set EditFile under edition by SelectedIndex
					Editor_SelectIndex(Bros.selected());
					})
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== AppArgs Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Process AppArgs
	//---------------------------------------------------------------------------

	function AppArgs_Process(AppArgs)
		{
		//	deb						("AppArgs_Process", "AppArgs = " + AppArgs);

		// Extracts Files to Open
		var FilesToOpen				= [];
		var RigthContext			= AppArgs;
		while (true)
			{
			// Executes
			//	deb					("RigthContext = " + RigthContext);
			var RE					= /\"([^\"]*)\"/gi;
			var Result				= RE.exec(RigthContext);
			//	deb					("Result = " + Result);

			// Found ?
			if (Result == null)
				break;

			// Pushes FullFileName found
			FilesToOpen.push		(RegExp.$1);

			// Redefine RigthContext
			RigthContext			= RegExp.rightContext;

			//	Bros.RE_ShowRegExp	();
			//	break;
			}

		// Load all files
		//	deb						("FilesToOpen.length = " + FilesToOpen.length);
		//	for (var i = 0; i < FilesToOpen.length; i++)
		//		deb					(i + 1, FilesToOpen[i]);
		Load_Files					(FilesToOpen, 0);
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Menu/Buttons Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Menu_File_New_NormalText
	//---------------------------------------------------------------------------

	function Menu_File_New_NormalText()
		{
		//	deb						("Menu_File_New_NormalText");

		// Get New Edit File
		var EditFile				= EditFile_GetNew();
		EditFile.NeedToSaveAs		= ! false;
		EditFile.IsApplication		=   false;
		//	PCS						(EditFile);

		// Adds Edit File to Editor
		Editor_AddEditFile			(EditFile);
		}

	//---------------------------------------------------------------------------
	// Menu_File_New_Application
	//---------------------------------------------------------------------------

	function Menu_File_New_Application()
		{
		//	deb						("Menu_File_New_Application");

		// Get New Edit File
		var EditFile				= EditFile_GetNew();
		EditFile.NeedToSaveAs		= ! false;
		EditFile.IsApplication		= ! false;
		//	PCS						(EditFile);

		// Adds Edit File to Editor
		Editor_AddEditFile			(EditFile);

		//	PCS						(EditFile);
		var FullFileName			= Bros.URL_Public_Js_BApps + Bros.BrosFilName_AppEmpty;
		//	deb						("FullFileName = " + FullFileName);

		// Load
		Bros.lib.fs.read			(FullFileName, function (ErrorMsg, FileContent)
			{
			//	deb					("ErrorMsg", ErrorMsg, FileContent);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			// Update
			Bros.element			(EditFile.EditAreaName).text(FileContent);

			// Update again, becauser, after filling OnChange will be fired showing (*)
			EditFile_UpdateChanged	(EditFile,   false);	// Changed =   false
			});

		}

	//---------------------------------------------------------------------------
	// Menu_File_Open
	//---------------------------------------------------------------------------

	function Menu_File_Open()
		{
		//	deb						("Menu_File_Open");
		Bros.lib.dlg.fileopen(function (ErrorMsg, FullFileName)
			{
			//	deb					("Bros.lib.dlg.fileopen", ErrorMsg, FullFileName);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			if (FullFileName == "")
				return;
			// Already Openned ?
			var EditFile			= EditFile_Find(FullFileName);
			if (EditFile != null)
				{
				Editor_SelectIndex	(EditFile.Index);
				return;
				}
			Load					(FullFileName);
			});
		}

	//---------------------------------------------------------------------------
	// Menu_File_Close
	//---------------------------------------------------------------------------

	function Menu_File_Close()
		{
		//	deb						("Menu_File_Close");
		// Removes Current Edit File from Editor
		EditFile_Close				(Current_EditFile);
		}

	//---------------------------------------------------------------------------
	// Menu_File_CloseAll
	//---------------------------------------------------------------------------

	function Menu_File_CloseAll()
		{
		//	deb						("Menu_File_CloseAll");
		// Scans in inverse order
		EditFile_CloseAll			(EditFiles.length - 1);
		}

	//---------------------------------------------------------------------------
	// Menu_File_Save
	//---------------------------------------------------------------------------

	function Menu_File_Save()
		{
		//	deb						("Menu_File_Save");
		//	PCS						(Current_EditFile);
		Save						(Current_EditFile);
		}

	//---------------------------------------------------------------------------
	// Menu_File_SaveAll
	//---------------------------------------------------------------------------

	function Menu_File_SaveAll()
		{
		//	deb						("Menu_File_SaveAll");
		// Scans in inverse order
		EditFile_SaveAll			(EditFiles.length - 1);
		}

	//---------------------------------------------------------------------------
	// Menu_File_SaveAs
	//---------------------------------------------------------------------------

	function Menu_File_SaveAs()
		{
		//	deb						("Menu_File_SaveAs");
		SaveAs						(Current_EditFile);
		}

	//---------------------------------------------------------------------------
	// Menu_File_Print
	//---------------------------------------------------------------------------

	function Menu_File_Print()
		{
		//	deb						("Menu_File_Print", Current_EditFile);
		Print						(Current_EditFile);
		}

	//---------------------------------------------------------------------------
	// Print
	//---------------------------------------------------------------------------

	function Print(EditFile)
		{
		//	deb						("Print", EditFile);

		// Have ?
		if (EditFile == null)
			return;
		//	PCS						(EditFile);
		//	deb						(Bros.element(EditFile.EditAreaName).value());

		// Print
		//	Bros.element			(AppC.Window.Name).print();		// For testing
		Bros.element				(EditFile.EditAreaName).print();
		}

	//---------------------------------------------------------------------------
	// Menu_File_Exit
	//---------------------------------------------------------------------------

	function Menu_File_Exit()
		{
		//	deb						("Menu_File_Exit");
		Bros.element(APPC.windowname(AppC)).close();
		}

	//---------------------------------------------------------------------------
	// Menu_Tools_Options
	//---------------------------------------------------------------------------
	//
	//function Menu_Tools_Options()
	//	{
	//	//	deb						("Menu_Tools_Options");
	//	}

	//===========================================================================
	//===========================================================================
	//==
	//== EditFiles Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Get New Edit File
	//---------------------------------------------------------------------------

	function EditFile_GetNew()
		{
		//	deb						("EditFile_GetNew");

		// Builds
		var EditFile				= {
			 Index					: EditFiles.length
			,DisplayName			: "NoName" + NoNameIndex
			,FullFileName			: "NoName" + NoNameIndex++
			,EditAreaName			: ""
			,NeedToSaveAs			:   false
			,IsApplication			: ! false
			,Changed				:   false
			};

		// Stores
		EditFiles.push				(EditFile);

		// Returns
		return EditFile;
		}

	//---------------------------------------------------------------------------
	// Updates EditFile Props
	//---------------------------------------------------------------------------

	function EditFile_UpdateProps(EditFile)
		{
		//	deb						("EditFile_UpdateProps");

		// Define DisplayName
		var RE						= /[\/\\][^\/\\]*$/gi;
		var R						= RE.exec(EditFile.FullFileName);
		//	PCS						(R);
		if (R != null)
			EditFile.DisplayName	= EditFile.FullFileName.substr(R.index + 1, EditFile.FullFileName.length - R.index - 1);
		//	deb						("EditFile.DisplayName = [" + EditFile.DisplayName + "]");
		//	PCS						(EditFile);
		}

	//---------------------------------------------------------------------------
	// Update Changed
	//---------------------------------------------------------------------------

	function EditFile_UpdateChanged(EditFile, Changed)
		{
		//	deb						("EditFile_UpdateChanged", Changed);
		//	PCS						(EditFile);

		// Same Changed ?
		if (EditFile.Changed == Changed)
			return;
		//	PCS						(EditFile);

		// Change
		EditFile.Changed			= Changed;

		// Update things !
		Editor_SelectIndex			(EditFile.Index);
		}

	//---------------------------------------------------------------------------
	// Finds an EditFile from FullFileName
	//---------------------------------------------------------------------------

	function EditFile_Find(FullFileName)
		{
		//	deb						("EditFile_Find", FullFileName);
		FullFileName				= FullFileName.toLowerCase();
		var EditFile				= Bros.lib.arr.search(EditFiles, function (i, EF)
			{
			return (FullFileName == EF.FullFileName.toLowerCase());
			});
		return EditFile;
		}

	//---------------------------------------------------------------------------
	// Closes Edit File from Editor
	//---------------------------------------------------------------------------

	function EditFile_Close(EditFile, OnResult)
		{
		//	deb								("EditFile_Close", "EditFile.Changed = " + EditFile.Changed);
		if (EditFile.Changed)
			{
			Bros.lib.dlg.showconfirm(Bros.Msg.TXE.FileNotSavedCloseIt, function (Confirm)
				{
				//	deb						("Confirm = " + Confirm);
				if (! Confirm)
					{
					Bros.lib.sys.runonresult(OnResult, "", false);	// Closed =   false
					return;
					}
				Editor_RemEditFile			(EditFile);
				Bros.lib.sys.runonresult	(OnResult, "", ! false);	// Closed = ! false
				})
			return;
			}
		Editor_RemEditFile					(EditFile);
		Bros.lib.sys.runonresult			(OnResult, "", ! false);	// Closed = ! false
		}

	//---------------------------------------------------------------------------
	// Closes all Edit Files from Editor
	//---------------------------------------------------------------------------

	function EditFile_CloseAll(Index)
		{
		//	deb						("EditFile_CloseAll", Index);

		// Have some ?
		if (EditFiles.length == 0)
			return;

		// Starts
		var EditFile				= EditFiles[Index];
		//	PCS						(EditFile);
		EditFile_Close				(EditFile, function (ErrorMsg, Closed)
			{
			//	deb					("Closed = " + Closed);
			// Back Index (closed or not
			var NewIndex			= Index - 1;

			// End of job ?
			if (NewIndex < 0)
				return;

			// Reenter
			EditFile_CloseAll		(NewIndex);
			});
		}

	//---------------------------------------------------------------------------
	// Saves all Edit Files from Editor
	//---------------------------------------------------------------------------

	function EditFile_SaveAll(Index)
		{
		//	deb						("EditFile_SaveAll", Index);

		// Have some ?
		if (EditFiles.length == 0)
			return;

		// Find next file to save
		var EditFile;
		while (Index >= 0)
			{
			//	deb					("Index = " + Index);
			EditFile				= EditFiles[Index];

			// Need to save ?
			if (EditFile.NeedToSaveAs || (! EditFile.Changed))
				{
				Index--;
				continue;
				}

			// Saves the Current_EditFile
			var LastEditFile		= Current_EditFile;

			// DoSave
			DoSave					(EditFile, function (ErrorMsg)
				{
				//	deb				("DoSave, ErrorMsg = " + ErrorMsg);

				// Restores the Current_EditFile and select it (because EditFile_SaveAll changes it)
				Current_EditFile	= LastEditFile;
				Editor_SelectEditFile(Current_EditFile);

				// Error ?
				if (Bros.lib.dlg.didshowerror(ErrorMsg))
					return;

				// Reenter
				EditFile_SaveAll	(Index - 1);
				});

			// Stops !
			break;
			}
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Auxiliary Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Update Status Panel
	//---------------------------------------------------------------------------

	function UpdateStatusPanel(EditFile)
		{
		//	deb						("UpdateStatusPanel", SelectedIndex);

		// Builded ?
		if (! AppC.StatusPanel.Build)
			return;

		// Define
		var ToShow					= "";
		if (EditFile != null)
			{
			ToShow					= APPC.GambPanelSpace + EditFile.FullFileName;
			//	ToShow			   += " (" + EditFile.DisplayName + ")";	// To verify if EditFile.DisplayNamewhile Bros does not update panel caption
			}

		// Show
		Bros
			.element				("MyStatusPanelInfo")
				.html				(ToShow)
			;
		}

	//===========================================================================
	//===========================================================================
	//==
	//== FileSystem Methods
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Load_Files
	//---------------------------------------------------------------------------

	function Load_Files(FilesToLoad, Index)
		{
		//	deb						("AppArgs_Process", "FilesToLoad.length = " + FilesToLoad.length, "Index = " + Index);

		// Ended
		if (Index > (FilesToLoad.length - 1))
			{
			// Select the first
			Editor_SelectIndex		(0);
			return;
			}

		// Loads
		Load						(FilesToLoad[Index], function (ErrorMsg)
			{
			//	deb					("ErrorMsg", ErrorMsg);
			// Reenter for the next file
			Load_Files				(FilesToLoad, Index + 1);
			});
		}

	//---------------------------------------------------------------------------
	// Load
	//---------------------------------------------------------------------------

	function Load(FullFileName, OnResult)
		{
		//	deb						("Load", FullFileName);
		//	return;
		Bros.lib.fs.read			(FullFileName, function (ErrorMsg, FileContent)
			{
			//	deb					("ErrorMsg", ErrorMsg, FileContent);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				{
				// Fires the event
				Bros.lib.sys.runonresult(OnResult, ErrorMsg);
				return;
				}

			// Get New Edit File
			var EditFile			= EditFile_GetNew();

			// Define
			EditFile.FullFileName	= FullFileName;

			// Adds Edit File to Editor
			Editor_AddEditFile		(EditFile);
			//	PCS					(EditFile);

			// Fills
			Bros.element			(EditFile.EditAreaName).value(FileContent);

			// Update again, becauser, after filling OnChange will be fired showing (*)
			EditFile_UpdateChanged	(EditFile,   false);	// Changed =   false

			// Fires the event
			Bros.lib.sys.runonresult(OnResult, "");
			});
		};

	//---------------------------------------------------------------------------
	// Save
	//---------------------------------------------------------------------------

	function Save(EditFile)
		{
		//	deb						("Save", EditFile);

		// Have ?
		if (EditFile == null)
			return;
		//	PCS						(EditFile);

		// NeedToSaveAs ?
		if (EditFile.NeedToSaveAs)
			{
			SaveAs					(EditFile);
			return;
			}

		// DoSave
		DoSave						(EditFile, function (ErrorMsg)
			{
			//	deb					("DoSave, ErrorMsg = " + ErrorMsg);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;

			// Show Success (no more because (*) inicates it)
			//	Bros.lib.dlg.showmsg(Bros.Msg.PHR.FileSaved);
			});
		}

	//---------------------------------------------------------------------------
	// DoSave
	//---------------------------------------------------------------------------

	function DoSave(EditFile, OnResult)
		{
		//	deb						("DoSave");
		//	PCS						(EditFile);

		// Get Values
		var FullFileName			= EditFile.FullFileName;
		var FileContent				= Bros.element(EditFile.EditAreaName).value();
		//	deb						("FullFileName = " + FullFileName, "FileContent = " + FileContent);

		// Writes
		Bros.lib.fs.write			(FullFileName, FileContent, function (ErrorMsg)
			{
			//	deb					("Bros.FS.Write, ErrorMsg = " + ErrorMsg);
			if (ErrorMsg == "")
				{
				EditFile.NeedToSaveAs=   false;
				EditFile_UpdateChanged(EditFile,   false);	// Changed =   false
				}
			Bros.lib.sys.runonresult(OnResult, ErrorMsg);
			});
		}

	//---------------------------------------------------------------------------
	// SaveAs
	//---------------------------------------------------------------------------

	function SaveAs(EditFile)
		{
		//	deb						("SaveAs", EditFile);

		// Have ?
		if (EditFile == null)
			return;
		//	PCS						(EditFile);

		// Get's Name
		Bros.lib.dlg.filesave(function (ErrorMsg, FullFileName)
			{
			//	deb					("Bros.lib.dlg.filesave", ErrorMsg, FullFileName);
			if (Bros.lib.dlg.didshowerror(ErrorMsg))
				return;
			if (FullFileName == "")
				return;
			//	deb					("Bros.lib.dlg.filesave", "FullFileName = " + FullFileName);

			// File exists ?
			Bros.lib.fs.exists(FullFileName, function(ErrorMsg, FF_Exists)
				{
				//	deb				("Bros.lib.dlg.exists", ErrorMsg, FF_Exists);
				if (Bros.lib.dlg.didshowerror(ErrorMsg))
					return;
				//	deb				("FF_Exists = " + FF_Exists);
				if (! FF_Exists)
					{
					DoSaveAs		(EditFile, FullFileName);
					return;
					}
				// Already Exists, ask for confirmation
				Bros.lib.dlg.showconfirm(Bros.Msg.TXE.FileAlreadyExistsOverwrite + "<p><b>" + FullFileName + "</b>", function(MyAnswerIsYes)
					{
					if (MyAnswerIsYes)
						DoSaveAs	(EditFile, FullFileName);
					});
				});
			});
		}

	//---------------------------------------------------------------------------
	// DoSaveAs
	//---------------------------------------------------------------------------

	function DoSaveAs(EditFile, FullFileName)
		{
		//	deb						("DoSaveAs", EditFile, FullFileName);

		// Saves the FullFileName (in case of error on saving)
		var LastFullFileName		= EditFile.FullFileName;
		EditFile.FullFileName		= FullFileName;
		DoSave						(EditFile, function (ErrorMsg)
			{
			//	deb					("DoSave, ErrorMsg = " + ErrorMsg);
			if (ErrorMsg != "")
				{
				//	PCS				(EditFile);
				EditFile.FullFileName = LastFullFileName;
				//	PCS				(EditFile);
				Bros.lib.dlg.showerror(ErrorMsg);
				return;
				}

			// Success !

			// Updates EditFile Props
			EditFile_UpdateProps	(EditFile);

			// Update things !
			Editor_SelectIndex		(EditFile.Index);

			// Show Success (no more because (*) inicates it)
			//	Bros.lib.dlg.showmsg(Bros.Msg.PHR.FileSaved);
			});
		}

	//===========================================================================
	//===========================================================================
	//==
	//== Methods for Editor
	//==
	//===========================================================================
	//===========================================================================

	//---------------------------------------------------------------------------
	// Set EditFile under edition by EditFile
	//---------------------------------------------------------------------------

	function Editor_SelectEditFile(EditFile)
		{
		//	deb						("Editor_SelectEditFile");
		if (EditFile == null)
			return;
		Editor_SelectIndex			(EditFile.Index);
		}

	//---------------------------------------------------------------------------
	// Set EditFile under edition by SelectedIndex
	//---------------------------------------------------------------------------

	function Editor_SelectIndex(SelectedIndex)
		{
		//	deb						("Editor_SelectIndex", "SelectedIndex = " + SelectedIndex, "EditFiles.length = " + EditFiles.length);
		//	return;

		// If Empty, clears Status Panel
		if (EditFiles.length == 0)
			{
			Current_EditFile		= null;
			UpdateStatusPanel		(Current_EditFile);
			return;
			}

		// Adjust (in case of Editor_RemEditFile)
		if (SelectedIndex			> (EditFiles.length - 1))
			SelectedIndex			= (EditFiles.length - 1);
		//	deb						("SelectedIndex = " + SelectedIndex, "EditFiles.length = " + EditFiles.length);

		// Defines Current_EditFile
		Current_EditFile			= EditFiles[SelectedIndex];

		// Update Selector Panels
		//	PCS						(Current_EditFile);
		var ToShow					= Current_EditFile.DisplayName;
		if (Current_EditFile.Changed)
			{
			ToShow				   += " (*)";
			//	ToShow				= "<font color='FF0000'>"	+ ToShow + "</font>";
			ToShow					= "<b>"						+ ToShow + "</b>";
			}
		//	deb						("XPTBUGASPECTUP - 01");
		Bros
			.element				("MySelectorPanels")
				.selected			(SelectedIndex)
				.caption			(ToShow)						// In case of changing via Save As OR changed something
			;

		// Set Focus
		Bros.element(Current_EditFile.EditAreaName).setfocus();

		// Update Status Panel
		UpdateStatusPanel			(Current_EditFile);
		}

	//---------------------------------------------------------------------------
	// Add Edit File to Editor
	//---------------------------------------------------------------------------

	function Editor_AddEditFile(EditFile)
		{
		//	deb						("Editor_AddEditFile");
		//	PCS						(EditFile);

		// Updates EditFile Props
		EditFile_UpdateProps		(EditFile);

		// Define 
		EditFile.EditAreaName		= "EditArea_" + Bros.lib.sys.getnewuniqueid();
		//	deb						("EditFile.EditAreaName = " + EditFile.EditAreaName);
		var SelectedIndex			= 0;

		// Update
		Bros
			.element				("MySelectorPanels")
			.addparentitem			(EditFile.DisplayName)
				.createelement		("editarea")
					.name			(EditFile.EditAreaName)
					//	.mode		(EditFile.IsApplication ? "codeeditor" : "texteditor")
					.mode			("codeeditor")
					//	.mode		("texteditor")
					//	.borderstyle(Bros.bsEditTop)				// Use here if selectorpanels have alignment "top"
					.borderstyle	(Bros.bsEditBottom)				// Use here if selectorpanels have alignment "bottom"
					.align			("client")
					//	.setfocus	()								// No longer need Editor_SelectIndex do it
					.onchange		(function (Elem, e)
						{
						//	deb		("Editor_AddEditFile, OnChange");
						EditFile_UpdateChanged(EditFile, ! false);	// Changed = ! false
						})
				.parentitem			()
			// This is a Gamb !!!
			.onready				(function (Elem)
				{
				//	PCS				(Elem.Selector);
				//	deb				(Elem.Selector.SelectorItems.length);
				//	//for (var i = 0; i < Elem.ChildElements.length; i++)
				//	//	{
				//	//	var Temp	= Elem.ChildElements[i];
				//	//	PCS			(Temp);
				//	//	}
				SelectedIndex		= Elem.Selector.SelectorItems.length - 1;
				//	Bros.selected	(SelectedIndex);
				})
			;

		// Set EditFile under edition by SelectedIndex
		Editor_SelectIndex			(SelectedIndex);
		}

	//---------------------------------------------------------------------------
	// Removes Edit File from Editor
	//---------------------------------------------------------------------------

	function Editor_RemEditFile(EditFile)
		{
		//	deb						("Editor_RemEditFile");
		//	PCS						(EditFile);

		// Selected ?
		if (EditFile == null)
			return;

		// Stores
		var LastIndex				= EditFile.Index;

		// Deletes Panel
		Bros
			.element				("MySelectorPanels")
				.deleteitem			(LastIndex);
			;

		// Deletes from EditFiles
		Bros.lib.arr.deleteindex	(EditFiles, LastIndex);

		// Rebuild Indexes
		Bros.lib.arr.rebuildindexes	(EditFiles);

		// Reselect the best as possible
		Editor_SelectIndex			(LastIndex);
		}

//###########################################################################
//###########################################################################
