//###########################################################################
//###########################################################################
//##
//## Bros - Browser Operational System - Messages
//##
//###########################################################################
//###########################################################################

		var Hint_VerbInf			= "Verbo (infinitivo)";
		var Hint_Color				= "Cor";

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("CLD",								"Mensagens do Calendário");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Window_Caption",					"Bros Calendário");
		//
		this.Lang_AddData			("Week_Header",						"sm");
		//
		this.Lang_AddObj			("Big",								"Para Calendários Grandes");
			this.Lang_AddData		("Jan",								"Janeiro");
			this.Lang_AddData		("Feb",								"Fevereiro");
			this.Lang_AddData		("Mar",								"Março");
			this.Lang_AddData		("Apr",								"Abril");
			this.Lang_AddData		("May",								"Maio");
			this.Lang_AddData		("Jun",								"Junho");
			this.Lang_AddData		("Jul",								"Julho");
			this.Lang_AddData		("Aug",								"Agosto");
			this.Lang_AddData		("Sep",								"Setembro");
			this.Lang_AddData		("Oct",								"Outubro");
			this.Lang_AddData		("Nov",								"Novembro");
			this.Lang_AddData		("Dec",								"Dezembro");
			//
			this.Lang_AddData		("Sun",								"Domingo");
			this.Lang_AddData		("Mon",								"Segunda-feira");
			this.Lang_AddData		("Tue",								"Terça-feira");
			this.Lang_AddData		("Wed",								"Quarta-feira");
			this.Lang_AddData		("Thu",								"Quinta-feira");
			this.Lang_AddData		("Fri",								"Sexta-feira");
			this.Lang_AddData		("Sat",								"S&aacute;bado");
			this.Lang_BackObj		();
			//
		this.Lang_AddObj			("Medium",							"Para Calendários Médios");
			this.Lang_AddData		("Jan",								"Jan");
			this.Lang_AddData		("Feb",								"Fev");
			this.Lang_AddData		("Mar",								"Mar");
			this.Lang_AddData		("Apr",								"Abr");
			this.Lang_AddData		("May",								"Mai");
			this.Lang_AddData		("Jun",								"Jun");
			this.Lang_AddData		("Jul",								"Jul");
			this.Lang_AddData		("Aug",								"Ago");
			this.Lang_AddData		("Sep",								"Set");
			this.Lang_AddData		("Oct",								"Out");
			this.Lang_AddData		("Nov",								"Nov");
			this.Lang_AddData		("Dec",								"Dez");
			//
			this.Lang_AddData		("Sun",								"Dom");			// Domingo
			this.Lang_AddData		("Mon",								"Seg");			// Segunda
			this.Lang_AddData		("Tue",								"Ter");			// Terça
			this.Lang_AddData		("Wed",								"Qua");			// Quarta
			this.Lang_AddData		("Thu",								"Qui");			// Quinta
			this.Lang_AddData		("Fri",								"Sex");			// Sexta
			this.Lang_AddData		("Sat",								"Sáb");			// Sábado
			this.Lang_BackObj		();
			//
		this.Lang_AddObj			("Small",							"Para Calendários Pequenos");
			this.Lang_AddData		("Jan",								"J");
			this.Lang_AddData		("Feb",								"F");
			this.Lang_AddData		("Mar",								"M");
			this.Lang_AddData		("Apr",								"A");
			this.Lang_AddData		("May",								"M");
			this.Lang_AddData		("Jun",								"J");
			this.Lang_AddData		("Jul",								"J");
			this.Lang_AddData		("Aug",								"A");
			this.Lang_AddData		("Sep",								"S");
			this.Lang_AddData		("Oct",								"O");
			this.Lang_AddData		("Nov",								"N");
			this.Lang_AddData		("Dec",								"D");
			//
			this.Lang_AddData		("Sun",								"D");
			this.Lang_AddData		("Mon",								"S");
			this.Lang_AddData		("Tue",								"T");
			this.Lang_AddData		("Wed",								"Q");
			this.Lang_AddData		("Thu",								"Q");
			this.Lang_AddData		("Fri",								"S");
			this.Lang_AddData		("Sat",								"S");
			this.Lang_BackObj		();
			//
		this.Lang_AddData			("InsertNewReminderOnThisDate",		"Inserir novo Lembrete nesta data");
		this.Lang_AddData			("InsertNewPersonOnThisDate",		"Inserir nova Pessoa com aniversário nesta data");
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("CLR",								"Colors");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Black",							"Preto",				Hint_Color, "000000");
		this.Lang_AddData			("White",							"Branco",				Hint_Color, "FFFFFF");
		this.Lang_AddData			("Transparent",						"Transparente",			Hint_Color, "");
		//
		this.Lang_AddData			("LightGray",						"Cinza Claro",			Hint_Color, "E0E0E0");
		this.Lang_AddData			("Silver",							"Prata",				Hint_Color, "C0C0C0");
		this.Lang_AddData			("Gray",							"Cinza",				Hint_Color, "808080");
		this.Lang_AddData			("DarkGray",						"Cinza escuro",			Hint_Color, "606060");
		//
		this.Lang_AddData			("Red",								"Vermelho",				Hint_Color, "FF0000");
		this.Lang_AddData			("GreenLime",						"Verde Limão",			Hint_Color, "00FF00");
		this.Lang_AddData			("Blue",							"Azul",					Hint_Color, "0000FF");
		//
		this.Lang_AddData			("Yellow",							"Amarelo",				Hint_Color, "FFFF00");
		this.Lang_AddData			("Magenta",							"Magenta",				Hint_Color, "FF00FF");
		this.Lang_AddData			("Cyan",							"Ciano",				Hint_Color, "00FFFF");
		//
		this.Lang_AddData			("Maroon",							"Marrom",				Hint_Color, "800000");
		this.Lang_AddData			("Green",							"Verde",				Hint_Color, "008000");
		this.Lang_AddData			("BlueNavy",						"Azul Marinho",			Hint_Color, "000080");
		//
		this.Lang_AddData			("GreenOlive",						"Verde Oliva",			Hint_Color, "808000");
		this.Lang_AddData			("Purple",							"Púrpura",				Hint_Color, "800080");
		this.Lang_AddData			("Teal",							"Azul Petróleo",		Hint_Color, "008080");
		//
		this.Lang_AddData			("LightYellow",						"Amarelo Claro",		Hint_Color, "FFFFC0");
		this.Lang_AddData			("Gold",							"Ouro",					Hint_Color, "FFC000");
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("VRB",								"Verbos (Infinitivo)");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Apply",							"Aplicar",				Hint_VerbInf);
		this.Lang_AddData			("Cancel",							"Cancelar",				Hint_VerbInf);
		this.Lang_AddData			("Change",							"Mudar",				Hint_VerbInf);
		this.Lang_AddData			("Close",							"Fechar",				Hint_VerbInf);
		this.Lang_AddData			("Delete",							"Deletar",				Hint_VerbInf);
		this.Lang_AddData			("Open",							"Abrir",				Hint_VerbInf);
		this.Lang_AddData			("Print",							"Imprimir",				Hint_VerbInf);
		this.Lang_AddData			("Rename",							"Renomear",				Hint_VerbInf);
		this.Lang_AddData			("Save",							"Salvar",				Hint_VerbInf);
		this.Lang_AddData			("Start",							"Bros",					Hint_VerbInf);
		this.Lang_AddData			("Supply",							"Fornecer",				Hint_VerbInf);
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("WRD",								"Word Messages");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Address",							"Endereço");
		this.Lang_AddData			("Appearance",						"Aparência");
		this.Lang_AddData			("Application",						"Aplicação");
		this.Lang_AddData			("BackgroundColor",					"Cor de fundo");
		this.Lang_AddData			("Birthday",						"Aniversário");
		this.Lang_AddData			("Bold",							"Negrito");
		this.Lang_AddData			("Calculator",						"Calculadora");
		this.Lang_AddData			("Calendar",						"Calendário");
		this.Lang_AddData			("Caption",							"Título");
		this.Lang_AddData			("City",							"Cidade");
		this.Lang_AddData			("Color",							"Cor");
		this.Lang_AddData			("Colors",							"Cores");
		this.Lang_AddData			("Comma",							"Vírgula");
		this.Lang_AddData			("Concluded",						"Concluído");
		this.Lang_AddData			("Confirmation",					"Confirmação");
		this.Lang_AddData			("Country",							"País");
		this.Lang_AddData			("DateCreated",						"Data/Hora da Criação");
		this.Lang_AddData			("DateRemind",						"Data/Hora do Lembrete");
		this.Lang_AddData			("Dayly",							"Diariamente");
		this.Lang_AddData			("Defaults",						"Padrões");
		this.Lang_AddData			("Description",						"Descrição");
		this.Lang_AddData			("Developers",						"Desenvolvedores");
		this.Lang_AddData			("Dot",								"Ponto");
		this.Lang_AddData			("EMail",							"EMail");
		this.Lang_AddData			("EMails",							"EMails");
		this.Lang_AddData			("Enabled",							"Habilitado");
		this.Lang_AddData			("Error",							"Erro");
		this.Lang_AddData			("Exit",							"Sair");
		this.Lang_AddData			("File",							"Arquivo");
		this.Lang_AddData			("First",							"Primeiro");
		this.Lang_AddData			("Font",							"Fonte");
		this.Lang_AddData			("FontFamilies",					"Famílias de Fontes");
		this.Lang_AddData			("FontFamily",						"Família do Fonte");
		this.Lang_AddData			("Fonts",							"Fontes");
		this.Lang_AddData			("From",							"De");
		this.Lang_AddData			("GeneralObservations",				"Observações Gerais");
		this.Lang_AddData			("Historic",						"Histórico");
		this.Lang_AddData			("Important",						"Importante");
		this.Lang_AddData			("Information",						"Informação");
		this.Lang_AddData			("Italic",							"Itálico");
		this.Lang_AddData			("Language",						"Linguagem");
		this.Lang_AddData			("Last",							"Último");
		this.Lang_AddData			("Loading",							"Carregando");
		this.Lang_AddData			("Monthly",							"Mensalmente");
		this.Lang_AddData			("Name",							"Nome");
		this.Lang_AddData			("Neighborhood",					"Bairro");
		this.Lang_AddData			("New",								"Novo");
		this.Lang_AddData			("Next",							"Próximo");
		this.Lang_AddData			("No",								"Não");
		this.Lang_AddData			("None",							"Nada");
		this.Lang_AddData			("Normal",							"Normal");
		this.Lang_AddData			("NoWrap",							"Na mesma linha");
		this.Lang_AddData			("OK",								"OK");
		this.Lang_AddData			("Options",							"Opções");
		this.Lang_AddData			("People",							"Pessoas");
		this.Lang_AddData			("Personal",						"Pessoal");
		this.Lang_AddData			("Phone",							"Telefone");
		this.Lang_AddData			("Phones",							"Telefones");
		this.Lang_AddData			("Previous",						"Anterior");
		this.Lang_AddData			("Priorities",						"Prioridades");
		this.Lang_AddData			("Priority",						"Prioridade");
		this.Lang_AddData			("Programs",						"Programas");
		this.Lang_AddData			("Properties",						"Propriedades");
		this.Lang_AddData			("Relevance",						"Relevância");
		this.Lang_AddData			("Relevances",						"Relevâncias");
		this.Lang_AddData			("Reminders",						"Lembretes");
		this.Lang_AddData			("Sequence",						"Sequência");
		this.Lang_AddData			("Settings",						"Definições");
		this.Lang_AddData			("Size",							"Tamanho");
		this.Lang_AddData			("State",							"Estado");
		this.Lang_AddData			("Style",							"Estilo");
		this.Lang_AddData			("To",								"Até");
		this.Lang_AddData			("Toggle",							"Inverter");
		this.Lang_AddData			("Tools",							"Ferramentas");
		this.Lang_AddData			("Underline",						"Sublinhado");
		this.Lang_AddData			("VeryImportant",					"Muito Importante");
		this.Lang_AddData			("Warning",							"Aviso");
		this.Lang_AddData			("Weekly",							"Semanalmente");
		this.Lang_AddData			("Welcome",							"Benvindo");
		this.Lang_AddData			("Yes",								"Sim");
		this.Lang_AddData			("You",								"Você");
		this.Lang_AddData			("ZipCode",							"CEP");
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("PHR",								"Phrases Messages");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("AddProgram",						"Adicionar Programa");
		this.Lang_AddData			("AllTables",						"Todas as Tabelas");
		this.Lang_AddData			("AnimateWindows",					"Anima as Janelas");
		this.Lang_AddData			("ApplicationArguments",			"Argumentos da Aplicação");
		this.Lang_AddData			("BoldBgRed",						"Negrito com cor de fundo Vermelho");
		this.Lang_AddData			("BrosApp_Builder",					"Bros Criador de Aplicações");
		this.Lang_AddData			("BrosApp_Editor",					"Bros Editor de Aplicações");
		this.Lang_AddData			("BrosApp_LCenter",					"Bros Central de Aprendizado de Aplicações");		// To cut (Hello World)
		this.Lang_AddData			("BrosApp_LCenterDsk",				"Bros Central de Aprendizado de Aplicações (Hello World)");
		this.Lang_AddData			("BrosApp_LCenterMob",				"Bros Central de Aprendizado");
		this.Lang_AddData			("ChangeUser",						"Mudar Usuário");
		this.Lang_AddData			("ClearMsgs",						"Limpa Msgs");
		this.Lang_AddData			("CloseAll",						"Fechar Tudo");
		this.Lang_AddData			("CodeEditor",						"Editor de Notas e Programas");
		this.Lang_AddData			("CopyToFolder",					"Copiar para a Pasta...");
		this.Lang_AddData			("CredentialsChanged",				"Credenciais Mudadas");
		this.Lang_AddData			("CurrentPassword",					"Password Atual");
		this.Lang_AddData			("CurrentUserName",					"User Name Atual");
		this.Lang_AddData			("MyDataBase",						"Minha Base de Dados");
		this.Lang_AddData			("DateAppearanceEG",				"Aparência das Datas, ex.");
		this.Lang_AddData			("DateFormat",						"Formato da Data");
		this.Lang_AddData			("DateTimeAppearanceEG",			"Aparência das Datas/Horas, ex.");
		this.Lang_AddData			("DateTimeFormat",					"Formato da Data/Hora");
		this.Lang_AddData			("DecimalSeparator",				"Separador de Decimais");
		this.Lang_AddData			("DeleteThisRecord",				"Deleta este Registro");
		this.Lang_AddData			("DesktopMode",						"Modo Desktop");
		this.Lang_AddData			("DoesNotMatch",					"Não Confere");
		this.Lang_AddData			("FileAlreadyExists",				"Arquivo já existe");
		this.Lang_AddData			("FileManager",						"Gerenciador de Arquivos");
		this.Lang_AddData			("FileSaved",						"Arquivo Salvo");
		this.Lang_AddData			("ImageSource",						"Origem da Image");
		this.Lang_AddData			("ImageViewer",						"Visualizador de Imagens");
		this.Lang_AddData			("MobileMode",						"Modo Mobile");
		this.Lang_AddData			("MoveToFolder",					"Mover para Pasta...");
		this.Lang_AddData			("MyComputer",						"Meu Computador");
		this.Lang_AddData			("NewFolder",						"Novo Arquivo");
		this.Lang_AddData			("NewPassword",						"Novo Password");
		this.Lang_AddData			("NewUserName",						"Novo User Name");
		this.Lang_AddData			("NormalBgYellow",					"Normal com cor de fundo Amarelo");
		this.Lang_AddData			("NormalText",						"Texto Normal");
		this.Lang_AddData			("NumbersAppearanceEG",				"Aparência dos Números, ex.");
		this.Lang_AddData			("PrintScreen",						"Imprimie a Tela");
		this.Lang_AddData			("ProgramAdded",					"Programa Adicionado");
		this.Lang_AddData			("ReloadApplication",				"Recarregar a Applicação");
		this.Lang_AddData			("RemoveProgram",					"Remover Programa");
		this.Lang_AddData			("SaveAll",							"Salvar Tudo");
		this.Lang_AddData			("SaveAs",							"Salvar Como");
		this.Lang_AddData			("ScriptSource",					"Origem do Script");
		this.Lang_AddData			("SelectAnImage",					"Selecionar uma Imagem");
		this.Lang_AddData			("SelectAppArgsAsURL",				"Selecionar Argumento da Applicação como uma URL");
		this.Lang_AddData			("SelectAProgram",					"Selecionar um programa...");
		this.Lang_AddData			("SelectAStartMenu",				"Selecionar um Menu do Start");
		this.Lang_AddData			("SelectOneScriptSource",			"Selecionar uma Origem de Script");
		this.Lang_AddData			("StartMenu",						"Menu de Start");
		this.Lang_AddData			("SupplyACaption",					"Fornecer um Título");
		this.Lang_AddData			("SystemMonitor",					"Monitor do Sistema");
		this.Lang_AddData			("ThousandSeparator",				"Separador de Milhares");
		this.Lang_AddData			("TimeAppearanceEG",				"Aparência das Horas, ex.");
		this.Lang_AddData			("TimeFormat",						"Formato da Hora");
		this.Lang_AddData			("TurnOffComputer",					"Desligar Computador Bros...");
		this.Lang_AddData			("UserCredentials",					"Credenciais do Usuário");
		this.Lang_AddData			("UserDisplayName",					"Nome do Usuário a ser exibido");
		this.Lang_AddData			("WebSite",							"Web Site");
		this.Lang_AddData			("WebSites",						"Sites na Web");
		this.Lang_AddData			("YearTo2000",						"Ano NN = 20NN");
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("KRN",								"Msgs for Kernel");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("YouCanShutDown",					"Você pode desligar seu computador com segurança agora.<br>(pressione F5 para rebootar seu computador Bros)<p>(se você estava logado as<br>posições das janelas abertas foram salvas para seu próximo login)");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("SGI",								"Msgs for Sign-In");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("AutoNextLogin",					"Fazer auto login quando eu rodar o Bros neste computador");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("APP",								"Msgs for loadapplication");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("APP_NotFound",					"Não encontrada aplicação com o nome:");
		this.Lang_AddData			("APP_FailLoading",					"Erro durante a carga da Aplicação com o nome:");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("FSY",								"Msgs for File System");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("InvalidFullFileName",				"Nome de Arquivo/Pasta inválido.<br>(falta de :, ou múltiplos : (dois pontos)<br>ou<br>possui algum dos 9 caracteres inválidos <font face='courier new' size=4>(<b><>:\"/\\|?*</b>)</font><br>ou<br>pedaço de nome em branco)");
		this.Lang_AddData			("UnknownRootFolder",				"Pasta Raiz inválida:");
		//
		this.Lang_AddData			("CannotCrFolderThisRoot",			"Você não pode criar Pastas neste tipo de Pasta Raiz.");
		this.Lang_AddData			("CannotCreateRoot",				"Você não pode criar Pastas Raiz.");
		//
		this.Lang_AddData			("CannotRenameRoots",				"Você não pode renomear Pastas Raiz.");
		this.Lang_AddData			("RootFolderAlreadyExists",			"Pasta Raiz já existe.");
		//
		this.Lang_AddData			("CannotCopyFolders",				"Você não pode Copiar Pastas.");
		this.Lang_AddData			("DestFolderNotFound",				"Pasta de Destino não encontrada.");
		this.Lang_AddData			("DestIsNotFolder",					"Destino não é uma Pasta.");
		//
		this.Lang_AddData			("CannotDelFromThisRoot",			"Você não pode deletar Arquivos/Pastas neste tipo de Pasta Raiz.");
		this.Lang_AddData			("CannotDeleteRoots",				"Você não pode deletar Pastas Raiz.");
		this.Lang_AddData			("CannotDelFolderNotEmpty",			"Você não pode deletar Pastas não vazias (temporariamente).");
		//
		this.Lang_AddData			("SourceNotFound",					"Arquivo/Pasta Origem não encontrada.");
		this.Lang_AddData			("DestinationExists",				"Arquivo/Pasta de Destino já existe.");
		//
		this.Lang_AddData			("FileNotFound",					"Arquivo não encontrado.");
		this.Lang_AddData			("CannotReadFolder",				"Você não pode ler uma Pasta.");
		this.Lang_AddData			("CannotReadExecuteFolder",			"Você não pode ler e executar uma Pasta.");
		//
		this.Lang_AddData			("CannotWriteFolder",				"Você não pode gravar uma Pasta.");
		//
		this.Lang_AddData			("CannotWriteURL",					"Você não pode gravar uma URL.");

		// RootFolder ErrorMsgs (RFEM)
		this.Lang_AddData			("RFEM_FolderCaption_Invalid",		"<b>Nome de Pasta</b> Inválido (precisa terminar com : (dois pontos).<p>");
		this.Lang_AddData			("RFEM_FolderMap_Invalid",			"<b>Mapa de Pasta</b> Inválido (precisa especificar um directório).<p>");
		this.Lang_AddData			("RFEM_FolderMap_Driver_NotF",		"<b>Driver</b> Inválido (não encontrado).<p>");
		this.Lang_AddData			("RFEM_FolderMap_Driver_AccT",		"<b>Access Token</b> Inválido.<p>");

		// Drivers Caption
		this.Lang_AddData			("DriverCaption_URL",				"Driver URL");
		this.Lang_AddData			("DriverCaption_BrosFS",			"Driver Bros Gerenciador de Arquivos");
		this.Lang_AddData			("DriverCaption_Dropbox",			"Driver Dropbox");
		//
		this.Lang_AddData			("DriverCaption_Dropbox_Msg",		"Se você ainda não possue um accesstoken, faça o login na sua conta do Dropbox e crie<br>" +
																		"um em: Developers/App Console/Create App [Dropbox API app] ... [Create app]<br>" +
																		"[Generated access token]");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("FMA",								"Msgs for File Manager");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("File",							"Arquivo");
		this.Lang_AddData			("Folder",							"Pasta");
		//
		this.Lang_AddData			("Rename",							"Renomear");
		this.Lang_AddData			("Delete",							"Deletar");
		//
		this.Lang_AddData			("From",							"De");
		this.Lang_AddData			("To",								"Para");
		//
		this.Lang_AddData			("CannotMoveRoots",					"Você não pode mover Pastas Raiz.");

		this.Lang_AddData			("ExplorePhysically",				"Explorar Fisicamente");
		this.Lang_AddData			("ExploreMapped",					"Explorar Normalmente");

		// Window
		this.Lang_AddData			("Window_Caption",					"Bros Gerenciador de Arquivos");
		this.Lang_AddData			("Window_Caption_Physically",		"(FISICAMENTE)");
		this.Lang_AddData			("Window_Caption_SelDFolder",		"Selecione uma Pasta de destino");
		this.Lang_AddData			("Window_Caption_Open",				"Abrir");
		this.Lang_AddData			("Window_Caption_SaveAs",			"Salvar como");

		this.Lang_AddData			("SelectFileFolder",				"Favor selecionar antes um Arquivo/Pasta.");
		this.Lang_AddData			("SelectFolder",					"Favor selecionar antes uma Pasta.");
		this.Lang_AddData			("SelectRootFolder",				"Favor selecionar antes uma Pasta Raiz.");
		this.Lang_AddData			("SelectFile",						"Favor selecionar antes um Arquivo.");

		this.Lang_AddData			("CreateFolder",					"Criar nova Pasta");
		this.Lang_AddData			("CreateFolder_Under",				"Criar nova Pasta em:");

		// Window to New/Edit Root Folder
		this.Lang_AddData			("WinRF_Folder_Caption",			"Nome da Pasta");
		this.Lang_AddData			("WinRF_Phisical_Folder",			"Pasta Física");
		this.Lang_AddData			("WinRF_Driver",					"Driver");
		this.Lang_AddData			("WinRF_AccessToken",				"Access Token");

		// Menus
		this.Lang_AddData			("Menu_MapNewRootFolder",			"Mapear nova Pasta Raiz");
		this.Lang_AddData			("Menu_EditRootFolder",				"Editar Pasta Raiz");
		this.Lang_AddData			("Menu_DisconnectRootFolder",		"Deconectar Pasta Raiz");

		// Menus
		this.Lang_AddData			("NoAppAssociationOpenTextEd",		"Não existe aplicação associada com a extensão do nome do arquivo.<p>Você deseja abrir o arquivo com o Editor de Notas e Programas ?");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("TXE",								"Msgs for Application Text Editor");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Window_Caption",					"Bros Editor de Notas e Programas");
		this.Lang_AddData			("FileNotSavedCloseIt",				"Arquivo não salvo. Fechar assim mesmo ?");
		this.Lang_AddData			("FileAlreadyExistsOverwrite",		"Arquivo já existe. Gravar por cima ?");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("IMV",								"Msgs for Application Image Viewer");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Window_Caption",					"Bros Visualizador de Imagens");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("APE",								"Msgs for Application Editor");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Window_Caption",					"Bros Editor de Applicações");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("LIB_MENU",						"Msgs for Lib Menu");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("CloseMenuOnClick",				"Fechar o menu ao clicar ?");
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("TSY",								"Msgs for Table System Application");
		//---------------------------------------------------------------------------

		this.Lang_AddData			("Op_ShowRecord",					"Exibir Registro");
		this.Lang_AddData			("Op_InsertNewRecord",				"Inserir Novo Registro");
		this.Lang_AddData			("Op_InsertCopyRecord",				"Inserir Cópia do Registro");
		this.Lang_AddData			("Op_EditRecord",					"Editar Registro");
		this.Lang_AddData			("Op_DeleteRecord",					"Deletar Registro");
		//
		this.Lang_AddData			("Op_M_EditRecords",				"Editar Múltiplos Registro");
		this.Lang_AddData			("Op_M_DeleteRecords",				"Deletar Múltiplos Registro");
		//
		this.Lang_AddData			("Op_Menu",							"Menu");
		//
		this.Lang_AddData			("PleaseFillRecordsBefore",			"Pro favor, antes de executar esta operação, inserir pelo menos um registro na Tabela:<p><b>%1</b>.");
		this.Lang_AddData			("AutoRelatedCaption",				"Este Registro");
		this.Lang_AddData			("Error_CannotBeBlank",				"A coluna <b>%1</b> não pode ficar em branco.");
		this.Lang_AddData			("Error_Unique",					"O registro com ID <b>%1</b> já possue a coluna <b>%2</b> com o valor <b>%3</b>.");
		this.Lang_AddData			("Error_Boolean",					"A coluna <b>%1</b> precisa ter <b>S</b> (Sim) ou <b>N</b> (Não) e não <b>%2</b>.");
		this.Lang_AddData			("Error_Color",						"A coluna <b>%1</b> precisa ter 6 caracteres hexadecimais (ex. F2A48E) correspondentes à cor RGB (Red (Vermelho), Green (Verde), Blue (Azul)).");
		this.Lang_AddData			("Error_CannotBeDeleted",			"Este registro não pode ser deletado porque ele é usado em:<p>");
		this.Lang_AddData			("Error_RecordUsed",				"<b>%1</b> registro(s) na tabela <b>%2</b>, na coluna <b>%3</b><br>");
		//
		this.Lang_AddData			("Error_InvalidTableNickName",		"Apelido da Tabela Inválido (<b>%1</b>).");
		//
		this.Lang_AddData			("Error_NoRowsChecked",				"Você executou a operação múltipla:<p><b>%1</b><p>porém não selecionou nenhum registro.");
		this.Lang_AddData			("Error_MOperNoOnClick",			"A operação:<p><b>%1</b><p>não possui o método do evento OnClick.");
		this.Lang_AddData			("MOper_Confirm",					"Você confirma a operação:<p><b>%1</b><p>para ser executada no(s) registro(s) com ID(s):<p>%2<p>?");
		//
		this.Lang_BackObj			();

		//---------------------------------------------------------------------------
		this.Lang_AddObj			("REM",								"Msgs for Table Reminders Application");
		//---------------------------------------------------------------------------
		//
		this.Lang_AddData			("EnvolvedPerson",					"Pessoa Envolvida");
		this.Lang_AddData			("EnvolvedValue",					"Valor Envolvido");
		//
		this.Lang_AddData			("OnDate",							"Na Data");
		this.Lang_AddData			("DateBeguin",						"A partir da Data");
		this.Lang_AddData			("DateEnd",							"Até a Data");
		this.Lang_AddData			("RemindWillOccur",					"Lembrete ocorrerá");
		//
		this.Lang_AddData			("OneTimeOnly",						"Somente uma vez");
		//
		this.Lang_AddData			("BeguinTime",						"Hora Inicial");
		this.Lang_AddData			("EndTime",							"Hora Final");
		//
		this.Lang_AddData			("OnWeeks",							"Nas Semanas");
		//
		this.Lang_AddData			("OnAllMonthWeeks",					"em todas as semanas dos meses");
		this.Lang_AddData			("On1stMonthWeeks",					"somente nas 1as semanas dos meses");
		this.Lang_AddData			("On2ndMonthWeeks",					"somente nas 2as semanas dos meses");
		this.Lang_AddData			("On3rdMonthWeeks",					"somente nas 3as semanas dos meses");
		this.Lang_AddData			("On4rtMonthWeeks",					"somente nas 4as semanas dos meses");
		this.Lang_AddData			("OnLastMonthWeeks",				"somente nas últimas semanas do meses");
		//
		this.Lang_AddData			("OnEveryMonthDay",					"No dia");
		//
		this.Lang_BackObj			();





//###########################################################################
//###########################################################################
